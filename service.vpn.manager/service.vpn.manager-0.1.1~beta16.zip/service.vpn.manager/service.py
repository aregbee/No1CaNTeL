import xbmc
import xbmcgui

from resources.lib.backend_loader import (
    backend_capabilities,
    get_backend,
    platform_name,
)
from resources.lib import netverify

backend = get_backend()
PLATFORM = platform_name()
CAPABILITIES = backend_capabilities(backend)

import time


window = xbmcgui.Window(10000)
monitor = xbmc.Monitor()


def setprop(name, value):
    window.setProperty(name, str(value) if value else "N/A")


def _dashboard_interface(value):
    text = str(value or "").strip()

    if "(" in text and text.endswith(")"):
        return text.rsplit("(", 1)[1][:-1].strip()

    if text in ("", "N/A", "Unknown"):
        return ""

    return text


def _dashboard_path(value):
    text = str(value or "Unknown").strip()
    lower = text.lower()

    if "router" in lower or "upstream" in lower:
        return "Router/Upstream"

    if "local" in lower or "openvpn" in lower:
        return "Local OpenVPN"

    return text


def publish_dashboard_summary(state):
    state = state or {}

    status = str(
        state.get("status", "CHECK VPN")
    ).strip()

    path = _dashboard_path(
        state.get("path", "Unknown")
    )

    interface = _dashboard_interface(
        state.get("interface", "")
    )

    summary = "{} - {}".format(
        status,
        path
    )

    if interface:
        summary += " [{}]".format(interface)

    setprop(
        "VPNManager.StatusSummary",
        summary
    )

    path_lower = str(
        state.get("path", "")
    ).lower()

    status_lower = status.lower()

    if (
        ("local" in path_lower or "openvpn" in path_lower)
        and status_lower == "protected"
    ):
        activity = "Active"

    elif (
        ("router" in path_lower or "upstream" in path_lower)
        and status_lower == "protected"
    ):
        activity = "Standby"

    else:
        activity = "Inactive"

    setprop(
        "VPNManager.ProfileActivity",
        activity
    )


def publish_backend_state(state):
    state = state or {}

    publish_dashboard_summary(state)

    setprop("VPNManager.PublicIP", "Updating...")
    setprop("VPNManager.VPNExitLocation", "Updating...")
    setprop("VPNManager.VPNExitNetwork", "Updating...")
    setprop("VPNManager.VPNPath", state.get("path", "Unknown"))
    setprop("VPNManager.VPNStatus", state.get("status", "CHECK VPN"))
    setprop("VPNManager.VPNInterface", state.get("interface", "N/A"))
    setprop("VPNManager.VPNTunnelIP", state.get("tunnel_ip", "N/A"))
    setprop("VPNManager.VPNServer", state.get("server", "Unknown"))
    setprop("VPNManager.VPNKillSwitch", state.get("killswitch", "Unknown"))
    setprop(
        "VPNManager.VPNVerification",
        state.get("verification", "Backend state unavailable")
    )


def refresh():
    # Publish authoritative local/backend state first.
    # External IP classification is supplemental and must not delay
    # path/status/killswitch changes appearing in Kodi.
    backend_state = backend.vpn_state()
    publish_backend_state(backend_state)

    external = netverify.external_vpn_check()
    state = netverify.merge_state(
        backend_state,
        external
    )

    pub = external.get(
        "public_ip",
        "Unavailable"
    )

    path = state.get("path", "Unknown")
    status = state.get("status", "CHECK VPN")
    interface = state.get("interface", "N/A")
    tip = state.get("tunnel_ip", "N/A")
    server = state.get("server", "Unknown")
    killswitch = state.get("killswitch", "Unknown")
    verification = state.get(
        "verification",
        "Backend state unavailable"
    )

    setprop("VPNManager.PublicIP", pub)
    setprop(
        "VPNManager.VPNExitLocation",
        external.get("exit_location", "Unavailable")
    )
    setprop(
        "VPNManager.VPNExitNetwork",
        external.get("exit_network", "Unavailable")
    )
    setprop("VPNManager.VPNPath", path)
    setprop("VPNManager.VPNStatus", status)
    setprop("VPNManager.VPNInterface", interface)
    setprop("VPNManager.VPNTunnelIP", tip)
    setprop("VPNManager.VPNServer", server)
    setprop("VPNManager.VPNKillSwitch", killswitch)
    setprop("VPNManager.VPNVerification", verification)

    publish_dashboard_summary(state)

    xbmc.log(
        "Kodi VPN Manager: Public={} VPN={} Status={} Verify={}".format(
            pub,
            path,
            status,
            verification
        ),
        xbmc.LOGINFO
    )


AUTO_REFRESH_SECONDS = 300
next_auto_refresh = time.monotonic() + AUTO_REFRESH_SECONDS
last_state_token = backend.state_token()

# Initial display refresh, after backend state tracking exists.
refresh()

while not monitor.waitForAbort(1):

    current_state_token = backend.state_token()

    state_changed = (
        bool(current_state_token)
        and current_state_token != last_state_token
    )

    if state_changed:
        xbmc.log(
            "Kodi VPN Manager: VPN state changed {} -> {}".format(
                last_state_token or "unknown",
                current_state_token
            ),
            xbmc.LOGINFO
        )

        last_state_token = current_state_token

    manual_refresh = (
        window.getProperty("VPNManager.RefreshVPN") == "1"
    )

    timed_refresh = (
        time.monotonic() >= next_auto_refresh
    )

    if manual_refresh or timed_refresh or state_changed:

        if manual_refresh:
            window.clearProperty("VPNManager.RefreshVPN")
            setprop("VPNManager.VPNStatus", "Refreshing...")
            setprop("VPNManager.VPNVerification", "Checking now...")

            xbmc.log(
                "Kodi VPN Manager: Manual VPN refresh requested",
                xbmc.LOGINFO
            )

            try:
                result = backend.request_refresh()

                # If a backend refresh is already running,
                # wait for it to finish before reading state.
                for _ in range(90):
                    if not backend.refresh_in_progress():
                        break

                    if monitor.waitForAbort(0.5):
                        break

                xbmc.log(
                    "Kodi VPN Manager: VPN refresh result={}".format(
                        result if result is not None else "unavailable"
                    ),
                    xbmc.LOGINFO
                )

            except Exception as exc:
                xbmc.log(
                    "Kodi VPN Manager: VPN refresh failed: {}".format(exc),
                    xbmc.LOGERROR
                )

        if state_changed and not manual_refresh:
            monitor.waitForAbort(2)

        refresh()

        # Prevent a manual backend refresh from causing a duplicate refresh.
        last_state_token = backend.state_token() or last_state_token

        next_auto_refresh = (
            time.monotonic() + AUTO_REFRESH_SECONDS
        )


for prop in (
    "VPNManager.PublicIP",
    "VPNManager.VPNExitLocation",
    "VPNManager.VPNExitNetwork",
    "VPNManager.VPNPath",
    "VPNManager.VPNStatus",
    "VPNManager.StatusSummary",
    "VPNManager.ProfileActivity",
    "VPNManager.VPNInterface",
    "VPNManager.VPNTunnelIP",
    "VPNManager.VPNServer",
    "VPNManager.VPNKillSwitch",
    "VPNManager.VPNVerification",
):
    window.clearProperty(prop)
