import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.backend_loader import (
    backend_capabilities,
    get_backend,
)
from resources.lib import profiles


ADDON = xbmcaddon.Addon()
WINDOW = xbmcgui.Window(10000)
DIALOG = xbmcgui.Dialog()

BACKEND = get_backend()
CAPABILITIES = backend_capabilities(
    BACKEND,
    interactive=True
)

REGISTRY = xbmcvfs.translatePath(
    "special://profile/addon_data/"
    "service.vpn.manager/profiles.json"
)


def prop(name):
    value = WINDOW.getProperty(
        "VPNManager." + name
    )

    return value if value else "N/A"


def selected_profile():
    data = profiles.load(REGISTRY)

    return (
        data,
        profiles.selected_profile(data)
    )


def profile_name(profile):
    if not profile:
        return "None"

    return profile.get(
        "name",
        profile.get("id", "Unknown")
    )


def show_status():
    data, selected = selected_profile()

    message = (
        "Platform: {platform}\n"
        "Mode: {mode}\n"
        "\n"
        "VPN path: {path}\n"
        "Status: {status}\n"
        "Public IP: {public_ip}\n"
        "Interface: {interface}\n"
        "Tunnel IP: {tunnel_ip}\n"
        "Server: {server}\n"
        "Kill switch: {killswitch}\n"
        "Verification: {verification}\n"
        "\n"
        "Selected profile: {profile}"
    ).format(
        platform=CAPABILITIES["name"],
        mode=CAPABILITIES["mode"].title(),
        path=prop("VPNPath"),
        status=prop("VPNStatus"),
        public_ip=prop("PublicIP"),
        interface=prop("VPNInterface"),
        tunnel_ip=prop("VPNTunnelIP"),
        server=prop("VPNServer"),
        killswitch=prop("VPNKillSwitch"),
        verification=prop("VPNVerification"),
        profile=profile_name(selected),
    )

    DIALOG.textviewer(
        "Kodi VPN Manager",
        message
    )


def refresh_now():
    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )

    started = time.monotonic()

    while time.monotonic() - started < 60:
        xbmc.sleep(250)

        requested = WINDOW.getProperty(
            "VPNManager.RefreshVPN"
        )

        status = prop("VPNStatus")
        verification = prop(
            "VPNVerification"
        )

        if (
            requested != "1"
            and status != "Refreshing..."
            and verification != "Checking now..."
        ):
            break

    show_status()


def choose_profile():
    data = profiles.load(REGISTRY)

    available = [
        profile
        for profile in profiles.profiles(data)
        if profile.get("enabled", True)
    ]

    if not available:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No enabled managed VPN profiles are configured."
        )
        return

    current = profiles.selected_profile(data)

    labels = []

    for profile in available:
        prefix = (
            "✓ "
            if current
            and profile["id"] == current["id"]
            else ""
        )

        labels.append(
            "{}{} [{}]".format(
                prefix,
                profile["name"],
                profile["type"].upper(),
            )
        )

    choice = DIALOG.select(
        "Select VPN Profile",
        labels
    )

    if choice < 0:
        return

    selected = available[choice]

    data = profiles.set_selected(
        data,
        selected["id"]
    )

    profiles.save(
        REGISTRY,
        data
    )

    DIALOG.notification(
        "Kodi VPN Manager",
        "Selected: {}".format(
            selected["name"]
        ),
        xbmcgui.NOTIFICATION_INFO,
        3000
    )


def supported_profile_types():
    getter = getattr(
        BACKEND,
        "supported_profile_types",
        None
    )

    if not getter:
        return []

    try:
        return list(getter())
    except Exception:
        return []


def add_profile():
    types = supported_profile_types()

    if not types:
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform has no supported managed VPN profile types."
        )
        return

    if len(types) == 1:
        profile_type = types[0]

    else:
        labels = [
            item.upper()
            for item in types
        ]

        choice = DIALOG.select(
            "VPN Profile Type",
            labels
        )

        if choice < 0:
            return

        profile_type = types[choice]

    if profile_type == "openvpn":
        mask = ".ovpn"
        heading = "Select OpenVPN Profile"

    elif profile_type == "wireguard":
        mask = ".conf"
        heading = "Select WireGuard Profile"

    else:
        return

    selected_path = DIALOG.browseSingle(
        1,
        heading,
        "",
        mask,
        False,
        False,
        ""
    )

    if not selected_path:
        return

    selected_path = xbmcvfs.translatePath(
        selected_path
    )

    default_name = os.path.splitext(
        os.path.basename(selected_path)
    )[0]

    name = DIALOG.input(
        "Profile Name",
        defaultt=default_name
    ).strip()

    if not name:
        return

    data = profiles.load(REGISTRY)

    profile = {
        "id": profiles.make_id(profile_type),
        "name": name,
        "type": profile_type,
        "path": selected_path,
        "enabled": True,
    }

    data = profiles.upsert(
        data,
        profile
    )

    #
    # First profile becomes selected automatically.
    #
    if not profiles.selected_profile(data):
        data = profiles.set_selected(
            data,
            profile["id"]
        )

    profiles.save(
        REGISTRY,
        data
    )

    DIALOG.notification(
        "Kodi VPN Manager",
        "Added: {}".format(name),
        xbmcgui.NOTIFICATION_INFO,
        3000
    )


def remove_profile():
    data = profiles.load(REGISTRY)
    available = profiles.profiles(data)

    if not available:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No managed VPN profiles are configured."
        )
        return

    current = profiles.selected_profile(data)

    labels = []

    for profile in available:
        prefix = (
            "✓ "
            if current
            and profile["id"] == current["id"]
            else ""
        )

        labels.append(
            "{}{} [{}]".format(
                prefix,
                profile["name"],
                profile["type"].upper(),
            )
        )

    choice = DIALOG.select(
        "Remove VPN Profile",
        labels
    )

    if choice < 0:
        return

    profile = available[choice]

    if not DIALOG.yesno(
        "Kodi VPN Manager",
        "Remove profile '{}' ?".format(
            profile["name"]
        )
    ):
        return

    data = profiles.remove(
        data,
        profile["id"]
    )

    profiles.save(
        REGISTRY,
        data
    )

    DIALOG.notification(
        "Kodi VPN Manager",
        "Removed: {}".format(
            profile["name"]
        ),
        xbmcgui.NOTIFICATION_INFO,
        3000
    )


def can_manage(profile):
    if not CAPABILITIES["can_manage"]:
        return False

    checker = getattr(
        BACKEND,
        "can_manage_profile",
        None
    )

    if not checker:
        return False

    return bool(checker(profile))


def show_result(title, result):
    if not isinstance(result, dict):
        DIALOG.ok(
            title,
            str(result)
        )
        return

    ok = bool(result.get("ok"))

    message = result.get(
        "message",
        "Completed" if ok else "Failed"
    )

    state = result.get("state")

    if state:
        message += "\n\nState: {}".format(
            state
        )

    DIALOG.ok(
        title,
        message
    )


def connect_selected():
    data, profile = selected_profile()

    if not profile:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No VPN profile is selected."
        )
        return

    if not can_manage(profile):
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform cannot manage the selected profile."
        )
        return

    connector = getattr(
        BACKEND,
        "connect",
        None
    )

    if not connector:
        return

    result = connector(profile)

    show_result(
        "VPN Connection",
        result
    )

    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )


def disconnect_selected():
    data, profile = selected_profile()

    if not profile:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No VPN profile is selected."
        )
        return

    if not can_manage(profile):
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform cannot manage the selected profile."
        )
        return

    disconnect = getattr(
        BACKEND,
        "disconnect",
        None
    )

    if not disconnect:
        return

    result = disconnect(profile)

    show_result(
        "VPN Disconnect",
        result
    )

    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )



def disable_protection_selected():
    disable = getattr(
        BACKEND,
        "disable_protection",
        None
    )

    if not disable:
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform does not support disabling managed VPN protection."
        )
        return

    confirmed = DIALOG.yesno(
        "Disable VPN Protection",
        (
            "This will stop the managed VPN, disable the kill switch "
            "and DNS lock, and restore normal Internet access.\n\n"
            "Continue?"
        )
    )

    if not confirmed:
        return

    result = disable()

    show_result(
        "VPN Protection",
        result
    )

    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )


def publish_dashboard_properties():
    data, selected = selected_profile()

    WINDOW.setProperty(
        "VPNManager.Platform",
        CAPABILITIES["name"]
    )

    WINDOW.setProperty(
        "VPNManager.Mode",
        CAPABILITIES["mode"].title()
    )

    WINDOW.setProperty(
        "VPNManager.SelectedProfile",
        profile_name(selected)
    )


class DashboardWindow(xbmcgui.WindowXMLDialog):
    REFRESH_BUTTON = 100
    SETTINGS_BUTTON = 101
    CHANGE_PROFILE_BUTTON = 102
    BACK_ACTIONS = (9, 10, 92)

    def onInit(self):
        publish_dashboard_properties()
        self.setFocusId(self.REFRESH_BUTTON)

    def onClick(self, control_id):
        if control_id == self.REFRESH_BUTTON:
            WINDOW.setProperty(
                "VPNManager.RefreshVPN",
                "1"
            )

        elif control_id == self.SETTINGS_BUTTON:
            ADDON.openSettings()
            publish_dashboard_properties()

        elif control_id == self.CHANGE_PROFILE_BUTTON:
            choose_profile()
            publish_dashboard_properties()

    def onAction(self, action):
        if action.getId() in self.BACK_ACTIONS:
            self.close()


def main():
    publish_dashboard_properties()

    dashboard = DashboardWindow(
        "VPNManagerDashboard.xml",
        ADDON.getAddonInfo("path"),
        "Default",
        "720p"
    )

    dashboard.doModal()
    del dashboard


if __name__ == "__main__":
    main()
