#!/bin/sh

OVPN_SERVICE="vpn-manager-openvpn.service"
KILLSWITCH="/storage/.config/openvpn-killswitch.sh"
BOOTGUARD="/storage/.config/vpn-bootstrap-guard.sh"
DNSLOCK="/storage/.config/openvpn-dns-lock.sh"
IPT="/usr/sbin/iptables"

STATE_FILE="/run/vpn-selector.state"
UPSTREAM_IP_FILE="/run/vpn-selector.upstream-ip"

get_lan_interface()
{
    LANIF="$(ip -4 route show table main default 2>/dev/null |
        awk '/^default / {
            for (i=1;i<=NF;i++)
                if ($i=="dev") { print $(i+1); exit }
        }')"

    [ -n "$LANIF" ]
}

get_current_path()
{
    if systemctl is-active --quiet "$OVPN_SERVICE" &&
       ip route get 1.1.1.1 2>/dev/null | grep -q 'dev tun0'; then
        echo local
        return
    fi

    SAVED="$(cat "$STATE_FILE" 2>/dev/null)"

    if [ "$SAVED" = "router" ]; then
        echo router
    else
        echo unknown
    fi
}

get_upstream_ip()
{
    curl --interface "$LANIF" -4fsS \
        --connect-timeout 5 --max-time 10 \
        https://api.ipify.org 2>/dev/null
}

check_iplogs()
{
    DATA="$(curl --interface "$LANIF" -4fsS \
        --connect-timeout 5 --max-time 10 \
        -X POST https://iplogs.com/v1/check \
        -H 'Content-Type: application/json' \
        -d '{}' 2>/dev/null |
        tr -d '[:space:]')" || {
            echo X
            return
        }

    printf '%s' "$DATA" | grep -Fq "\"ip\":\"$UPIP\"" || {
        echo X
        return
    }

    if printf '%s' "$DATA" | grep -Fq '"is_vpn":true' &&
       printf '%s' "$DATA" | grep -Fq '"verdict":"vpn_detected"'; then
        echo 1
    elif printf '%s' "$DATA" | grep -Fq '"is_vpn":false'; then
        echo 0
    else
        echo X
    fi
}

check_proxycheck()
{
    DATA="$(curl --interface "$LANIF" -4fsS \
        --connect-timeout 5 --max-time 10 \
        "https://proxycheck.io/v2/$UPIP?vpn=2" 2>/dev/null |
        tr -d '[:space:]')" || {
            echo X
            return
        }

    printf '%s' "$DATA" | grep -Fq '"status":"ok"' || {
        echo X
        return
    }

    if printf '%s' "$DATA" | grep -Fq '"proxy":"yes"' &&
       printf '%s' "$DATA" | grep -Fq '"type":"VPN"'; then
        echo 1
    elif printf '%s' "$DATA" | grep -Fq '"proxy":"no"'; then
        echo 0
    else
        echo X
    fi
}

# SELECTOR_REDESIGN_V1

start_local_probe()
{
    DETECTOR_IPS="$(
        {
            getent ahostsv4 api.ipify.org 2>/dev/null
            getent ahostsv4 iplogs.com 2>/dev/null
            getent ahostsv4 proxycheck.io 2>/dev/null
        } | awk '/^[0-9]+\./ && !seen[$1]++ {print $1}'
    )"

    [ -n "$DETECTOR_IPS" ] || return 1

    $IPT -N CE_VPN_PROBE 2>/dev/null || true
    $IPT -F CE_VPN_PROBE

    while $IPT -D OUTPUT -j CE_VPN_PROBE 2>/dev/null; do :; done

    for IP in $DETECTOR_IPS; do
        $IPT -A CE_VPN_PROBE -o "$LANIF" \
            -d "$IP" -p tcp --dport 443 -j ACCEPT
    done

    $IPT -A CE_VPN_PROBE -j RETURN
    $IPT -I OUTPUT 1 -j CE_VPN_PROBE
}

stop_local_probe()
{
    while $IPT -D OUTPUT -j CE_VPN_PROBE 2>/dev/null; do :; done
    $IPT -F CE_VPN_PROBE 2>/dev/null || true
    $IPT -X CE_VPN_PROBE 2>/dev/null || true
}

verify_upstream()
{
    echo "Running full VPN verification..."

    IPLOGS="$(check_iplogs)"
    PROXYCHECK="$(check_proxycheck)"

    echo "IPLogs VPN:     $IPLOGS"
    echo "Proxycheck VPN: $PROXYCHECK"

    [ "$IPLOGS" = "1" ] && [ "$PROXYCHECK" = "1" ]
}

keep_local()
{
    printf '%s\n' local > "$STATE_FILE"

    if [ -n "$UPIP" ]; then
        printf '%s\n' "$UPIP" > "$UPSTREAM_IP_FILE"
    fi

    echo "Keeping local OpenVPN protection."
    exit 0
}

use_router()
{
    echo "UPSTREAM VPN CONFIRMED"

    if systemctl is-active --quiet "$OVPN_SERVICE"; then
        echo "Stopping unnecessary local managed OpenVPN..."
        systemctl stop "$OVPN_SERVICE"
    fi

    "$DNSLOCK" unlock 2>/dev/null || true
    "$KILLSWITCH" down 2>/dev/null || true
    "$BOOTGUARD" down

    printf '%s\n' router > "$STATE_FILE"
    printf '%s\n' "$UPIP" > "$UPSTREAM_IP_FILE"

    echo "Using router/upstream VPN."
    exit 0
}

use_local()
{
    printf '%s\n' failed > "$STATE_FILE"

    echo "Upstream VPN not confirmed."
    echo "Preparing local OpenVPN fail-closed protection..."

    if ! systemctl is-active --quiet "$OVPN_SERVICE"; then
        "$DNSLOCK" unlock 2>/dev/null || true
    fi

    "$KILLSWITCH" up || {
        echo "ERROR: Could not activate OpenVPN kill switch."
        echo "Bootstrap guard remains ACTIVE."
        exit 1
    }

    "$BOOTGUARD" down

    if systemctl is-active --quiet "$OVPN_SERVICE"; then
        echo "Local managed OpenVPN already running."
    else
        echo "Starting local managed OpenVPN fallback..."
        systemctl start "$OVPN_SERVICE"
    fi

    COUNT=0

    while [ "$COUNT" -lt 30 ]; do
        if systemctl is-active --quiet "$OVPN_SERVICE" &&
           ip route get 1.1.1.1 2>/dev/null | grep -q 'dev tun0'; then

            "$DNSLOCK" lock || {
                echo "ERROR: Could not lock DNS to the VPN tunnel."
                echo "OpenVPN kill switch remains active."
                exit 1
            }

            "$KILLSWITCH" up || {
                echo "ERROR: Could not rebuild kill switch after DNS lock."
                exit 1
            }

            printf '%s\n' local > "$STATE_FILE"
            printf '%s\n' "$UPIP" > "$UPSTREAM_IP_FILE"

            echo "LOCAL OPENVPN ACTIVE"
            exit 0
        fi

        COUNT=$((COUNT + 1))
        sleep 1
    done

    printf '%s\n' failed > "$STATE_FILE"

    echo "ERROR: Local OpenVPN failed to become the Internet route."
    echo "OpenVPN kill switch remains ACTIVE -- WAN stays blocked."
    exit 1
}


if ! get_lan_interface; then
    printf '%s\n' failed > "$STATE_FILE"
    echo "ERROR: Could not determine physical Internet interface."
    exit 1
fi

CURRENT="$(get_current_path)"
LASTIP="$(cat "$UPSTREAM_IP_FILE" 2>/dev/null)"

echo "Physical Internet interface: $LANIF"
echo "Current VPN path: $CURRENT"

#
# LOCAL MODE
# Keep the working tunnel and kill switch intact.
# Resolve detector hosts through VPN DNS, then temporarily permit
# only those HTTPS probes on the physical interface.
#
if [ "$CURRENT" = "local" ]; then
    echo "Checking whether router/upstream VPN has returned..."

    if ! start_local_probe; then
        echo "WARNING: Could not prepare safe upstream probe."
        keep_local
    fi

    trap 'stop_local_probe' 0 2 15

    UPIP="$(get_upstream_ip)"

    if [ -z "$UPIP" ]; then
        echo "Physical upstream IP unavailable; keeping local VPN."
        stop_local_probe
        trap - 0 2 15
        keep_local
    fi

    echo "Physical upstream IP: $UPIP"
    echo "Previous upstream IP: ${LASTIP:-unknown}"

    if [ -n "$LASTIP" ] && [ "$UPIP" = "$LASTIP" ]; then
        echo "Physical upstream IP unchanged."
        stop_local_probe
        trap - 0 2 15
        keep_local
    fi

    if verify_upstream; then
        stop_local_probe
        trap - 0 2 15
        use_router
    fi

    stop_local_probe
    trap - 0 2 15
    keep_local
fi

#
# ROUTER MODE
# Do not install the bootstrap firewall merely to verify an
# already-established router/upstream VPN.
#
if [ "$CURRENT" = "router" ]; then
    UPIP="$(get_upstream_ip)"

    if [ -z "$UPIP" ]; then
        echo "ERROR: Physical upstream IP unavailable."
        use_local
    fi

    echo "Physical upstream IP: $UPIP"
    echo "Previous upstream IP: ${LASTIP:-unknown}"

    if [ -n "$LASTIP" ] && [ "$UPIP" = "$LASTIP" ]; then
        echo "Upstream IP unchanged; keeping verified router VPN."
        "$KILLSWITCH" down 2>/dev/null || true
        "$BOOTGUARD" down 2>/dev/null || true
        printf '%s\n' router > "$STATE_FILE"
        exit 0
    fi

    echo "Upstream IP changed."

    if verify_upstream; then
        use_router
    fi

    use_local
fi

#
# UNKNOWN / STARTUP MODE
# This is where bootstrap fail-close belongs: before we know
# whether any trusted VPN path exists.
#
printf '%s\n' failed > "$STATE_FILE"

echo "VPN path unknown; activating bootstrap protection."

"$BOOTGUARD" up || {
    echo "ERROR: Bootstrap guard could not initialize."
    echo "WAN remains blocked if guard rules were installed."
    exit 1
}

UPIP="$(get_upstream_ip)"

if [ -z "$UPIP" ]; then
    echo "ERROR: Could not determine physical upstream public IP."
    use_local
fi

echo "Physical upstream IP: $UPIP"
echo "Previous upstream IP: ${LASTIP:-unknown}"

if verify_upstream; then
    use_router
fi

use_local
