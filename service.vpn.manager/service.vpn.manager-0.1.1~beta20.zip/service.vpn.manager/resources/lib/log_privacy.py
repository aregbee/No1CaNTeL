import ipaddress
import re

import xbmc
import xbmcaddon


SETTING_ID = "debug_show_full_ip_logs"

_IPV4_RE = re.compile(
    r"(?<![\w.])"
    r"((?:\d{1,3}\.){3}\d{1,3})"
    r"(?![\w.])"
)

_IPV6_RE = re.compile(
    r"(?<![0-9A-Fa-f:])"
    r"((?:[0-9A-Fa-f]{0,4}:){2,7}"
    r"[0-9A-Fa-f]{0,4})"
    r"(?![0-9A-Fa-f:])"
)


def _addon():
    return xbmcaddon.Addon(
        "service.vpn.manager"
    )


def reset_full_ip_logging():
    addon = _addon()

    try:
        addon.setSettingBool(
            SETTING_ID,
            False,
        )

    except Exception:
        addon.setSetting(
            SETTING_ID,
            "false",
        )



def _mask_ipv6(match):
    value = match.group(1)

    try:
        address = ipaddress.ip_address(
            value
        )
    except ValueError:
        return value

    if address.version != 6:
        return value

    first = (
        address.exploded
        .split(":", 1)[0]
        .lstrip("0")
        or "0"
    )

    return (
        first
        + ":x:x:x:x:x:x:x"
    )


def _mask_ipv4(match):
    value = match.group(1)

    try:
        address = ipaddress.ip_address(
            value
        )
    except ValueError:
        return value

    if address.version != 4:
        return value

    first = value.split(".", 1)[0]

    return "{}.x.x.x".format(
        first
    )


def redact_ips(message):
    text = str(message)

    text = _IPV6_RE.sub(
        _mask_ipv6,
        text,
    )

    text = _IPV4_RE.sub(
        _mask_ipv4,
        text,
    )

    return text


def install_log_filter():
    current = xbmc.log

    if getattr(
        current,
        "_vpn_manager_privacy_filter",
        False,
    ):
        return

    original = current

    def filtered_log(
        message,
        level=xbmc.LOGDEBUG,
    ):
        original(
            redact_ips(message),
            level,
        )

    filtered_log._vpn_manager_privacy_filter = True
    filtered_log._vpn_manager_original = original

    xbmc.log = filtered_log
