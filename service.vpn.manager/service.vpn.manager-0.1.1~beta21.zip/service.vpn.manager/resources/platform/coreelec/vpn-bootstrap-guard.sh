#!/bin/sh

IPT=/usr/sbin/iptables
IP6T=/usr/sbin/ip6tables
LAUNCHER="/storage/.config/vpn-manager-openvpn-launcher.py"
NTP_PEERS_FILE="/run/vpn-bootstrap-ntp.peers"

case "$1" in
  up)
    LANIF="$(ip -4 route show table main default 2>/dev/null |
        awk '/^default / {
            for (i=1;i<=NF;i++)
                if ($i=="dev") { print $(i+1); exit }
        }')"

    [ -n "$LANIF" ] || {
        echo "ERROR: Cannot determine physical network interface"
        exit 1
    }

    LAN="$(ip -4 route show table main dev "$LANIF" scope link 2>/dev/null |
        awk '$1 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\/[0-9]+$/ {
            print $1; exit
        }')"

    DNSIP="$(awk '/^nameserver[[:space:]]+/ {print $2; exit}' /etc/resolv.conf)"

    [ -n "$LAN" ] || {
        echo "ERROR: Cannot determine LAN subnet"
        exit 1
    }

    [ -n "$DNSIP" ] || {
        echo "ERROR: Cannot determine DNS resolver"
        exit 1
    }

    echo "Bootstrap guard:"
    echo " interface=$LANIF"
    echo " LAN=$LAN"
    echo " DNS=$DNSIP"

    # Bootstrap whitelist rules deliberately use ACCEPT rather than
    # RETURN. CE_VPN_BOOT is inserted at the top of OUTPUT and may
    # coexist temporarily with an older fail-closed chain. RETURN
    # would allow a whitelisted packet to fall through into that older
    # chain and be rejected, preventing DNS/NTP/VPN recovery.

    # ---------- IPv4 ----------
    $IPT -N CE_VPN_BOOT 2>/dev/null || true
    $IPT -F CE_VPN_BOOT

    while $IPT -D OUTPUT -j CE_VPN_BOOT 2>/dev/null; do :; done

    $IPT -A CE_VPN_BOOT -o lo -j ACCEPT
    $IPT -A CE_VPN_BOOT -o "$LANIF" -d "$LAN" -j ACCEPT

    # DHCP
    $IPT -A CE_VPN_BOOT -o "$LANIF" \
        -p udp --sport 68 --dport 67 -j ACCEPT

    # DNS required to resolve detector/OpenVPN hosts
    $IPT -A CE_VPN_BOOT -o "$LANIF" \
        -d "$DNSIP" -p udp --dport 53 -j ACCEPT
    $IPT -A CE_VPN_BOOT -o "$LANIF" \
        -d "$DNSIP" -p tcp --dport 53 -j ACCEPT

    # Selected OpenVPN transport is added after the
    # fail-closed chain is attached, so DNS resolution can
    # occur while all unrelated WAN traffic remains blocked.

    # Permit traffic once local OpenVPN creates tun0
    $IPT -A CE_VPN_BOOT -o tun0 -j ACCEPT

    # Everything else blocked until VPN decision is made
    $IPT -A CE_VPN_BOOT -j REJECT

    $IPT -I OUTPUT 1 -j CE_VPN_BOOT

    # --------------------------------------------------------
    # Time bootstrap
    #
    # OpenVPN certificate validation requires a sane clock.
    # The fail-closed chain is already attached here.
    #
    # DNS is permitted by the rules above. Resolve the system
    # NTP configuration, then permit UDP/123 ONLY to those
    # resolved IPv4 addresses.
    # --------------------------------------------------------

    NTP_HOSTS="$(
        awk '
            /^[[:space:]]*(server|pool)[[:space:]]+/ {
                print $2
            }
        ' /etc/ntp.conf 2>/dev/null
    )"

    [ -n "$NTP_HOSTS" ] || {
        NTP_HOSTS="pool.ntp.org"
    }

    : > "$NTP_PEERS_FILE" || {
        echo "ERROR: Cannot create bootstrap NTP peer file."
        exit 1
    }

    chmod 600 "$NTP_PEERS_FILE" 2>/dev/null || true

    for NTPHOST in $NTP_HOSTS; do

        if echo "$NTPHOST" |
            grep -Eq '^[0-9]+(\.[0-9]+){3}$'; then

            NTPIPS="$NTPHOST"

        else

            NTPIPS="$(
                getent ahostsv4 "$NTPHOST" 2>/dev/null |
                    awk '
                        $1 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ {
                            print $1
                        }
                    ' |
                    sort -u
            )"
        fi

        for NTPIP in $NTPIPS; do

            grep -qxF "$NTPIP" \
                "$NTP_PEERS_FILE" 2>/dev/null ||
                echo "$NTPIP" >> "$NTP_PEERS_FILE"

        done
    done

    [ -s "$NTP_PEERS_FILE" ] || {
        echo "ERROR: Could not resolve an NTP peer."
        echo "Bootstrap guard remains ACTIVE."
        exit 1
    }

    while IFS= read -r NTPIP; do

        [ -n "$NTPIP" ] || continue

        $IPT -I CE_VPN_BOOT 1 \
            -o "$LANIF" \
            -d "$NTPIP" \
            -p udp \
            --dport 123 \
            -j ACCEPT || exit 1

    done < "$NTP_PEERS_FILE"

    echo "Bootstrap NTP peers:"
    sed 's/^/  /' "$NTP_PEERS_FILE"

    TRANSPORTS="$("$LAUNCHER" --transport 2>/dev/null)" || {
        echo "ERROR: Cannot determine selected VPN transport."
        echo "Bootstrap guard remains ACTIVE."
        exit 1
    }

    [ -n "$TRANSPORTS" ] || {
        echo "ERROR: Selected VPN profile has no transport."
        echo "Bootstrap guard remains ACTIVE."
        exit 1
    }

    echo " VPN transport(s):"
    printf '%s\n' "$TRANSPORTS" | sed 's/^/  /'

    while IFS='|' read -r VPNHOST VPNPORT VPNPROTO; do
        [ -n "$VPNHOST" ] || continue
        [ -n "$VPNPORT" ] || {
            echo "ERROR: Missing VPN transport port."
            exit 1
        }

        case "$VPNPROTO" in
            tcp*) VPNPROTO="tcp" ;;
            udp*) VPNPROTO="udp" ;;
            *)
                echo "ERROR: Unsupported VPN protocol: $VPNPROTO"
                exit 1
                ;;
        esac

        if echo "$VPNHOST" |
            grep -Eq '^[0-9]+(\.[0-9]+){3}$'; then
            VPNIPS="$VPNHOST"
        else
            VPNIPS="$(getent ahostsv4 "$VPNHOST" 2>/dev/null |
                awk '{print $1}' | sort -u)"
        fi

        [ -n "$VPNIPS" ] || {
            echo "ERROR: Cannot resolve VPN endpoint: $VPNHOST"
            echo "Bootstrap guard remains ACTIVE."
            exit 1
        }

        for VPNIP in $VPNIPS; do
            $IPT -I CE_VPN_BOOT 1 -o "$LANIF" \
                -d "$VPNIP" -p "$VPNPROTO" \
                --dport "$VPNPORT" -j ACCEPT || exit 1
        done
    done <<EOF
$TRANSPORTS
EOF

    # Resolve detector hosts while DNS is the only WAN service permitted.
    DETECTOR_IPS="$(
        {
            getent ahostsv4 api.ipify.org 2>/dev/null
            getent ahostsv4 iplogs.com 2>/dev/null
            getent ahostsv4 proxycheck.io 2>/dev/null
        } | awk '/^[0-9]+\./ && !seen[$1]++ {print $1}'
    )"

    [ -n "$DETECTOR_IPS" ] || {
        echo "ERROR: Could not resolve VPN detector hosts."
        echo "Bootstrap guard remains ACTIVE."
        exit 1
    }

    # Allow HTTPS only to the resolved detector endpoints.
    for IP in $DETECTOR_IPS; do
        $IPT -I CE_VPN_BOOT 1 -o "$LANIF" \
            -d "$IP" -p tcp --dport 443 -j ACCEPT
        echo " detector=$IP"
    done


    # ---------- IPv6 ----------
    # Local PureVPN profile is IPv4-only, so don't permit IPv6 WAN fallback.
    $IP6T -N CE_VPN_BOOT6 2>/dev/null || true
    $IP6T -F CE_VPN_BOOT6

    while $IP6T -D OUTPUT -j CE_VPN_BOOT6 2>/dev/null; do :; done

    $IP6T -A CE_VPN_BOOT6 -o lo -j ACCEPT
    $IP6T -A CE_VPN_BOOT6 -d fe80::/10 -j ACCEPT
    $IP6T -A CE_VPN_BOOT6 -d ff00::/8 -j ACCEPT
    $IP6T -A CE_VPN_BOOT6 -j REJECT

    $IP6T -I OUTPUT 1 -j CE_VPN_BOOT6
    ;;

  down)
    rm -f "$NTP_PEERS_FILE"

    while $IPT -D OUTPUT -j CE_VPN_BOOT 2>/dev/null; do :; done
    $IPT -F CE_VPN_BOOT 2>/dev/null || true
    $IPT -X CE_VPN_BOOT 2>/dev/null || true

    while $IP6T -D OUTPUT -j CE_VPN_BOOT6 2>/dev/null; do :; done
    $IP6T -F CE_VPN_BOOT6 2>/dev/null || true
    $IP6T -X CE_VPN_BOOT6 2>/dev/null || true
    ;;

  *)
    echo "Usage: $0 {up|down}"
    exit 1
    ;;
esac
