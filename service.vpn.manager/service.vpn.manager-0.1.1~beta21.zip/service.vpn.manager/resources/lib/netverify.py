import json
import shutil
import subprocess
import urllib.error
import urllib.request


CURL = shutil.which("curl")


def _run(args, timeout=12):
    if not args or not args[0]:
        return ""

    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=timeout
        )

        if result.returncode == 0:
            return result.stdout.strip()

    except Exception:
        pass

    return ""


def _urllib_fetch(url, post=False, timeout=10):
    try:
        data = b"{}" if post else None

        request = urllib.request.Request(
            url,
            data=data,
            headers={
                "User-Agent": "Kodi-VPN-Manager/0.1",
                "Accept": "application/json,text/plain,*/*",
            },
            method="POST" if post else "GET",
        )

        if post:
            request.add_header(
                "Content-Type",
                "application/json"
            )

        with urllib.request.urlopen(
            request,
            timeout=timeout
        ) as response:
            return response.read().decode(
                "utf-8",
                errors="replace"
            ).strip()

    except Exception:
        return ""


def fetch(url, interface=None, post=False):
    #
    # Binding to a specific interface is primarily useful on Linux
    # when checking upstream connectivity independently of a local
    # VPN tunnel. urllib cannot do that portably, so use curl when
    # interface binding is explicitly requested.
    #
    if interface and CURL:
        args = [
            CURL,
            "-4fsS",
            "--connect-timeout", "5",
            "--max-time", "10",
            "--interface", interface,
        ]

        if post:
            args.extend([
                "-X", "POST",
                "-H", "Content-Type: application/json",
                "-d", "{}",
            ])

        args.append(url)

        return _run(args)

    #
    # Portable path for Android, Windows, Linux and CoreELEC.
    #
    value = _urllib_fetch(
        url,
        post=post
    )

    if value:
        return value

    #
    # Fallback for appliance environments where Python HTTPS
    # certificate handling may be incomplete.
    #
    if CURL:
        args = [
            CURL,
            "-4fsS",
            "--connect-timeout", "5",
            "--max-time", "10",
        ]

        if post:
            args.extend([
                "-X", "POST",
                "-H", "Content-Type: application/json",
                "-d", "{}",
            ])

        args.append(url)

        return _run(args)

    return ""


def json_data(text):
    try:
        return json.loads(text)
    except Exception:
        return None


def _boolish(value):
    if isinstance(value, bool):
        return value

    if isinstance(value, (int, float)):
        return bool(value)

    if isinstance(value, str):
        value = value.strip().lower()

        if value in ("true", "yes", "1"):
            return True

        if value in ("false", "no", "0"):
            return False

    return None


def public_ip(interface=None):
    value = fetch(
        "https://api.ipify.org",
        interface=interface
    )

    return value if value else "Unavailable"


def external_vpn_check(
    interface=None,
    requested_city="",
    requested_country="",
    requested_country_code="",
):
    first = json_data(
        fetch(
            "https://api.ipapi.is/",
            interface=interface
        )
    )

    second = json_data(
        fetch(
            "https://iplogs.com/v1/check",
            interface=interface,
            post=True
        )
    )

    third = json_data(
        fetch(
            "https://ipinfo.io/json",
            interface=interface
        )
    )

    detector1 = None
    detector2 = None
    pub = "Unavailable"

    if isinstance(first, dict):
        if first.get("ip"):
            pub = str(first["ip"])

        if "is_vpn" in first:
            detector1 = _boolish(
                first.get("is_vpn")
            )

    if isinstance(second, dict):
        raw = _boolish(
            second.get("is_vpn")
        )

        verdict = str(
            second.get("verdict", "")
        ).lower()

        if raw is not None:
            detector2 = (
                raw
                and verdict == "vpn_detected"
            )

    if (
        pub == "Unavailable"
        and isinstance(third, dict)
        and third.get("ip")
    ):
        pub = str(
            third.get("ip")
        ).strip()

    if pub == "Unavailable":
        pub = public_ip(interface)

    detectors = [
        value
        for value in (
            detector1,
            detector2,
        )
        if value is not None
    ]

    positive = sum(
        value is True
        for value in detectors
    )

    negative = sum(
        value is False
        for value in detectors
    )

    #
    # Only count detectors that actually returned a verdict.
    # One positive response plus one unavailable service is
    # not a disagreement.
    #
    if detectors and positive == len(detectors):
        verdict = "vpn"

    elif detectors and negative == len(detectors):
        verdict = "not_detected"

    elif positive and negative:
        verdict = "probable_vpn"

    else:
        verdict = "unknown"

    #
    # Exit-node metadata.
    #
    # Location:
    #   Use 2-of-3 consensus from:
    #     1. IPinfo
    #     2. api.ipapi.is
    #     3. IPLogs
    #
    # If no two sources agree, use:
    #   IPinfo -> api.ipapi.is -> IPLogs
    #
    # Network:
    #   Keep IPLogs preferred for ASN/organization data.
    #
    exit_info = {}

    second_info = {}

    if isinstance(second, dict):
        candidate = second.get(
            "ip_info"
        )

        if isinstance(candidate, dict):
            second_info = candidate


    ipinfo = (
        third
        if isinstance(third, dict)
        else {}
    )

    ipapi = (
        first
        if isinstance(first, dict)
        else {}
    )

    iplogs = second_info


    def geo_text(value):
        return str(
            value or ""
        ).strip()


    def geo_normalize(value):
        import unicodedata

        value = geo_text(
            value
        ).casefold()

        value = unicodedata.normalize(
            "NFKD",
            value,
        )

        value = "".join(
            char
            for char in value
            if not unicodedata.combining(
                char
            )
        )

        cleaned = []

        for char in value:
            if char.isalnum():
                cleaned.append(char)
            else:
                cleaned.append(" ")

        return " ".join(
            "".join(cleaned).split()
        )


    def geo_region(source):
        if not isinstance(source, dict):
            return ""

        return geo_text(
            source.get("region")
            or source.get("state")
            or source.get("province")
        )


    def geo_country_code(source):
        if not isinstance(source, dict):
            return ""

        value = geo_text(
            source.get(
                "country_code"
            )
        )

        if not value:
            candidate = geo_text(
                source.get(
                    "country"
                )
            )

            if (
                len(candidate) == 2
                and candidate.isalpha()
            ):
                value = candidate

        return value.upper()


    def geo_country_name(source):
        if not isinstance(source, dict):
            return ""

        value = geo_text(
            source.get(
                "country_name"
            )
        )

        if value:
            return value

        value = geo_text(
            source.get(
                "country"
            )
        )

        if (
            len(value) == 2
            and value.isalpha()
        ):
            return ""

        return value


    def geo_majority(values):
        groups = {}

        for source_name, value in values.items():
            value = geo_text(
                value
            )

            if not value:
                continue

            key = geo_normalize(
                value
            )

            if not key:
                continue

            groups.setdefault(
                key,
                [],
            ).append(
                (
                    source_name,
                    value,
                )
            )

        #
        # Any 2-of-3 agreement wins.
        #
        for group in groups.values():
            if len(group) >= 2:
                for preferred in (
                    "ipinfo",
                    "ipapi",
                    "iplogs",
                ):
                    for source_name, value in group:
                        if source_name == preferred:
                            return value, len(group)

        #
        # No majority: fixed fallback order.
        #
        for preferred in (
            "ipinfo",
            "ipapi",
            "iplogs",
        ):
            value = geo_text(
                values.get(
                    preferred
                )
            )

            if value:
                return value, 1

        return "", 0


    def geo_record(name, source):
        return {
            "source": name,
            "city": geo_text(
                source.get("city")
            ),
            "region": geo_region(
                source
            ),
            "country":
                geo_country_name(
                    source
                ),
            "country_code":
                geo_country_code(
                    source
                ),
        }


    records = {
        "ipinfo":
            geo_record(
                "ipinfo",
                ipinfo,
            ),

        "ipapi":
            geo_record(
                "ipapi",
                ipapi,
            ),

        "iplogs":
            geo_record(
                "iplogs",
                iplogs,
            ),
    }

    source_order = (
        "ipinfo",
        "ipapi",
        "iplogs",
    )

    requested_city_key = (
        geo_normalize(
            requested_city
        )
    )

    requested_country_key = (
        geo_normalize(
            requested_country
        )
    )

    requested_country_code_key = (
        geo_text(
            requested_country_code
        ).upper()
    )


    def requested_match(
        record,
    ):
        if not requested_city_key:
            return False

        if not (
            requested_country_key
            or requested_country_code_key
        ):
            return False

        if (
            geo_normalize(
                record.get("city")
            )
            != requested_city_key
        ):
            return False

        name_match = (
            requested_country_key
            and geo_normalize(
                record.get(
                    "country"
                )
            )
            == requested_country_key
        )

        code_match = (
            requested_country_code_key
            and geo_text(
                record.get(
                    "country_code"
                )
            ).upper()
            == requested_country_code_key
        )

        return bool(
            name_match
            or code_match
        )


    requested_matches = [
        name
        for name in source_order
        if requested_match(
            records[name]
        )
    ]

    selected_source = ""
    selection_reason = ""
    consensus_votes = 0

    if requested_matches:
        selected_source = (
            requested_matches[0]
        )

        selection_reason = (
            "requested_location_match"
        )

        consensus_votes = len(
            requested_matches
        )

    else:
        groups = {}

        for name in source_order:
            record = records[name]

            city_key = (
                geo_normalize(
                    record.get("city")
                )
            )

            country_key = (
                geo_text(
                    record.get(
                        "country_code"
                    )
                ).upper()
                or geo_normalize(
                    record.get(
                        "country"
                    )
                )
            )

            if (
                city_key
                and country_key
            ):
                groups.setdefault(
                    (
                        city_key,
                        country_key,
                    ),
                    [],
                ).append(
                    name
                )

        for names in (
            groups.values()
        ):
            if len(names) >= 2:
                selected_source = next(
                    name
                    for name
                    in source_order
                    if name in names
                )

                selection_reason = (
                    "2_of_3_consensus"
                )

                consensus_votes = (
                    len(names)
                )

                break

    if not selected_source:
        for name in source_order:
            record = records[name]

            if any(
                record.get(key)
                for key in (
                    "city",
                    "region",
                    "country",
                    "country_code",
                )
            ):
                selected_source = (
                    name
                )

                selection_reason = (
                    "provider_priority"
                )

                consensus_votes = 1

                break

    selected = records.get(
        selected_source,
        {},
    )

    city = geo_text(
        selected.get("city")
    )

    region = geo_text(
        selected.get("region")
    )

    country = geo_text(
        selected.get("country")
    )

    country_code = geo_text(
        selected.get(
            "country_code"
        )
    ).upper()

    if (
        country_code
        and not country
        and requested_country_key
        and requested_country_code_key
        == country_code
    ):
        country = geo_text(
            requested_country
        )

    if (
        country_code
        and not country
    ):
        for name in source_order:
            record = records[name]

            if (
                geo_text(
                    record.get(
                        "country_code"
                    )
                ).upper()
                == country_code
            ):
                candidate = (
                    geo_text(
                        record.get(
                            "country"
                        )
                    )
                )

                if candidate:
                    country = candidate
                    break

    if city:
        exit_info[
            "city"
        ] = city

    if region:
        exit_info[
            "region"
        ] = region

    if country:
        exit_info[
            "country"
        ] = country

    if country_code:
        exit_info[
            "country_code"
        ] = country_code


    def component_votes(
        field,
    ):
        groups = {}

        for name in source_order:
            value = geo_normalize(
                records[name].get(
                    field
                )
            )

            if value:
                groups[value] = (
                    groups.get(
                        value,
                        0,
                    )
                    + 1
                )

        return max(
            groups.values(),
            default=0,
        )

    #
    # Network data.
    #
    # api.ipapi.is supplies fallback metadata.
    #
    for key in (
        "asn",
        "org",
        "organization",
        "isp",
    ):
        value = ipapi.get(
            key
        )

        if value:
            exit_info[
                key
            ] = value


    #
    # IPLogs remains preferred for ASN/network metadata.
    #
    for key in (
        "asn",
        "org",
        "organization",
        "isp",
    ):
        value = iplogs.get(
            key
        )

        if value:
            exit_info[
                key
            ] = value


    location_parts = []

    for value in (
        city,
        region,
        country,
    ):
        if (
            value
            and value.casefold()
            not in {
                item.casefold()
                for item in location_parts
            }
        ):
            location_parts.append(
                value
            )


    exit_location = (
        ", ".join(
            location_parts
        )
        if location_parts
        else "Unavailable"
    )


    location_consensus = {
        "selection_reason":
            selection_reason,

        "selected_source":
            selected_source,

        "votes":
            consensus_votes,

        "city_votes":
            component_votes(
                "city"
            ),

        "region_votes":
            component_votes(
                "region"
            ),

        "country_votes": (
            component_votes(
                "country_code"
            )
            or component_votes(
                "country"
            )
        ),

        "sources": 3,

        "requested_city":
            geo_text(
                requested_city
            ),

        "requested_country":
            geo_text(
                requested_country
            ),

        "requested_country_code":
            requested_country_code_key,

        "requested_match_sources":
            requested_matches,

        "source_locations": {
            name: {
                "city":
                    records[name].get(
                        "city",
                        "",
                    ),

                "region":
                    records[name].get(
                        "region",
                        "",
                    ),

                "country":
                    records[name].get(
                        "country",
                        "",
                    ),

                "country_code":
                    records[name].get(
                        "country_code",
                        "",
                    ),
            }

            for name
            in source_order
        },
    }

    asn = str(exit_info.get("asn") or "").strip()

    organization = str(
        exit_info.get("org")
        or exit_info.get("organization")
        or exit_info.get("isp")
        or ""
    ).strip()

    network_parts = []

    if asn:
        network_parts.append(asn)

    if organization and organization not in network_parts:
        network_parts.append(organization)

    exit_network = (
        " - ".join(network_parts)
        if network_parts
        else "Unavailable"
    )

    return {
        "public_ip": pub,
        "verdict": verdict,
        "detector1": detector1,
        "detector2": detector2,
        "detectors_responded": len(detectors),
        "detectors_positive": positive,
        "exit_location": exit_location,
        "exit_network": exit_network,
        "location_consensus": location_consensus,
    }


def merge_state(state, external):
    result = dict(state or {})
    external = external or {}

    verdict = external.get("verdict", "unknown")
    local_tunnel = bool(
        result.get("local_tunnel", False)
    )
    backend_verified = bool(
        result.get("backend_verified", False)
    )

    result["external_verdict"] = verdict

    #
    # Strong backend evidence remains authoritative.
    # External services are supplementary and may disagree.
    #
    if backend_verified:
        if verdict == "vpn":
            result["verification"] = (
                "{}; exit IP classified as VPN/proxy".format(
                    result.get("verification", "Backend verified")
                )
            )

        elif verdict == "probable_vpn":
            result["verification"] = (
                "{}; exit IP possibly classified as VPN/proxy".format(
                    result.get("verification", "Backend verified")
                )
            )

        elif verdict == "not_detected":
            result["verification"] = (
                "{}; exit IP not identified as VPN/proxy".format(
                    result.get("verification", "Backend verified")
                )
            )

        return result

    #
    # A local tunnel exists, but that alone does not prove
    # it is a privacy VPN. Android firewall/ad-blocking apps
    # may also create VPN-style tunnel interfaces.
    #
    if local_tunnel:
        if verdict == "vpn":
            result["status"] = "Protected"
            result["verification"] = (
                "Local tunnel route confirmed; exit IP classified as VPN/proxy"
            )

        elif verdict == "probable_vpn":
            result["status"] = "PROBABLE VPN"
            result["verification"] = (
                "Local tunnel detected; exit IP possibly classified as VPN/proxy"
            )

        elif verdict == "not_detected":
            result["status"] = (
                "TUNNEL ACTIVE - VPN NOT CONFIRMED"
            )
            result["verification"] = (
                "Local tunnel detected; exit IP not identified as VPN/proxy"
            )

        else:
            result["status"] = (
                "VPN TUNNEL ACTIVE - VERIFYING"
            )

        return result

    #
    # No local tunnel is visible. External detection can therefore
    # indicate a router/upstream VPN without requiring local control.
    #
    if verdict == "vpn":
        result.update({
            "path": "Router / upstream VPN",
            "status": "Protected",
            "server": "Upstream / externally detected",
            "killswitch": "Upstream-managed",
            "verification": "Exit IP classified as VPN/proxy",
        })

    elif verdict == "probable_vpn":
        result.update({
            "path": "Possible router / upstream VPN",
            "status": "PROBABLE VPN",
            "server": "Upstream / externally detected",
            "killswitch": "Upstream-managed",
            "verification": "Exit IP possibly classified as VPN/proxy",
        })

    elif verdict == "not_detected":
        result["status"] = "VPN NOT DETECTED"
        result["verification"] = (
            "No local tunnel; exit IP not identified as VPN/proxy"
        )

    return result
