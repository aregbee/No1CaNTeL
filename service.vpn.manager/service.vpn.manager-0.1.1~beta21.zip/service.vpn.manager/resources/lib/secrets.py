import json
import os
import tempfile
import time


SCHEMA_VERSION = 1

SUPPORTED_SECRET_TYPES = (
    "username_password",
    "token",
    "certificate",
    "private_key",
    "keypair",
    "generic",
)


def _default_data():
    return {
        "schema": SCHEMA_VERSION,
        "items": {},
    }


def _clean_ref(value):
    return str(value or "").strip()


def _clean_type(value):
    value = str(value or "generic").strip().lower()

    if value not in SUPPORTED_SECRET_TYPES:
        return "generic"

    return value


def _clean_values(value):
    if not isinstance(value, dict):
        return {}

    result = {}

    for key, item in value.items():
        key = str(key or "").strip()

        if not key:
            continue

        if item is None:
            result[key] = ""

        elif isinstance(
            item,
            (str, int, float, bool),
        ):
            result[key] = str(item)

    return result


def _normalize_item(item):
    if not isinstance(item, dict):
        return None

    secret_type = _clean_type(
        item.get("type")
    )

    values = _clean_values(
        item.get("values")
    )

    created = item.get(
        "created",
        time.time(),
    )

    updated = item.get(
        "updated",
        created,
    )

    try:
        created = float(created)
    except (TypeError, ValueError):
        created = time.time()

    try:
        updated = float(updated)
    except (TypeError, ValueError):
        updated = created

    return {
        "type": secret_type,
        "values": values,
        "created": created,
        "updated": updated,
    }


def _normalize_data(data):
    result = _default_data()

    if not isinstance(data, dict):
        return result

    raw_items = data.get(
        "items",
        {},
    )

    if not isinstance(raw_items, dict):
        return result

    for ref, raw in raw_items.items():
        ref = _clean_ref(ref)
        item = _normalize_item(raw)

        if not ref or not item:
            continue

        result["items"][ref] = item

    return result


def load(path):
    if not path or not os.path.exists(path):
        return _default_data()

    try:
        with open(
            path,
            "r",
            encoding="utf-8",
        ) as handle:
            data = json.load(handle)

    except (
        OSError,
        ValueError,
        TypeError,
    ):
        return _default_data()

    return _normalize_data(data)


def save(path, data):
    data = _normalize_data(data)

    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)

    fd, temp_path = tempfile.mkstemp(
        prefix=".secrets-",
        suffix=".tmp",
        dir=directory,
    )

    try:
        try:
            os.fchmod(fd, 0o600)
        except OSError:
            pass

        with os.fdopen(
            fd,
            "w",
            encoding="utf-8",
        ) as handle:

            json.dump(
                data,
                handle,
                indent=2,
                sort_keys=True,
            )

            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())

        try:
            os.chmod(
                temp_path,
                0o600,
            )
        except OSError:
            pass

        os.replace(
            temp_path,
            path,
        )

        try:
            os.chmod(
                path,
                0o600,
            )
        except OSError:
            pass

    finally:
        if os.path.exists(temp_path):
            try:
                os.unlink(temp_path)
            except OSError:
                pass

    return data


def get_secret(data, secret_ref):
    normalized = _normalize_data(data)
    secret_ref = _clean_ref(secret_ref)

    item = normalized[
        "items"
    ].get(secret_ref)

    if item is None:
        return None

    return {
        "type": item["type"],
        "values": dict(
            item["values"]
        ),
        "created": item["created"],
        "updated": item["updated"],
    }


def set_secret(
    data,
    secret_ref,
    secret_type,
    values,
):
    normalized = _normalize_data(data)

    secret_ref = _clean_ref(secret_ref)

    if not secret_ref:
        return normalized

    old = normalized[
        "items"
    ].get(secret_ref)

    now = time.time()

    normalized["items"][secret_ref] = {
        "type": _clean_type(
            secret_type
        ),
        "values": _clean_values(
            values
        ),
        "created": (
            old["created"]
            if old
            else now
        ),
        "updated": now,
    }

    return normalized


def remove_secret(
    data,
    secret_ref,
):
    normalized = _normalize_data(data)

    secret_ref = _clean_ref(
        secret_ref
    )

    normalized["items"].pop(
        secret_ref,
        None,
    )

    return normalized


