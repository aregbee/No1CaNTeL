import time
import socket
import os
import json
import re
import shutil
import subprocess

from resources.lib import profiles as profile_registry


BACKEND_ID = "linux"
BACKEND_NAME = "CoreELEC / Linux"
MODE = "manager"

CAN_MONITOR = True
CAN_MANAGE = True



IP = shutil.which("ip")
IPTABLES = shutil.which("iptables")

STATE_FILE = "/run/vpn-selector.state"

PROTECTION_DISABLED_FILE = (
    "/storage/.kodi/userdata/"
    "addon_data/service.vpn.manager/"
    "protection.disabled"
)

RUNTIME_TARGET_FILE = (
    "/run/vpn-manager-openvpn.target.json"
)

EFFECTIVE_OPENVPN_CONFIG = (
    "/run/vpn-manager-openvpn.effective.ovpn"
)


KILLSWITCH_SCRIPT = (
    "/storage/.config/openvpn-killswitch.sh"
)
OPENVPN_PROFILE = "/storage/.config/openvpn/purevpn.ovpn"
PROFILE_REGISTRY = (
    "/storage/.kodi/userdata/addon_data/"
    "service.vpn.manager/profiles.json"
)


def run(args, timeout=8):
    if not args or not args[0]:
        return ""

    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=timeout
        )

        if result.returncode == 0:
            return result.stdout.strip()

    except Exception:
        pass

    return ""


def lan_interface():
    if not IP:
        return ""

    data = run([
        IP, "-4", "route", "show",
        "table", "main", "default"
    ])

    for line in data.splitlines():
        parts = line.split()

        if "dev" in parts:
            try:
                return parts[parts.index("dev") + 1]
            except Exception:
                pass

    return ""


def internet_route():
    if not IP:
        return ""

    return run([IP, "-4", "route", "get", "1.1.1.1"])


def tunnel_ip():
    if not IP:
        return ""

    data = run([
        IP, "-4", "-o", "addr", "show",
        "dev", "tun0"
    ])

    match = re.search(r"\binet\s+([0-9.]+)/", data)

    return match.group(1) if match else ""


def tunnel_exists():
    return os.path.exists("/sys/class/net/tun0")


def kill_switch_active():
    if not IPTABLES:
        return False

    data = run([IPTABLES, "-S", "OUTPUT"])

    return "-A OUTPUT -j CE_OVPN_KS" in data


def selected_openvpn_path():
    try:
        data = profile_registry.load(
            PROFILE_REGISTRY
        )

        profile = profile_registry.selected_profile(
            data
        )

        if (
            profile
            and profile.get("enabled", True)
            and str(
                profile.get("type", "")
            ).lower() == "openvpn"
        ):
            profile_path = str(
                profile.get("path", "")
            ).strip()

            if profile_path:
                return profile_path

    except Exception:
        pass

    # Temporary compatibility fallback for the current installation.
    return OPENVPN_PROFILE


def configured_server():
    profile_path = selected_openvpn_path()

    try:
        with open(
            profile_path,
            "r",
            encoding="utf-8"
        ) as f:
            for line in f:
                parts = line.strip().split()

                if len(parts) >= 2 and parts[0] == "remote":
                    host = parts[1]

                    if len(parts) >= 3:
                        return "{}:{}".format(
                            host,
                            parts[2]
                        )

                    return host

    except Exception:
        pass

    return "N/A"


def protection_disabled():
    return os.path.exists(
        PROTECTION_DISABLED_FILE
    )


def _set_protection_disabled(
    disabled,
):
    directory = os.path.dirname(
        PROTECTION_DISABLED_FILE
    )

    os.makedirs(
        directory,
        exist_ok=True,
    )

    if disabled:
        temporary = (
            PROTECTION_DISABLED_FILE
            + ".tmp"
        )

        with open(
            temporary,
            "w",
            encoding="utf-8",
        ) as f:
            f.write("disabled\n")
            f.flush()
            os.fsync(f.fileno())

        os.chmod(
            temporary,
            0o600,
        )

        os.replace(
            temporary,
            PROTECTION_DISABLED_FILE,
        )

    else:
        try:
            os.remove(
                PROTECTION_DISABLED_FILE
            )
        except FileNotFoundError:
            pass


def selector_state():
    if protection_disabled():
        return "disabled"

    try:
        with open(
            STATE_FILE,
            "r",
            encoding="utf-8",
        ) as f:
            return f.read().strip()

    except Exception:
        return ""


SYSTEMCTL = shutil.which("systemctl")
SELECTOR_SERVICE = "vpn-selector.service"


def start_selector():
    if protection_disabled():
        # Deliberate user-disabled mode.
        # Never auto-reconnect from here.
        return 3

    if not SYSTEMCTL:
        return None

    try:
        result = subprocess.run(
            [
                SYSTEMCTL,
                "start",
                SELECTOR_SERVICE
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=45
        )

        return result.returncode

    except Exception:
        return None


def selector_service_state():
    if not SYSTEMCTL:
        return ""

    return run(
        [
            SYSTEMCTL,
            "is-active",
            SELECTOR_SERVICE
        ],
        timeout=2
    )


def vpn_state():
    route = internet_route()
    state = selector_state()
    iface = lan_interface() or "LAN"

    if state == "disabled":
        ks = kill_switch_active()

        return {
            "path": "Protection disabled",
            "status": "PROTECTION DISABLED",
            "interface": iface,
            "tunnel_ip": "N/A",
            "server": "None",
            "killswitch": (
                "Active"
                if ks
                else "INACTIVE"
            ),
            "verification":
                "Disabled by user",
            "selector_state": state,
            "local_tunnel":
                tunnel_exists(),
            "backend_verified": False,
        }

    local_routed = (
        tunnel_exists()
        and "dev tun0" in route
    )

    # Local OpenVPN is actually carrying Internet traffic.
    if local_routed:
        ks = kill_switch_active()

        return {
            "path": "Local OpenVPN",
            "status": (
                "Protected"
                if ks
                else "VPN ACTIVE - KILL SWITCH OFF"
            ),
            "interface": "tun0",
            "tunnel_ip": tunnel_ip() or "N/A",
            "server": configured_server(),
            "killswitch": "Active" if ks else "INACTIVE",
            "verification": "tun0 route confirmed",
            "selector_state": state,
            "local_tunnel": True,
            "backend_verified": True,
        }

    # Router/upstream VPN selected and verified.
    if state == "router":
        return {
            "path": "Router / upstream VPN",
            "status": "Protected",
            "interface": "Upstream ({})".format(iface),
            "tunnel_ip": "N/A",
            "server": "Router-managed",
            "killswitch": "Router-managed",
            "verification": "Selector verified",
            "selector_state": state,
            "local_tunnel": False,
            "backend_verified": True,
        }

    # Selector expected local VPN but tun0 is not routing Internet.
    if state == "local":
        ks = kill_switch_active()

        return {
            "path": "Local OpenVPN",
            "status": "ROUTE FAULT",
            "interface": iface,
            "tunnel_ip": "N/A",
            "server": configured_server(),
            "killswitch": "Active" if ks else "INACTIVE",
            "verification": "tun0 Internet route missing",
            "selector_state": state,
            "local_tunnel": tunnel_exists(),
            "backend_verified": False,
        }

    # Selector deliberately failed closed.
    if state == "failed":
        ks = kill_switch_active()

        return {
            "path": "Local OpenVPN failed",
            "status": "FAIL-CLOSED",
            "interface": iface,
            "tunnel_ip": "N/A",
            "server": configured_server(),
            "killswitch": "Active" if ks else "UNKNOWN",
            "verification": "Selector failure",
            "selector_state": state,
            "local_tunnel": tunnel_exists(),
            "backend_verified": False,
        }

    # No trustworthy selector state available yet.
    ks = kill_switch_active()

    return {
        "path": "Unknown",
        "status": "CHECK VPN",
        "interface": iface,
        "tunnel_ip": "N/A",
        "server": "Unknown",
        "killswitch": "Active" if ks else "Unknown",
        "verification": "Selector state unavailable",
        "selector_state": state,
        "local_tunnel": tunnel_exists(),
        "backend_verified": False,
    }


def state_token():
    return selector_state()


def lightweight_router_probe():
    """
    Lightweight router-mode fingerprint check.

    A successful public-IP lookup is compared with the upstream
    IP last verified by the selector.

    If that lookup fails, a raw IPv4 connectivity test separates
    detector/DNS trouble from loss of the physical Internet path.
    """
    state = selector_state()

    if state != "router":
        return {
            "ok": True,
            "changed": False,
            "state": state,
            "reason": "not_router",
        }

    upstream_file = "/run/vpn-selector.upstream-ip"

    try:
        with open(
            upstream_file,
            "r",
            encoding="utf-8",
        ) as f:
            previous_ip = f.read().strip()
    except OSError:
        previous_ip = ""

    route = subprocess.run(
        [
            "ip",
            "-4",
            "route",
            "show",
            "table",
            "main",
            "default",
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=5,
    )

    if route.returncode != 0:
        return {
            "ok": False,
            "changed": False,
            "state": state,
            "physical_internet": False,
            "reason": "default_route_unavailable",
        }

    interface = None

    for line in route.stdout.splitlines():
        parts = line.split()

        if not parts or parts[0] != "default":
            continue

        try:
            index = parts.index("dev")
            interface = parts[index + 1]
        except (ValueError, IndexError):
            pass

        if interface:
            break

    if not interface:
        return {
            "ok": False,
            "changed": False,
            "state": state,
            "physical_internet": False,
            "reason": "physical_interface_unavailable",
        }

    try:
        probe = subprocess.run(
            [
                "curl",
                "--interface",
                interface,
                "-4fsS",
                "--connect-timeout",
                "3",
                "--max-time",
                "5",
                "https://api.ipify.org",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=7,
        )

    except Exception as exc:
        return {
            "ok": False,
            "changed": False,
            "state": state,
            "interface": interface,
            "physical_internet": _raw_ipv4_connectivity(),
            "reason": "public_ip_probe_exception: {}".format(exc),
        }

    if probe.returncode != 0:
        return {
            "ok": False,
            "changed": False,
            "state": state,
            "interface": interface,
            "physical_internet": _raw_ipv4_connectivity(),
            "reason": (
                probe.stderr.strip()
                or "public_ip_probe_failed"
            ),
        }

    current_ip = probe.stdout.strip()

    try:
        socket.inet_aton(current_ip)
    except OSError:
        return {
            "ok": False,
            "changed": False,
            "state": state,
            "interface": interface,
            "physical_internet": _raw_ipv4_connectivity(),
            "reason": "invalid_public_ip",
        }

    if not previous_ip:
        return {
            "ok": False,
            "changed": False,
            "state": state,
            "interface": interface,
            "physical_internet": True,
            "current_ip": current_ip,
            "reason": "verified_upstream_ip_missing",
        }

    changed = current_ip != previous_ip

    return {
        "ok": True,
        "changed": changed,
        "state": state,
        "interface": interface,
        "physical_internet": True,
        "previous_ip": previous_ip,
        "current_ip": current_ip,
        "reason": (
            "upstream_ip_changed"
            if changed
            else "unchanged"
        ),
    }


def failed_recovery_probe():
    """
    Cheap recovery gate while the bootstrap guard is fail-closed.

    DNS resolution is deliberately used here because unrestricted
    raw WAN traffic is blocked in failed mode.
    """
    for host in (
        "api.ipify.org",
        "proxycheck.io",
    ):
        try:
            result = socket.getaddrinfo(
                host,
                443,
                socket.AF_INET,
                socket.SOCK_STREAM,
            )

            if result:
                return {
                    "ready": True,
                    "reason": "detector_dns_recovered",
                    "host": host,
                }

        except OSError:
            pass

    return {
        "ready": False,
        "reason": "detector_dns_unavailable",
    }


def request_refresh():
    return start_selector()


def refresh_in_progress():
    return selector_service_state() in (
        "active",
        "activating",
    )


MANAGED_OPENVPN_SERVICE = "vpn-manager-openvpn.service"
MANAGEMENT_POLICY = "protected-selector"


def _profile_error(message):
    return {
        "ok": False,
        "code": None,
        "message": message,
    }


def can_manage_profile(profile):
    if not isinstance(profile, dict):
        return False

    if not profile.get("enabled", True):
        return False

    profile_type = str(
        profile.get("type", "")
    ).strip().lower()

    profile_path = str(
        profile.get("path", "")
    ).strip()

    return bool(
        SYSTEMCTL
        and profile_type == "openvpn"
        and profile_path
        and os.path.isfile(profile_path)
    )



def _resolve_ipv4(host, attempts=8):
    """
    Resolve a VPN hostname repeatedly and return the unique IPv4
    endpoint pool observed.

    Some providers use DNS round-robin, so a single lookup is not
    sufficient protection for a later OpenVPN connection.
    """
    import socket
    import time

    host = str(host or "").strip()

    if re.match(
        r"^[0-9]+(?:\.[0-9]+){3}$",
        host
    ):
        return [host]

    found = []

    getent = shutil.which("getent")

    for attempt in range(attempts):
        addresses = []

        if getent:
            try:
                result = subprocess.run(
                    [
                        getent,
                        "ahostsv4",
                        host,
                    ],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    text=True,
                    timeout=5,
                )

                if result.returncode == 0:
                    for line in result.stdout.splitlines():
                        parts = line.split()

                        if parts:
                            addresses.append(parts[0])

            except Exception:
                pass

        if not addresses:
            try:
                results = socket.getaddrinfo(
                    host,
                    None,
                    socket.AF_INET,
                    0,
                    0,
                )

                addresses = [
                    result[4][0]
                    for result in results
                ]

            except Exception:
                pass

        for address in addresses:
            if (
                re.match(
                    r"^[0-9]+(?:\.[0-9]+){3}$",
                    address
                )
                and address not in found
            ):
                found.append(address)

        if attempt + 1 < attempts:
            time.sleep(1)

    return found


def _config_reference_path(
    config_dir,
    value,
):
    value = str(value or "").strip()

    if not value:
        return None

    # Inline OpenVPN data such as <ca>...</ca>
    # has no external path to verify.
    if value.startswith("<"):
        return None

    if os.path.isabs(value):
        return value

    return os.path.normpath(
        os.path.join(
            config_dir,
            value,
        )
    )


def preflight_profile(profile):
    """
    Read-only validation for a proposed local OpenVPN profile.

    This function MUST NOT:
      - alter the profile registry
      - start/stop OpenVPN
      - invoke vpn-selector
      - alter routing, DNS, or firewall state
    """
    result = {
        "ok": False,
        "profile_id": None,
        "name": None,
        "type": None,
        "path": None,
        "active_path": active_profile_path(),
        "transports": [],
        "references": [],
        "warnings": [],
        "errors": [],
    }

    if not isinstance(profile, dict):
        result["errors"].append(
            "Invalid VPN profile"
        )
        return result

    result["profile_id"] = profile.get("id")
    result["name"] = profile.get("name")
    result["type"] = str(
        profile.get("type", "")
    ).strip().lower()

    path = str(
        profile.get("path", "")
    ).strip()

    result["path"] = path

    if not profile.get("enabled", True):
        result["errors"].append(
            "VPN profile is disabled"
        )

    if result["type"] != "openvpn":
        result["errors"].append(
            "CoreELEC preflight currently supports OpenVPN profiles"
        )

    if not path:
        result["errors"].append(
            "OpenVPN profile path is missing"
        )
        return result

    if not os.path.isfile(path):
        result["errors"].append(
            "OpenVPN profile does not exist: {}".format(
                path
            )
        )
        return result

    if not os.access(path, os.R_OK):
        result["errors"].append(
            "OpenVPN profile is not readable: {}".format(
                path
            )
        )
        return result

    if not shutil.which("openvpn"):
        result["errors"].append(
            "OpenVPN executable not found"
        )

    config_dir = os.path.dirname(path)

    try:
        with open(
            path,
            "r",
            encoding="utf-8",
            errors="replace",
        ) as f:
            lines = [
                line.strip()
                for line in f
                if line.strip()
                and not line.lstrip().startswith(
                    ("#", ";")
                )
            ]

    except Exception as exc:
        result["errors"].append(
            "Could not read OpenVPN profile: {}".format(
                exc
            )
        )
        return result

    proto = "udp"
    default_port = "1194"

    for line in lines:
        parts = line.split()

        if not parts:
            continue

        key = parts[0].lower()

        if key == "proto" and len(parts) >= 2:
            proto = (
                "tcp"
                if parts[1].lower().startswith("tcp")
                else "udp"
            )

        elif key == "port" and len(parts) >= 2:
            default_port = parts[1]

    for line in lines:
        parts = line.split()

        if not parts:
            continue

        key = parts[0].lower()

        if key == "remote" and len(parts) >= 2:
            host = parts[1]
            port = default_port
            remote_proto = proto

            if len(parts) >= 3:
                if parts[2].isdigit():
                    port = parts[2]

                    if len(parts) >= 4:
                        remote_proto = parts[3]
                else:
                    remote_proto = parts[2]

            remote_proto = (
                "tcp"
                if remote_proto.lower().startswith("tcp")
                else "udp"
            )

            addresses = _resolve_ipv4(host)

            transport = {
                "host": host,
                "port": port,
                "proto": remote_proto,
                "addresses": addresses,
            }

            result["transports"].append(
                transport
            )

            if not addresses:
                result["errors"].append(
                    "Cannot resolve VPN endpoint: {}".format(
                        host
                    )
                )

    if not result["transports"]:
        result["errors"].append(
            "OpenVPN profile has no remote directive"
        )

    # External files that may be required by the profile.
    reference_directives = {
        "ca",
        "cert",
        "key",
        "pkcs12",
        "tls-auth",
        "tls-crypt",
        "auth-user-pass",
    }

    for line in lines:
        parts = line.split()

        if not parts:
            continue

        key = parts[0].lower()

        if key not in reference_directives:
            continue

        # Bare "auth-user-pass" is valid; credentials may be
        # supplied by the launcher/runtime.
        if (
            key == "auth-user-pass"
            and len(parts) == 1
        ):
            result["references"].append({
                "directive": key,
                "path": None,
                "status": "runtime",
            })
            continue

        if len(parts) < 2:
            continue

        ref = _config_reference_path(
            config_dir,
            parts[1],
        )

        if not ref:
            continue

        exists = os.path.isfile(ref)
        readable = (
            exists
            and os.access(ref, os.R_OK)
        )

        result["references"].append({
            "directive": key,
            "path": ref,
            "status": (
                "ok"
                if readable
                else "missing"
            ),
        })

        if not readable:
            result["errors"].append(
                "Required {} file unavailable: {}".format(
                    key,
                    ref,
                )
            )

    result["ok"] = not result["errors"]

    return result



def build_handoff_plan(profile):
    """
    Build a read-only protected handoff plan.

    This performs validation and endpoint staging only.
    It MUST NOT change registry state, routing, DNS, firewall,
    OpenVPN services, or selector state.
    """
    check = preflight_profile(profile)

    plan = {
        "ok": False,
        "action": "blocked",
        "profile_id": check.get("profile_id"),
        "name": check.get("name"),
        "active_path": check.get("active_path"),
        "target_path": check.get("path"),
        "transports": check.get("transports", []),
        "staged_endpoints": [],
        "errors": list(check.get("errors", [])),
        "warnings": list(check.get("warnings", [])),
    }

    if not check.get("ok"):
        return plan

    active_path = check.get("active_path")
    target_path = check.get("path")

    try:
        same_profile = (
            active_path
            and target_path
            and os.path.realpath(active_path)
            == os.path.realpath(target_path)
        )
    except Exception:
        same_profile = (
            active_path == target_path
        )

    if same_profile:
        plan["ok"] = True
        plan["action"] = "already_active"
        return plan

    for transport in check.get(
        "transports",
        []
    ):
        for address in transport.get(
            "addresses",
            []
        ):
            plan["staged_endpoints"].append({
                "host": transport.get("host"),
                "address": address,
                "port": transport.get("port"),
                "proto": transport.get("proto"),
            })

    if not plan["staged_endpoints"]:
        plan["errors"].append(
            "No usable VPN transport endpoints were staged"
        )
        return plan

    plan["ok"] = True
    plan["action"] = "protected_switch"

    return plan



def _profile_id_for_path(
    data,
    path,
):
    if not path:
        return None

    try:
        wanted = os.path.realpath(path)
    except Exception:
        wanted = str(path)

    for item in profile_registry.profiles(
        data
    ):
        candidate = item.get("path")

        if not candidate:
            continue

        try:
            candidate = os.path.realpath(
                candidate
            )
        except Exception:
            candidate = str(candidate)

        if candidate == wanted:
            return item.get("id")

    return None


def _current_protected_mode(data=None):
    """
    Identify the actual protected starting mode.

    local:
        A verified tun0 is carrying Internet traffic.

    router:
        The selector has already verified the upstream/router VPN.

    No network state is changed here.
    """
    route = internet_route()
    active_path = active_profile_path()

    if (
        active_path
        and tunnel_exists()
        and "dev tun0" in route
    ):
        active_id = active_profile_id(
            data=data,
        )

        if not active_id:
            return {
                "ok": False,
                "mode": "local",
                "active_profile_id": None,
                "active_path": active_path,
                "errors": [
                    "Local VPN is routing traffic but "
                    "its profile cannot be identified"
                ],
            }

        return {
            "ok": True,
            "mode": "local",
            "active_profile_id": active_id,
            "active_path": active_path,
            "errors": [],
        }

    state = selector_state()

    if state == "router":
        return {
            "ok": True,
            "mode": "router",
            "active_profile_id": None,
            "active_path": None,
            "errors": [],
        }

    return {
        "ok": False,
        "mode": state or "unknown",
        "active_profile_id": None,
        "active_path": active_path,
        "errors": [
            "No verified protected VPN starting mode"
        ],
    }


def _set_registry_selected(profile_id):
    try:
        data = profile_registry.load(
            PROFILE_REGISTRY
        )

        data = profile_registry.set_selected(
            data,
            profile_id,
        )

        profile_registry.save(
            PROFILE_REGISTRY,
            data,
        )

        return {
            "ok": True,
            "profile_id": profile_id,
        }

    except Exception as exc:
        return {
            "ok": False,
            "profile_id": profile_id,
            "error": str(exc),
        }


def build_handoff_transaction(profile):
    """
    Build a complete READ-ONLY VPN transaction.

    Router mode:
        Selecting a profile changes only the preferred local
        fallback. The verified router VPN remains authoritative.

    Local mode:
        Builds a protected local-to-local switch transaction.
    """
    plan = build_handoff_plan(profile)

    transaction = {
        "ok": False,
        "action": plan.get("action"),
        "previous_mode": None,
        "previous_profile_id": None,
        "previous_path": plan.get("active_path"),
        "previous_endpoint": None,
        "target_profile_id": plan.get("profile_id"),
        "target_path": plan.get("target_path"),
        "endpoint": None,
        "errors": list(
            plan.get("errors", [])
        ),
        "warnings": list(
            plan.get("warnings", [])
        ),
    }

    if not plan.get("ok"):
        return transaction

    try:
        data = profile_registry.load(
            PROFILE_REGISTRY
        )

    except Exception as exc:
        transaction["errors"].append(
            "Could not read profile registry: {}".format(
                exc
            )
        )
        return transaction

    protected = _current_protected_mode(
        data=data,
    )

    transaction["previous_mode"] = (
        protected.get("mode")
    )

    if not protected.get("ok"):
        transaction["errors"].extend(
            protected.get("errors", [])
        )
        return transaction

    registry_selected = data.get(
        "selected"
    )

    # -----------------------------------------------------
    # ROUTER MODE
    #
    # The router VPN is already the verified protected path.
    # A local profile selection therefore changes only which
    # profile will be used if local fallback is later needed.
    # -----------------------------------------------------
    if protected.get("mode") == "router":
        transaction[
            "previous_profile_id"
        ] = registry_selected

        if (
            plan.get("profile_id")
            == registry_selected
        ):
            transaction["ok"] = True
            transaction["action"] = (
                "router_selection_unchanged"
            )
            return transaction

        endpoints = plan.get(
            "staged_endpoints",
            []
        )

        if not endpoints:
            transaction["errors"].append(
                "No preflighted fallback endpoint available"
            )
            return transaction

        chosen = endpoints[0]

        transaction["endpoint"] = {
            "address": chosen.get("address"),
            "port": chosen.get("port"),
            "proto": chosen.get("proto"),
            "host": chosen.get("host"),
        }

        transaction["ok"] = True
        transaction["action"] = (
            "select_fallback"
        )

        return transaction

    # -----------------------------------------------------
    # LOCAL MODE
    # -----------------------------------------------------

    active_id = protected.get(
        "active_profile_id"
    )

    active_path = protected.get(
        "active_path"
    )

    transaction[
        "previous_profile_id"
    ] = active_id

    transaction[
        "previous_path"
    ] = active_path

    previous_endpoint = (
        _runtime_endpoint_for_profile(
            active_id
        )
    )

    if not previous_endpoint:
        transaction["errors"].append(
            "Protected local handoff refused: "
            "the active VPN has no verified pinned "
            "runtime endpoint for deterministic rollback"
        )
        return transaction

    transaction[
        "previous_endpoint"
    ] = previous_endpoint

    if plan.get("action") == "already_active":
        transaction["ok"] = True
        transaction["action"] = (
            "already_active"
        )
        return transaction

    if registry_selected != active_id:
        transaction["errors"].append(
            "Registry selection does not match "
            "the verified active VPN profile"
        )
        return transaction

    endpoints = plan.get(
        "staged_endpoints",
        []
    )

    if not endpoints:
        transaction["errors"].append(
            "No preflighted target endpoint available"
        )
        return transaction

    chosen = endpoints[0]

    transaction["endpoint"] = {
        "address": chosen.get("address"),
        "port": chosen.get("port"),
        "proto": chosen.get("proto"),
        "host": chosen.get("host"),
    }

    transaction["ok"] = True
    transaction["action"] = (
        "protected_switch"
    )

    return transaction



def _command_result(
    args,
    timeout=30,
):
    if not args or not args[0]:
        return None

    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
        )

        return {
            "code": result.returncode,
            "stdout": result.stdout.strip(),
            "stderr": result.stderr.strip(),
        }

    except Exception as exc:
        return {
            "code": None,
            "stdout": "",
            "stderr": str(exc),
        }


def _read_runtime_target():
    """
    Return a validated pinned runtime target, or None.

    This is deliberately strict because the value may become
    the only deterministic rollback route after the active
    tunnel has been stopped.
    """
    try:
        with open(
            RUNTIME_TARGET_FILE,
            "r",
            encoding="utf-8",
        ) as f:
            payload = json.load(f)

    except (FileNotFoundError, OSError, ValueError, TypeError):
        return None

    if not isinstance(payload, dict):
        return None

    profile_id = payload.get("profile_id")
    address = payload.get("remote_address")
    port = payload.get("remote_port")
    proto = str(
        payload.get("remote_proto") or ""
    ).lower()

    if not profile_id or not address or not port:
        return None

    if proto.startswith("tcp"):
        proto = "tcp"
    elif proto.startswith("udp"):
        proto = "udp"
    else:
        return None

    try:
        socket.inet_aton(str(address))
    except OSError:
        return None

    try:
        port_int = int(port)
    except (TypeError, ValueError):
        return None

    if not 1 <= port_int <= 65535:
        return None

    return {
        "profile_id": str(profile_id),
        "remote_address": str(address),
        "remote_port": str(port_int),
        "remote_proto": proto,
    }


def _runtime_endpoint_for_profile(profile_id):
    target = _read_runtime_target()

    if not target:
        return None

    if target.get("profile_id") != profile_id:
        return None

    return {
        "address": target.get(
            "remote_address"
        ),
        "port": target.get(
            "remote_port"
        ),
        "proto": target.get(
            "remote_proto"
        ),
        "host": None,
    }


def _write_runtime_target(transaction):
    endpoint = transaction.get("endpoint") or {}

    payload = {
        "profile_id": transaction.get(
            "target_profile_id"
        ),
        "remote_address": endpoint.get(
            "address"
        ),
        "remote_port": endpoint.get(
            "port"
        ),
        "remote_proto": endpoint.get(
            "proto"
        ),
    }

    required = (
        "profile_id",
        "remote_address",
        "remote_port",
        "remote_proto",
    )

    for key in required:
        if not payload.get(key):
            raise ValueError(
                "Runtime target missing {}".format(
                    key
                )
            )

    tmp = RUNTIME_TARGET_FILE + ".tmp"

    try:
        with open(
            tmp,
            "w",
            encoding="utf-8",
        ) as f:
            json.dump(
                payload,
                f,
                indent=2,
            )
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())

        os.chmod(tmp, 0o600)
        os.replace(
            tmp,
            RUNTIME_TARGET_FILE,
        )
        os.chmod(
            RUNTIME_TARGET_FILE,
            0o600,
        )

    except Exception:
        try:
            os.unlink(tmp)
        except Exception:
            pass
        raise



def _run_killswitch_up():
    if not os.path.isfile(
        KILLSWITCH_SCRIPT
    ):
        return {
            "code": None,
            "stdout": "",
            "stderr": (
                "Kill-switch script not found"
            ),
        }

    return _command_result(
        [
            KILLSWITCH_SCRIPT,
            "up",
        ],
        timeout=30,
    )


def _service_action(action):
    if not SYSTEMCTL:
        return {
            "code": None,
            "stdout": "",
            "stderr": "systemctl unavailable",
        }

    return _command_result(
        [
            SYSTEMCTL,
            action,
            MANAGED_OPENVPN_SERVICE,
        ],
        timeout=40,
    )


def _wait_tunnel_absent(
    timeout=15,
):
    deadline = time.time() + timeout

    while time.time() < deadline:
        if (
            not tunnel_exists()
            and not active_profile_path()
        ):
            return True

        time.sleep(0.25)

    return False


def _raw_ipv4_connectivity():
    """
    DNS-independent Internet reachability check.

    This verifies that a TCP connection can leave through the
    newly-established tunnel without relying on hostname
    resolution.
    """
    try:
        sock = socket.create_connection(
            ("1.1.1.1", 443),
            timeout=5,
        )
        sock.close()
        return True
    except Exception:
        return False


def _wait_profile_active(
    profile_id,
    timeout=45,
):
    deadline = time.time() + timeout

    while time.time() < deadline:
        route = internet_route()

        if (
            tunnel_exists()
            and "dev tun0" in route
            and active_profile_id()
            == profile_id
        ):
            if _raw_ipv4_connectivity():
                return True

        time.sleep(1)

    return False


def _rollback_handoff(
    previous_profile_id,
    previous_endpoint,
):
    """
    Restore the previously verified local profile using its
    exact pre-switch pinned endpoint.

    No DNS resolution is required after the target tunnel has
    failed or been stopped.
    """
    if not previous_profile_id:
        return {
            "ok": False,
            "stage": "rollback_identity",
            "detail": (
                "Previous profile identity is unavailable"
            ),
        }

    if not previous_endpoint:
        return {
            "ok": False,
            "stage": "rollback_endpoint",
            "detail": (
                "Previous pinned endpoint is unavailable"
            ),
        }

    stop = _service_action("stop")

    if stop.get("code") != 0:
        return {
            "ok": False,
            "stage": "rollback_stop",
            "detail": stop,
        }

    if not _wait_tunnel_absent():
        return {
            "ok": False,
            "stage": "rollback_tunnel_stop",
            "detail": (
                "Target tunnel did not disappear"
            ),
        }

    registry = _set_registry_selected(
        previous_profile_id
    )

    if not registry.get("ok"):
        return {
            "ok": False,
            "stage": "rollback_registry",
            "detail": registry,
        }

    #
    # Restore the PREVIOUS exact runtime target before touching
    # the firewall. This is the key deterministic rollback step.
    #
    previous_transaction = {
        "target_profile_id": previous_profile_id,
        "endpoint": previous_endpoint,
    }

    try:
        _write_runtime_target(
            previous_transaction
        )
    except Exception as exc:
        return {
            "ok": False,
            "stage": "rollback_target",
            "detail": str(exc),
        }

    protection = _run_killswitch_up()

    if protection.get("code") != 0:
        return {
            "ok": False,
            "stage": "rollback_protection",
            "detail": protection,
        }

    start_result = _service_action(
        "start"
    )

    if start_result.get("code") != 0:
        return {
            "ok": False,
            "stage": "rollback_start",
            "detail": start_result,
        }

    if not _wait_profile_active(
        previous_profile_id,
        timeout=45,
    ):
        return {
            "ok": False,
            "stage": "rollback_verify",
            "detail": (
                "Previous VPN profile did not "
                "re-establish a verified tunnel"
            ),
        }

    return {
        "ok": True,
        "stage": "rolled_back",
    }



def execute_handoff(
    profile,
    dry_run=True,
):
    """
    Execute a VPN profile transaction.

    dry_run=True is deliberately mandatory by default.
    """
    transaction = build_handoff_transaction(
        profile
    )

    result = {
        "ok": False,
        "dry_run": bool(dry_run),
        "action": transaction.get("action"),
        "previous_mode": transaction.get(
            "previous_mode"
        ),
        "previous_profile_id": (
            transaction.get(
                "previous_profile_id"
            )
        ),
        "previous_endpoint": (
            transaction.get(
                "previous_endpoint"
            )
        ),
        "target_profile_id": (
            transaction.get(
                "target_profile_id"
            )
        ),
        "endpoint": transaction.get(
            "endpoint"
        ),
        "stage": "preflight",
        "rolled_back": False,
        "errors": list(
            transaction.get(
                "errors",
                []
            )
        ),
    }

    if not transaction.get("ok"):
        return result

    if transaction.get("action") in (
        "already_active",
        "router_selection_unchanged",
    ):
        result["ok"] = True
        result["stage"] = transaction.get(
            "action"
        )
        return result

    if dry_run:
        result["ok"] = True
        result["stage"] = "dry_run_ready"
        return result

    target_id = transaction.get(
        "target_profile_id"
    )

    # -----------------------------------------------------
    # ROUTER MODE
    #
    # Do not disturb the router VPN. Merely commit the
    # validated preferred local fallback profile.
    # -----------------------------------------------------
    if (
        transaction.get("previous_mode")
        == "router"
    ):
        if (
            transaction.get("action")
            != "select_fallback"
        ):
            result["errors"].append(
                "Unexpected router-mode transaction"
            )
            return result

        commit = _set_registry_selected(
            target_id
        )

        if not commit.get("ok"):
            result["errors"].append(
                "Could not save fallback profile: {}".format(
                    commit.get("error")
                )
            )
            result["stage"] = (
                "fallback_commit_failed"
            )
            return result

        result["ok"] = True
        result["stage"] = (
            "fallback_selected"
        )

        return result

    # -----------------------------------------------------
    # LOCAL MODE
    # -----------------------------------------------------

    if (
        transaction.get("previous_mode")
        != "local"
    ):
        result["errors"].append(
            "Unsupported protected starting mode"
        )
        return result

    if not SYSTEMCTL:
        result["errors"].append(
            "systemctl unavailable"
        )
        return result

    if not kill_switch_active():
        result["errors"].append(
            "Protected handoff refused: "
            "current kill switch is not active"
        )
        return result

    previous_id = transaction.get(
        "previous_profile_id"
    )

    previous_endpoint = transaction.get(
        "previous_endpoint"
    )

    if not previous_endpoint:
        result["errors"].append(
            "Protected handoff refused: "
            "deterministic rollback endpoint unavailable"
        )
        return result

    try:
        _write_runtime_target(
            transaction
        )

    except Exception as exc:
        result["errors"].append(
            "Could not stage runtime target: {}".format(
                exc
            )
        )
        return result

    result["stage"] = "target_staged"

    protection = _run_killswitch_up()

    if protection.get("code") != 0:
        try:
            _write_runtime_target(
                {
                    "target_profile_id": previous_id,
                    "endpoint": previous_endpoint,
                }
            )
            restore = _run_killswitch_up()

        except Exception as exc:
            restore = {
                "code": None,
                "stderr": str(exc),
            }

        result["stage"] = (
            "target_protection_failed"
        )

        result["errors"].append(
            protection.get("stderr")
            or "Could not stage target kill-switch rules"
        )

        if restore.get("code") != 0:
            result["errors"].append(
                "Could not restore previous kill-switch rules"
            )

        return result

    result["stage"] = "target_protected"

    stop = _service_action("stop")

    if stop.get("code") != 0:
        result["errors"].append(
            stop.get("stderr")
            or "Could not stop current OpenVPN service"
        )

        rollback = _rollback_handoff(
            previous_id,
            previous_endpoint,
        )

        result["rolled_back"] = bool(
            rollback.get("ok")
        )
        result["stage"] = rollback.get(
            "stage",
            "rollback_failed",
        )

        return result

    if not _wait_tunnel_absent():
        result["errors"].append(
            "Current tunnel did not fully stop"
        )

        rollback = _rollback_handoff(
            previous_id,
            previous_endpoint,
        )

        result["rolled_back"] = bool(
            rollback.get("ok")
        )
        result["stage"] = rollback.get(
            "stage",
            "rollback_failed",
        )

        return result

    result["stage"] = "old_tunnel_stopped"

    start_result = _service_action(
        "start"
    )

    if start_result.get("code") != 0:
        result["errors"].append(
            start_result.get("stderr")
            or "Could not start target OpenVPN service"
        )

        rollback = _rollback_handoff(
            previous_id,
            previous_endpoint,
        )

        result["rolled_back"] = bool(
            rollback.get("ok")
        )
        result["stage"] = rollback.get(
            "stage",
            "rollback_failed",
        )

        return result

    result["stage"] = "target_started"

    if not _wait_profile_active(
        target_id,
        timeout=45,
    ):
        result["errors"].append(
            "Target VPN failed verification"
        )

        rollback = _rollback_handoff(
            previous_id,
            previous_endpoint,
        )

        result["rolled_back"] = bool(
            rollback.get("ok")
        )
        result["stage"] = rollback.get(
            "stage",
            "rollback_failed",
        )

        return result

    result["stage"] = "target_verified"

    commit = _set_registry_selected(
        target_id
    )

    if not commit.get("ok"):
        result["errors"].append(
            "Could not commit selected profile: {}".format(
                commit.get("error")
            )
        )

        rollback = _rollback_handoff(
            previous_id,
            previous_endpoint,
        )

        result["rolled_back"] = bool(
            rollback.get("ok")
        )
        result["stage"] = rollback.get(
            "stage",
            "rollback_failed",
        )

        return result

    result["ok"] = True
    result["stage"] = "committed"

    return result



def connect(profile):
    if not isinstance(profile, dict):
        return _profile_error(
            "Invalid VPN profile"
        )

    if not profile.get("enabled", True):
        return _profile_error(
            "VPN profile is disabled"
        )

    profile_type = str(
        profile.get("type", "")
    ).strip().lower()

    if profile_type != "openvpn":
        return _profile_error(
            "CoreELEC manager currently supports OpenVPN profiles"
        )

    if not can_manage_profile(profile):
        return _profile_error(
            "OpenVPN profile or manager backend unavailable"
        )

    try:
        data = profile_registry.load(
            PROFILE_REGISTRY
        )

        data = profile_registry.upsert(
            data,
            profile
        )

        data = profile_registry.set_selected(
            data,
            profile["id"]
        )

        selected = profile_registry.selected_profile(
            data
        )

        if not selected:
            return _profile_error(
                "Could not select VPN profile"
            )

        profile_registry.save(
            PROFILE_REGISTRY,
            data
        )

    except Exception as exc:
        return _profile_error(
            "Could not update VPN profile registry: {}".format(
                exc
            )
        )

    #
    # Do NOT start OpenVPN directly.
    # The selector first verifies the upstream/router path,
    # then starts the managed local fallback only if required.
    #
    clock_ok, clock_detail = (
        _sync_bootstrap_clock()
    )

    if not clock_ok:

        try:
            with open(
                STATE_FILE,
                "w",
                encoding="utf-8",
            ) as f:
                f.write("failed\n")

        except Exception:
            pass

        return {
            "ok": False,
            "code": None,
            "message": (
                "Time synchronization failed. "
                "Fail-closed protection remains active."
            ),
            "state": "failed",
        }

    code = request_refresh()

    if code == 0:
        return {
            "ok": True,
            "code": code,
            "message": "Protected VPN selection completed",
            "state": selector_state(),
        }

    return {
        "ok": False,
        "code": code,
        "message": "Protected VPN selection failed",
        "state": selector_state(),
    }


def _run_protection_command(
    command,
    timeout=30,
):
    try:
        result = subprocess.run(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
        )

        return (
            result.returncode == 0,
            result.returncode,
        )

    except Exception:
        return False, None


def _sync_bootstrap_clock():
    """
    Synchronize system time through the narrow NTP exception
    already established by vpn-bootstrap-guard.sh.
    """

    import socket
    import time

    ntpd = shutil.which(
        "ntpd"
    )

    if not ntpd:
        return (
            False,
            "ntpd unavailable",
        )

    peer_file = (
        "/run/vpn-bootstrap-ntp.peers"
    )

    try:
        with open(
            peer_file,
            "r",
            encoding="utf-8",
        ) as f:
            peers = [
                line.strip()
                for line in f
                if line.strip()
            ]

    except Exception:
        peers = []

    if not peers:
        return (
            False,
            "no bootstrap NTP peers",
        )

    for peer in peers:

        try:
            socket.inet_aton(
                peer
            )
        except OSError:
            continue

        try:
            result = subprocess.run(
                [
                    ntpd,
                    "-q",
                    "-p",
                    peer,
                ],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=25,
            )

        except Exception:
            continue

        if result.returncode != 0:
            continue

        # Jan 1 2025 UTC.
        #
        # This catches the known stale-RTC condition while
        # avoiding dependence on an external date source.
        if time.time() >= 1735689600:
            return (
                True,
                "clock synchronized",
            )

    return (
        False,
        "NTP synchronization failed",
    )


def disable_protection():
    """
    Deliberately enter an unprotected state.

    This is an explicit user action. The persistent marker
    suppresses automatic selector/fallback reconnection until
    enable_protection() is called.
    """

    if protection_disabled():
        return {
            "ok": True,
            "code": 0,
            "message":
                "VPN protection is already disabled",
            "state": "disabled",
        }

    if not SYSTEMCTL:
        return {
            "ok": False,
            "code": None,
            "message":
                "systemctl unavailable",
            "state": selector_state(),
        }

    try:
        _set_protection_disabled(
            True
        )

    except Exception as exc:
        return {
            "ok": False,
            "code": None,
            "message":
                "Could not enter disabled mode: "
                "{}".format(exc),
            "state": selector_state(),
        }

    errors = []

    # Stop the selector first so it cannot race the
    # deliberately disabled state.
    ok, code = _run_protection_command(
        [
            SYSTEMCTL,
            "stop",
            SELECTOR_SERVICE,
        ],
        timeout=30,
    )

    if not ok:
        errors.append(
            "selector stop failed ({})"
            .format(code)
        )

    # Keep fail-closed protection in place while OpenVPN
    # is being stopped.
    ok, code = _run_protection_command(
        [
            SYSTEMCTL,
            "stop",
            MANAGED_OPENVPN_SERVICE,
        ],
        timeout=30,
    )

    if not ok:
        errors.append(
            "OpenVPN stop failed ({})"
            .format(code)
        )

    bootstrap_guard = (
        "/storage/.config/"
        "vpn-bootstrap-guard.sh"
    )

    if os.path.exists(
        bootstrap_guard
    ):
        ok, code = _run_protection_command(
            [
                bootstrap_guard,
                "down",
            ],
            timeout=30,
        )

        if not ok:
            errors.append(
                "bootstrap guard disable failed ({})"
                .format(code)
            )

    dns_script = (
        "/storage/.config/"
        "openvpn-dns-lock.sh"
    )

    if os.path.exists(dns_script):
        ok, code = _run_protection_command(
            [
                dns_script,
                "unlock",
            ]
        )

        if not ok:
            errors.append(
                "DNS unlock failed ({})"
                .format(code)
            )

    else:
        errors.append(
            "DNS lock script missing"
        )

    if os.path.exists(
        KILLSWITCH_SCRIPT
    ):
        ok, code = _run_protection_command(
            [
                KILLSWITCH_SCRIPT,
                "down",
            ]
        )

        if not ok:
            errors.append(
                "kill switch disable failed ({})"
                .format(code)
            )

    else:
        errors.append(
            "kill switch script missing"
        )

    try:
        with open(
            STATE_FILE,
            "w",
            encoding="utf-8",
        ) as f:
            f.write("disabled\n")

    except Exception as exc:
        errors.append(
            "state write failed: {}"
            .format(exc)
        )

    if tunnel_exists():
        errors.append(
            "local VPN tunnel still present"
        )

    if kill_switch_active():
        errors.append(
            "kill switch still active"
        )

    if errors:
        return {
            "ok": False,
            "code": None,
            "message": (
                "Protection disable incomplete. "
                "Automatic reconnect remains "
                "suppressed.\n\n{}"
            ).format(
                "; ".join(errors)
            ),
            "state": "disabled",
        }

    return {
        "ok": True,
        "code": 0,
        "message": (
            "VPN protection disabled. "
            "Automatic reconnect is suppressed "
            "until protection is enabled again."
        ),
        "state": "disabled",
    }


def enable_protection():
    """
    Safely leave deliberate disabled mode.

    The existing fail-closed bootstrap guard is armed before
    the disabled marker is removed. Therefore a subsequent
    selector/VPN failure cannot expose ordinary ISP traffic.
    """

    bootstrap_guard = (
        "/storage/.config/"
        "vpn-bootstrap-guard.sh"
    )

    if not os.path.exists(bootstrap_guard):
        return {
            "ok": False,
            "code": None,
            "message": (
                "Bootstrap guard is missing. "
                "Protection remains disabled."
            ),
            "state": selector_state(),
        }

    # Still deliberately disabled here.
    # First remove unrestricted WAN access by arming
    # the existing fail-closed bootstrap guard.
    ok, guard_code = _run_protection_command(
        [
            bootstrap_guard,
            "up",
        ],
        timeout=60,
    )

    if not ok:
        return {
            "ok": False,
            "code": guard_code,
            "message": (
                "Could not arm fail-closed protection. "
                "Protection remains disabled."
            ),
            "state": selector_state(),
        }

    # Fail-closed protection is now active, so it is safe
    # to leave deliberate disabled mode.
    try:
        _set_protection_disabled(False)

    except Exception as exc:
        # Return to the original deliberately-unprotected
        # state if the marker cannot be cleared.
        _run_protection_command(
            [
                bootstrap_guard,
                "down",
            ],
            timeout=30,
        )

        return {
            "ok": False,
            "code": None,
            "message": (
                "Could not leave disabled mode: "
                "{}".format(exc)
            ),
            "state": selector_state(),
        }

    try:
        os.remove(STATE_FILE)
    except FileNotFoundError:
        pass
    except Exception:
        pass

    code = request_refresh()

    if code == 0:
        return {
            "ok": True,
            "code": code,
            "message": (
                "VPN protection enabled."
            ),
            "state": selector_state(),
        }

    # Deliberately DO NOT recreate the disabled marker.
    # The bootstrap guard is already active, so selector
    # failure must remain fail-closed.
    return {
        "ok": False,
        "code": code,
        "message": (
            "Protected selection failed. "
            "Fail-closed protection remains active."
        ),
        "state": selector_state(),
    }



def disconnect(profile):
    if not isinstance(profile, dict):
        return _profile_error(
            "Invalid VPN profile"
        )

    #
    # Never deliberately remove the local protected path unless
    # the selector has already established that the router VPN
    # is the authoritative protected path.
    #
    state = selector_state()

    if state != "router":
        return {
            "ok": False,
            "code": None,
            "message": (
                "Local VPN disconnect refused: "
                "no verified upstream VPN path"
            ),
            "state": state,
        }

    if not SYSTEMCTL:
        return _profile_error(
            "systemctl unavailable"
        )

    try:
        result = subprocess.run(
            [
                SYSTEMCTL,
                "stop",
                MANAGED_OPENVPN_SERVICE,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=30,
        )

        return {
            "ok": result.returncode == 0,
            "code": result.returncode,
            "message": (
                "Managed local VPN stopped; "
                "verified router VPN retained"
            ),
            "state": state,
        }

    except Exception as exc:
        return {
            "ok": False,
            "code": None,
            "message": str(exc),
            "state": state,
        }


def supported_profile_types():
    return ["openvpn"]


def active_profile_path():
    """Return the config path used by the live OpenVPN process."""
    import os

    try:
        pids = os.listdir("/proc")
    except OSError:
        return None

    for pid in pids:
        if not pid.isdigit():
            continue

        try:
            with open(
                "/proc/{}/cmdline".format(pid),
                "rb",
            ) as f:
                raw = f.read()
        except (OSError, IOError):
            continue

        if not raw:
            continue

        args = [
            part.decode(
                "utf-8",
                errors="replace",
            )
            for part in raw.split(b"\0")
            if part
        ]

        if not args:
            continue

        if os.path.basename(args[0]) != "openvpn":
            continue

        for index, arg in enumerate(args):
            if (
                arg == "--config"
                and index + 1 < len(args)
            ):
                return args[index + 1]

    return None
def active_profile_id(data=None):
    """
    Return the profile ID actually represented by the live
    OpenVPN process.

    A normal profile can be identified directly from --config.
    A pinned beta17 handoff uses the effective /run config, so
    its runtime target file supplies the original profile ID.
    """
    active_path = active_profile_path()

    if not active_path:
        return None

    if data is None:
        try:
            data = profile_registry.load(
                PROFILE_REGISTRY
            )
        except Exception:
            return None

    direct = _profile_id_for_path(
        data,
        active_path,
    )

    if direct:
        return direct

    try:
        effective = (
            os.path.realpath(active_path)
            == os.path.realpath(
                EFFECTIVE_OPENVPN_CONFIG
            )
        )
    except Exception:
        effective = (
            active_path
            == EFFECTIVE_OPENVPN_CONFIG
        )

    if not effective:
        return None

    try:
        with open(
            RUNTIME_TARGET_FILE,
            "r",
            encoding="utf-8",
        ) as f:
            target = json.load(f)
    except Exception:
        return None

    profile_id = str(
        target.get("profile_id", "")
    ).strip()

    if not profile_id:
        return None

    # Do not trust an arbitrary marker ID. It must exist in
    # the current registry.
    for profile in profile_registry.profiles(
        data
    ):
        if profile.get("id") == profile_id:
            return profile_id

    return None
