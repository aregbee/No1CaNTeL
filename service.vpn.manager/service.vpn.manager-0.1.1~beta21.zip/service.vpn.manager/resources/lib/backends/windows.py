import os
import re
import shutil
import subprocess


BACKEND_ID = "windows"
BACKEND_NAME = "Windows"

CAN_MONITOR = True


def _find_program(filename, candidates):
    found = shutil.which(filename)

    if found:
        return found

    for candidate in candidates:
        if candidate and os.path.isfile(candidate):
            return candidate

    return None


PROGRAM_FILES = os.environ.get("ProgramFiles", r"C:\Program Files")
PROGRAM_FILES_X86 = os.environ.get(
    "ProgramFiles(x86)",
    r"C:\Program Files (x86)"
)

OPENVPN_GUI = _find_program(
    "openvpn-gui.exe",
    (
        os.path.join(
            PROGRAM_FILES,
            "OpenVPN",
            "bin",
            "openvpn-gui.exe"
        ),
        os.path.join(
            PROGRAM_FILES_X86,
            "OpenVPN",
            "bin",
            "openvpn-gui.exe"
        ),
    )
)

WIREGUARD = _find_program(
    "wireguard.exe",
    (
        os.path.join(
            PROGRAM_FILES,
            "WireGuard",
            "wireguard.exe"
        ),
    )
)

CAN_MANAGE_OPENVPN = bool(OPENVPN_GUI)
CAN_MANAGE_WIREGUARD = bool(WIREGUARD)

CAN_MANAGE = (
    CAN_MANAGE_OPENVPN
    or CAN_MANAGE_WIREGUARD
)

MODE = "manager" if CAN_MANAGE else "monitor"


POWERSHELL = (
    shutil.which("powershell.exe")
    or shutil.which("powershell")
)

ROUTE = (
    shutil.which("route.exe")
    or shutil.which("route")
)


def run(args, timeout=8):
    if not args or not args[0]:
        return ""

    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=timeout,
            creationflags=getattr(
                subprocess,
                "CREATE_NO_WINDOW",
                0
            ),
        )

        if result.returncode == 0:
            return result.stdout.strip()

    except Exception:
        pass

    return ""


def powershell(command, timeout=8):
    if not POWERSHELL:
        return ""

    return run(
        [
            POWERSHELL,
            "-NoProfile",
            "-NonInteractive",
            "-ExecutionPolicy",
            "Bypass",
            "-Command",
            command,
        ],
        timeout=timeout,
    )


def active_adapters():
    data = powershell(
        """
Get-NetAdapter |
Where-Object {$_.Status -eq 'Up'} |
Select-Object -ExpandProperty Name
""".strip()
    )

    return [
        line.strip()
        for line in data.splitlines()
        if line.strip()
    ]


def vpn_adapters():
    names = active_adapters()
    found = []

    patterns = (
        r"wireguard",
        r"wintun",
        r"tap[- ]?windows",
        r"openvpn",
        r"\btun\b",
        r"\bvpn\b",
    )

    for name in names:
        low = name.lower()

        if any(
            re.search(pattern, low)
            for pattern in patterns
        ):
            found.append(name)

    return found


def default_route_interface():
    data = powershell(
        """
Get-NetRoute -AddressFamily IPv4 -DestinationPrefix '0.0.0.0/0' |
Where-Object {$_.State -eq 'Alive'} |
Sort-Object RouteMetric,InterfaceMetric |
Select-Object -First 1 -ExpandProperty InterfaceAlias
""".strip()
    )

    return data.splitlines()[0].strip() if data else ""


def interface_ip(interface):
    if not interface:
        return ""

    safe = interface.replace("'", "''")

    data = powershell(
        """
Get-NetIPAddress -AddressFamily IPv4 -InterfaceAlias '{}' |
Where-Object {{$_.IPAddress -notlike '169.254.*'}} |
Select-Object -First 1 -ExpandProperty IPAddress
""".format(safe).strip()
    )

    return data.splitlines()[0].strip() if data else ""


def routed_vpn_adapter():
    route_iface = default_route_interface()

    if not route_iface:
        return ""

    vpn_names = vpn_adapters()

    for name in vpn_names:
        if name.lower() == route_iface.lower():
            return name

    return ""


def state_token():
    adapters = vpn_adapters()
    routed = routed_vpn_adapter()

    return "{}|{}".format(
        ",".join(sorted(adapters)),
        routed,
    )


def request_refresh():
    # Detection-only until Windows management is added.
    return "monitor-only"


def refresh_in_progress():
    return False


def vpn_state():
    adapters = vpn_adapters()
    routed = routed_vpn_adapter()

    if routed:
        return {
            "path": "Windows VPN",
            "status": "VPN TUNNEL ACTIVE - VERIFYING",
            "interface": routed,
            "tunnel_ip": interface_ip(routed) or "N/A",
            "server": "Windows / app-managed",
            "killswitch": "Unknown",
            "verification": "VPN adapter is carrying default route",
            "local_tunnel": True,
            "backend_verified": False,
        }

    if adapters:
        return {
            "path": "Windows VPN",
            "status": "VPN DETECTED - VERIFYING",
            "interface": ", ".join(adapters),
            "tunnel_ip": interface_ip(adapters[0]) or "N/A",
            "server": "Windows / app-managed",
            "killswitch": "Unknown",
            "verification": "VPN adapter detected; route unconfirmed",
            "local_tunnel": True,
            "backend_verified": False,
        }

    return {
        "path": "No local Windows VPN detected",
        "status": "MONITOR ONLY",
        "interface": "N/A",
        "tunnel_ip": "N/A",
        "server": "N/A",
        "killswitch": "Unknown",
        "verification": "No local VPN adapter visible",
        "local_tunnel": False,
        "backend_verified": False,
    }



def _control(args, timeout=30):
    if not args or not args[0]:
        return {
            "ok": False,
            "code": None,
            "message": "Manager executable unavailable",
        }

    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            creationflags=getattr(
                subprocess,
                "CREATE_NO_WINDOW",
                0
            ),
        )

        message = (
            result.stdout.strip()
            or result.stderr.strip()
        )

        return {
            "ok": result.returncode == 0,
            "code": result.returncode,
            "message": message,
        }

    except Exception as exc:
        return {
            "ok": False,
            "code": None,
            "message": str(exc),
        }


def connect_openvpn(profile_path):
    if not OPENVPN_GUI:
        return {
            "ok": False,
            "code": None,
            "message": "OpenVPN GUI not installed",
        }

    profile_path = os.path.abspath(profile_path)

    if not os.path.isfile(profile_path):
        return {
            "ok": False,
            "code": None,
            "message": "OpenVPN profile not found",
        }

    if not profile_path.lower().endswith(".ovpn"):
        return {
            "ok": False,
            "code": None,
            "message": "Profile is not an .ovpn file",
        }

    config_dir = os.path.dirname(profile_path)
    config_name = os.path.splitext(
        os.path.basename(profile_path)
    )[0]

    return _control([
        OPENVPN_GUI,
        "--config_dir",
        config_dir,
        "--command",
        "connect",
        config_name,
    ])


def disconnect_openvpn(profile_path):
    if not OPENVPN_GUI:
        return {
            "ok": False,
            "code": None,
            "message": "OpenVPN GUI not installed",
        }

    profile_path = os.path.abspath(profile_path)

    config_dir = os.path.dirname(profile_path)
    config_name = os.path.splitext(
        os.path.basename(profile_path)
    )[0]

    return _control([
        OPENVPN_GUI,
        "--config_dir",
        config_dir,
        "--command",
        "disconnect",
        config_name,
    ])


def connect_wireguard(profile_path):
    if not WIREGUARD:
        return {
            "ok": False,
            "code": None,
            "message": "WireGuard for Windows not installed",
        }

    profile_path = os.path.abspath(profile_path)

    if not os.path.isfile(profile_path):
        return {
            "ok": False,
            "code": None,
            "message": "WireGuard profile not found",
        }

    if not profile_path.lower().endswith(".conf"):
        return {
            "ok": False,
            "code": None,
            "message": "Profile is not a WireGuard .conf file",
        }

    return _control([
        WIREGUARD,
        "/installtunnelservice",
        profile_path,
    ])


def disconnect_wireguard(profile_path):
    if not WIREGUARD:
        return {
            "ok": False,
            "code": None,
            "message": "WireGuard for Windows not installed",
        }

    tunnel_name = os.path.splitext(
        os.path.basename(profile_path)
    )[0]

    return _control([
        WIREGUARD,
        "/uninstalltunnelservice",
        tunnel_name,
    ])


def connect(profile):
    if not isinstance(profile, dict):
        return {
            "ok": False,
            "code": None,
            "message": "Invalid VPN profile",
        }

    if not profile.get("enabled", True):
        return {
            "ok": False,
            "code": None,
            "message": "VPN profile is disabled",
        }

    profile_type = str(
        profile.get("type", "")
    ).strip().lower()

    profile_path = str(
        profile.get("path", "")
    ).strip()

    if profile_type == "openvpn":
        return connect_openvpn(
            profile_path
        )

    if profile_type == "wireguard":
        return connect_wireguard(
            profile_path
        )

    return {
        "ok": False,
        "code": None,
        "message": "Unsupported VPN profile type",
    }


def disconnect(profile):
    if not isinstance(profile, dict):
        return {
            "ok": False,
            "code": None,
            "message": "Invalid VPN profile",
        }

    profile_type = str(
        profile.get("type", "")
    ).strip().lower()

    profile_path = str(
        profile.get("path", "")
    ).strip()

    if profile_type == "openvpn":
        return disconnect_openvpn(
            profile_path
        )

    if profile_type == "wireguard":
        return disconnect_wireguard(
            profile_path
        )

    return {
        "ok": False,
        "code": None,
        "message": "Unsupported VPN profile type",
    }


def can_manage_profile(profile):
    if not isinstance(profile, dict):
        return False

    profile_type = str(
        profile.get("type", "")
    ).strip().lower()

    if profile_type == "openvpn":
        return CAN_MANAGE_OPENVPN

    if profile_type == "wireguard":
        return CAN_MANAGE_WIREGUARD

    return False


def supported_profile_types():
    result = []

    if CAN_MANAGE_OPENVPN:
        result.append("openvpn")

    if CAN_MANAGE_WIREGUARD:
        result.append("wireguard")

    return result
