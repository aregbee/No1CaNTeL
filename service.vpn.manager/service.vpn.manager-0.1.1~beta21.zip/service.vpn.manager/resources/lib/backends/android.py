import os
import ipaddress
import re
import shutil
import socket
import subprocess
import time

try:
    import xbmcaddon
except Exception:
    xbmcaddon = None



ADDON_ID = "service.vpn.manager"


def _addon_setting(setting_id, default=""):
    if xbmcaddon is None:
        return default

    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        value = addon.getSetting(setting_id)

        if value == "":
            return default

        return value

    except Exception:
        return default


def _setting_bool(setting_id, default=False):
    fallback = "true" if default else "false"

    value = _addon_setting(
        setting_id,
        fallback
    )

    return str(value).strip().lower() in (
        "true",
        "1",
        "yes",
        "on",
    )


def _split_setting_values(value):
    if not value:
        return []

    values = []

    for item in re.split(r"[,;\n]+", value):
        item = item.strip()

        if item:
            values.append(item)

    return values


def _trusted_management_settings():
    #
    # Returns:
    #   allow_local_lan
    #   normalized IPv4 CIDRs
    #   validation errors
    #
    allow_local_lan = _setting_bool(
        "allow_local_lan",
        True
    )

    networks_raw = _split_setting_values(
        _addon_setting(
            "trusted_management_networks",
            ""
        )
    )

    hosts_raw = _split_setting_values(
        _addon_setting(
            "trusted_management_hosts",
            ""
        )
    )

    trusted = []
    errors = []

    for value in networks_raw:
        try:
            network = ipaddress.ip_network(
                value,
                strict=False
            )

            if network.version != 4:
                raise ValueError("IPv6 is not supported here")

            normalized = str(network)

            if normalized not in trusted:
                trusted.append(normalized)

        except Exception:
            errors.append(
                "Invalid trusted management network: {}".format(
                    value
                )
            )

    for value in hosts_raw:
        try:
            address = ipaddress.ip_address(
                value
            )

            if address.version != 4:
                raise ValueError("IPv6 is not supported here")

            normalized = "{}/32".format(
                address
            )

            if normalized not in trusted:
                trusted.append(normalized)

        except Exception:
            errors.append(
                "Invalid trusted management host: {}".format(
                    value
                )
            )

    return {
        "allow_local_lan": allow_local_lan,
        "trusted_ipv4": trusted,
        "errors": errors,
    }


def _vpn_dns_fallback():
    value = str(
        _addon_setting(
            "vpn_dns_fallback",
            "1.1.1.1"
        )
    ).strip()

    try:
        address = ipaddress.ip_address(value)

        if address.version != 4:
            raise ValueError("IPv6 DNS is not supported")

        return str(address), ""

    except Exception:
        return (
            "",
            "Invalid fallback VPN DNS server: {}".format(
                value or "(empty)"
            ),
        )




BACKEND_ID = "android"
BACKEND_NAME = "Android"
MODE = "monitor"

CAN_MONITOR = True
CAN_MANAGE = False


IP = shutil.which("ip")

TUNNEL_PATTERNS = (
    r"^tun\d*$",
    r"^tap\d*$",
    r"^wg\d*$",
    r"^ppp\d*$",
    r"^ipsec\d*$",
)


def run(args, timeout=5):
    if not args or not args[0]:
        return ""

    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=timeout
        )

        if result.returncode == 0:
            return result.stdout.strip()

    except Exception:
        pass

    return ""


def interfaces():
    path = "/sys/class/net"

    try:
        return sorted(os.listdir(path))
    except Exception:
        return []


def tunnel_interfaces():
    found = []

    for iface in interfaces():
        for pattern in TUNNEL_PATTERNS:
            if re.match(pattern, iface, re.IGNORECASE):
                found.append(iface)
                break

    return found


def internet_route():
    if not IP:
        return ""

    return run([
        IP,
        "-4",
        "route",
        "get",
        "1.1.1.1"
    ])


def routed_tunnel():
    route = internet_route()

    for iface in tunnel_interfaces():
        if "dev {}".format(iface) in route:
            return iface

    return ""


def interface_ip(iface):
    if not IP or not iface:
        return ""

    data = run([
        IP,
        "-4",
        "-o",
        "addr",
        "show",
        "dev",
        iface
    ])

    match = re.search(
        r"\binet\s+([0-9.]+)/",
        data
    )

    return match.group(1) if match else ""


def state_token():
    tunnels = tunnel_interfaces()
    routed = routed_tunnel()

    return "{}|{}".format(
        ",".join(tunnels),
        routed
    )


def request_refresh():
    # Standard Android is monitor-only.
    # VPN creation/control remains with Android or the VPN app.
    return "monitor-only"


def refresh_in_progress():
    return False


def vpn_state():
    tunnels = tunnel_interfaces()
    routed = routed_tunnel()

    #
    # Strongest local indication: Internet route is using
    # an Android tunnel interface.
    #
    if routed:
        return {
            "path": "Android VPN",
            "status": "Protected",
            "interface": routed,
            "tunnel_ip": interface_ip(routed) or "N/A",
            "server": "App / Android-managed",
            "killswitch": "Android-managed",
            "verification": "VPN tunnel route detected",
            "local_tunnel": True,
            "backend_verified": False,
        }

    #
    # A tunnel exists, but Android routing policy does not expose
    # enough information to prove that Kodi traffic uses it.
    #
    if tunnels:
        return {
            "path": "Android VPN",
            "status": "VPN DETECTED - VERIFYING",
            "interface": ", ".join(tunnels),
            "tunnel_ip": interface_ip(tunnels[0]) or "N/A",
            "server": "App / Android-managed",
            "killswitch": "Android-managed",
            "verification": "Tunnel interface detected; route unconfirmed",
            "local_tunnel": True,
            "backend_verified": False,
        }

    #
    # No local Android VPN tunnel is visible.
    # This does NOT rule out an upstream/router VPN.
    #
    return {
        "path": "No local Android VPN detected",
        "status": "MONITOR ONLY",
        "interface": "N/A",
        "tunnel_ip": "N/A",
        "server": "N/A",
        "killswitch": "Android-managed",
        "verification": "No local VPN tunnel visible",
        "local_tunnel": False,
        "backend_verified": False,
    }




SU = shutil.which("su")
GETPROP = shutil.which("getprop") or "/system/bin/getprop"

ADDON_ROOT = os.path.abspath(
    os.path.join(
        os.path.dirname(__file__),
        "..",
        "..",
        "..",
    )
)

_ROOT_CHECKED = False
_ROOT_READY = False
_ANDROID_ABI = ""
_OPENVPN_ENGINE = ""
_OPENVPN_LIBDIR = ""
_DNSPROXY_ENGINE = ""
_WG_ENGINE = ""
_WG_QUICK_ENGINE = ""


def _plain_command(args, timeout=5):
    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=timeout,
        )

        if result.returncode == 0:
            return result.stdout.strip()

    except Exception:
        pass

    return ""


def android_abi():
    global _ANDROID_ABI

    if _ANDROID_ABI:
        return _ANDROID_ABI

    value = _plain_command(
        [GETPROP, "ro.product.cpu.abi"]
    ).strip()

    aliases = {
        "armeabi-v7a": "armeabi-v7a",
        "arm64-v8a": "arm64-v8a",
        "x86": "x86",
        "x86_64": "x86_64",
    }

    _ANDROID_ABI = aliases.get(
        value,
        value or "unknown"
    )

    return _ANDROID_ABI


def _bundled_engine(name):
    abi = android_abi()

    candidate = os.path.join(
        ADDON_ROOT,
        "resources",
        "bin",
        "android",
        abi,
        "bin",
        name,
    )

    if os.path.isfile(candidate):
        return candidate

    return ""



def _root_command(command, timeout=15):
    if not SU:
        return ""

    try:
        result = subprocess.run(
            [
                SU,
                "-c",
                command,
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=timeout,
        )

        if result.returncode == 0:
            return result.stdout.strip()

    except Exception:
        pass

    return ""


def _stage_bundled_openvpn():
    source = _bundled_engine("openvpn")

    if not source:
        return "", ""

    runtime = (
        "/data/local/tmp/"
        "kodi-vpn-manager/openvpn"
    )

    runtime_bin = runtime + "/bin"
    runtime_tmp = runtime + "/tmp"
    executable = runtime_bin + "/openvpn"
    incoming = runtime_bin + "/openvpn.new"

    def q(value):
        return "'" + str(value).replace(
            "'",
            "'\\''"
        ) + "'"

    commands = [
        "mkdir -p {} {}".format(
            q(runtime_bin),
            q(runtime_tmp)
        ),
        "rm -f {}".format(q(incoming)),
        "cp {} {}".format(
            q(source),
            q(incoming)
        ),
        "chmod 755 {}".format(q(incoming)),
        "mv -f {} {}".format(
            q(incoming),
            q(executable)
        ),
    ]

    _root_command(
        " && ".join(commands),
        timeout=30
    )

    check = _root_command(
        "{} --version".format(
            q(executable)
        ),
        timeout=20
    )

    if "OpenVPN" not in check:
        return "", ""

    return executable, ""


def _stage_bundled_dnsproxy():
    source = _bundled_engine("dnsproxy")

    if not source:
        return ""

    runtime = (
        "/data/local/tmp/"
        "kodi-vpn-manager/dnsproxy"
    )

    runtime_bin = runtime + "/bin"
    executable = runtime_bin + "/dnsproxy"
    incoming = runtime_bin + "/dnsproxy.new"

    def q(value):
        return "'" + str(value).replace(
            "'",
            "'\\''"
        ) + "'"

    commands = [
        "mkdir -p {}".format(
            q(runtime_bin)
        ),
        "rm -f {}".format(
            q(incoming)
        ),
        "cp {} {}".format(
            q(source),
            q(incoming)
        ),
        "chmod 755 {}".format(
            q(incoming)
        ),
        "mv -f {} {}".format(
            q(incoming),
            q(executable)
        ),
    ]

    _root_command(
        " && ".join(commands),
        timeout=30
    )

    check = _root_command(
        "{} --version".format(
            q(executable)
        ),
        timeout=10
    )

    if "kvm-dnsproxy" not in check:
        return ""

    return executable



def _generic_system_engine(name):
    value = _root_command(
        "command -v {}".format(name)
    )

    if not value:
        return ""

    return value.splitlines()[0].strip()


def _detect_root_and_engines():
    global _ROOT_CHECKED
    global _ROOT_READY
    global _OPENVPN_ENGINE
    global _OPENVPN_LIBDIR
    global _DNSPROXY_ENGINE
    global _WG_ENGINE
    global _WG_QUICK_ENGINE

    if _ROOT_CHECKED:
        return

    _ROOT_CHECKED = True

    if not SU:
        return

    if _root_command("id -u") != "0":
        return

    _ROOT_READY = True

    #
    # Prefer engines shipped/managed by Kodi VPN Manager.
    # Generic system CLIs are allowed as a fallback.
    #
    bundled_openvpn, bundled_libdir = (
        _stage_bundled_openvpn()
    )

    if bundled_openvpn:
        _OPENVPN_ENGINE = bundled_openvpn
        _OPENVPN_LIBDIR = bundled_libdir
    else:
        _OPENVPN_ENGINE = _generic_system_engine(
            "openvpn"
        )
        _OPENVPN_LIBDIR = ""

    #
    # DNS forwarding is manager-owned. Do not depend on
    # dnsmasq or another ROM-provided DNS daemon.
    #
    _DNSPROXY_ENGINE = _stage_bundled_dnsproxy()

    _WG_ENGINE = (
        _bundled_engine("wg")
        or _generic_system_engine("wg")
    )

    _WG_QUICK_ENGINE = (
        _bundled_engine("wg-quick")
        or _generic_system_engine("wg-quick")
    )


def runtime_capabilities(interactive=False):
    #
    # Never request root from the background Kodi service.
    #
    if not interactive:
        return {
            "name": "Android",
            "mode": "monitor",
            "can_monitor": True,
            "can_manage": False,
        }

    _detect_root_and_engines()

    if not _ROOT_READY:
        return {
            "name": "Android",
            "mode": "monitor",
            "can_monitor": True,
            "can_manage": False,
            "rooted": False,
            "abi": android_abi(),
        }

    manageable = bool(
        _OPENVPN_ENGINE
        or (
            _WG_ENGINE
            and _WG_QUICK_ENGINE
        )
    )

    return {
        "name": (
            "Android (rooted)"
            if manageable
            else "Android (rooted, engine missing)"
        ),
        "mode": (
            "manager"
            if manageable
            else "monitor"
        ),
        "can_monitor": True,
        "can_manage": manageable,
        "rooted": True,
        "abi": android_abi(),
        "openvpn_engine": bool(_OPENVPN_ENGINE),
        "wireguard_engine": bool(
            _WG_ENGINE
            and _WG_QUICK_ENGINE
        ),
    }


def supported_profile_types():
    _detect_root_and_engines()

    result = []

    if _ROOT_READY and _OPENVPN_ENGINE:
        result.append("openvpn")

    if (
        _ROOT_READY
        and _WG_ENGINE
        and _WG_QUICK_ENGINE
    ):
        result.append("wireguard")

    return result


def can_manage_profile(profile):
    if not isinstance(profile, dict):
        return False

    if not profile.get("enabled", True):
        return False

    profile_type = str(
        profile.get("type", "")
    ).strip().lower()

    return profile_type in supported_profile_types()

MANAGED_RUNTIME = "/data/local/tmp/kodi-vpn-manager/openvpn"
MANAGED_PID = MANAGED_RUNTIME + "/openvpn.pid"
MANAGED_LOG = MANAGED_RUNTIME + "/openvpn.log"
MANAGED_TMP = MANAGED_RUNTIME + "/tmp"

ANDROID_IP = "/system/bin/ip"

MANAGED_ROUTE_PREF = 12000

MANAGEMENT_CHAIN = "KVM_MGMT"
MANAGEMENT_ROUTE_PROTO = 99
MANAGEMENT_ROUTES_FILE = (
    MANAGED_RUNTIME + "/management-routes"
)

FILTER_CHAIN = "KVM_OUT"
IP6_FILTER_CHAIN = "KVM6_OUT"
DNS_CHAIN = "KVM_DNS"

DNSPROXY_RUNTIME = (
    "/data/local/tmp/kodi-vpn-manager/dnsproxy"
)
DNSPROXY_PID = DNSPROXY_RUNTIME + "/dnsproxy.pid"
DNSPROXY_LOG = DNSPROXY_RUNTIME + "/dnsproxy.log"
DNSPROXY_STATE = DNSPROXY_RUNTIME + "/dnsproxy.state"

DNSPROXY_LISTEN_PORT = 1053
DNSPROXY_SOURCE_PORT = 1054

# Compatibility default. Runtime DNS selection will use
# vpn_dns_fallback and later prefer VPN-pushed DNS.
DEFAULT_VPN_DNS = "1.1.1.1"


def _shell_quote(value):
    return "'" + str(value).replace(
        "'",
        "'\\''"
    ) + "'"



def _dnsproxy_pid():
    value = _root_command(
        "cat {} 2>/dev/null".format(
            _shell_quote(DNSPROXY_PID)
        )
    ).strip()

    return value if value.isdigit() else ""


def _dnsproxy_running():
    pid = _dnsproxy_pid()

    if not pid:
        return False

    result = _root_command(
        "kill -0 {} 2>/dev/null && echo running".format(
            pid
        )
    )

    return result.strip() == "running"


def _dnsproxy_state():
    data = _root_command(
        "cat {} 2>/dev/null".format(
            _shell_quote(DNSPROXY_STATE)
        )
    )

    lines = [
        line.strip()
        for line in data.splitlines()
        if line.strip()
    ]

    return {
        "listener": lines[0] if len(lines) > 0 else "",
        "upstream": lines[1] if len(lines) > 1 else "",
    }


def _write_dnsproxy_state(listener, upstream):
    command = (
        "mkdir -p {runtime} && "
        "printf '%s\\n%s\\n' {listener} {upstream} "
        "> {state}"
    ).format(
        runtime=_shell_quote(DNSPROXY_RUNTIME),
        listener=_shell_quote(listener),
        upstream=_shell_quote(upstream),
        state=_shell_quote(DNSPROXY_STATE),
    )

    _root_command(command)

    state = _dnsproxy_state()

    return (
        state.get("listener") == listener
        and state.get("upstream") == upstream
    )


def _physical_ipv4_address(iface):
    if not iface:
        return ""

    data = _root_command(
        "{ip} -4 -o addr show dev {iface} 2>/dev/null".format(
            ip=ANDROID_IP,
            iface=_shell_quote(iface)
        )
    )

    match = re.search(
        r"\binet\s+([0-9.]+)/",
        data
    )

    return match.group(1) if match else ""


def _dns_upstream_uses_tunnel(address):
    if not address:
        return False

    route = _root_command(
        "{ip} -4 route get {address} 2>/dev/null".format(
            ip=ANDROID_IP,
            address=_shell_quote(address)
        )
    )

    return bool(
        re.search(
            r"\bdev\s+tun[0-9]*\b",
            route
        )
    )


def _stop_dnsproxy(remove_state=False):
    pid = _dnsproxy_pid()
    if pid:
        _root_command("kill {} 2>/dev/null || true".format(pid))
        time.sleep(0.2)
        if _root_command("kill -0 {} 2>/dev/null && echo running".format(pid)).strip() == "running":
            _root_command("kill -9 {} 2>/dev/null || true".format(pid))
            time.sleep(0.2)
            if _root_command("kill -0 {} 2>/dev/null && echo running".format(pid)).strip() == "running":
                return False

    paths = [DNSPROXY_PID]
    if remove_state:
        paths.append(DNSPROXY_STATE)

    _root_command(
        "rm -f " + " ".join(
            _shell_quote(path)
            for path in paths
        )
    )
    return True

def _start_dnsproxy(listener, upstream):
    global _DNSPROXY_ENGINE

    try:
        listener = str(
            ipaddress.ip_address(listener)
        )
        upstream = str(
            ipaddress.ip_address(upstream)
        )

        if (
            ipaddress.ip_address(listener).version != 4
            or ipaddress.ip_address(upstream).version != 4
        ):
            raise ValueError()

    except Exception:
        return False, "Invalid Android DNS proxy IPv4 address"

    if not _dns_upstream_uses_tunnel(upstream):
        return (
            False,
            "VPN DNS server is not routed through the tunnel",
        )

    # A surviving proxy may hold sockets created against an older
    # tunnel state. Recreate them after every successful VPN
    # connection/reconnection.
    if not _stop_dnsproxy(remove_state=False):
        return False, "Could not restart Android DNS proxy"


    if not _DNSPROXY_ENGINE:
        _DNSPROXY_ENGINE = _stage_bundled_dnsproxy()

    if not _DNSPROXY_ENGINE:
        return False, "Bundled Android DNS proxy is unavailable"

    command = (
        "mkdir -p {runtime}; "
        "rm -f {pid} {log}; "
        "{engine} "
        "--listen {listener} "
        "--port {listen_port} "
        "--upstream {upstream} "
        "--source-port {source_port} "
        "> {log} 2>&1 & "
        "echo $! > {pid}"
    ).format(
        runtime=_shell_quote(DNSPROXY_RUNTIME),
        pid=_shell_quote(DNSPROXY_PID),
        log=_shell_quote(DNSPROXY_LOG),
        engine=_shell_quote(_DNSPROXY_ENGINE),
        listener=_shell_quote(listener),
        listen_port=DNSPROXY_LISTEN_PORT,
        upstream=_shell_quote(upstream),
        source_port=DNSPROXY_SOURCE_PORT,
    )

    _root_command(
        command,
        timeout=10
    )

    time.sleep(0.5)

    if not _dnsproxy_running():
        return False, "Android DNS proxy failed to start"

    if not _write_dnsproxy_state(
        listener,
        upstream
    ):
        _stop_dnsproxy(remove_state=True)

        return False, "Could not record Android DNS proxy state"

    return True, ""



def _managed_pid():
    value = _root_command(
        "cat {} 2>/dev/null".format(
            _shell_quote(MANAGED_PID)
        )
    ).strip()

    return value if value.isdigit() else ""


def _managed_running():
    pid = _managed_pid()

    if not pid:
        return False

    result = _root_command(
        "kill -0 {} 2>/dev/null && echo running".format(
            pid
        )
    )

    return result.strip() == "running"


def _managed_log_tail(lines=40):
    return _root_command(
        "tail -{} {} 2>/dev/null".format(
            int(lines),
            _shell_quote(MANAGED_LOG)
        )
    )


def _managed_initialized():
    result = _root_command(
        "grep -F "
        "'Initialization Sequence Completed' "
        "{} >/dev/null 2>&1 && echo ready".format(
            _shell_quote(MANAGED_LOG)
        )
    )

    return result.strip() == "ready"


def _managed_route_interface():
    route = _root_command(
        "{} -4 route get 1.1.1.1 2>/dev/null".format(
            ANDROID_IP
        )
    )

    match = re.search(
        r"\bdev\s+((?:tun|tap|wg|ppp)\d*)\b",
        route
    )

    return match.group(1) if match else ""


def _routing_rule_state():
    rules = _root_command(
        "{} rule show".format(
            ANDROID_IP
        )
    )

    ours = False
    collision = False
    prefix = "{}:".format(
        MANAGED_ROUTE_PREF
    )

    for line in rules.splitlines():
        line = line.strip()

        if not line.startswith(prefix):
            continue

        if (
            "iif lo" in line
            and "lookup main" in line
        ):
            ours = True
        else:
            collision = True

    return ours, collision


def _install_managed_route_rule():
    ours, collision = _routing_rule_state()

    if ours:
        return True, ""

    if collision:
        return (
            False,
            "Android routing priority {} is already in use".format(
                MANAGED_ROUTE_PREF
            )
        )

    result = _root_command(
        "{} rule add pref {} iif lo lookup main "
        "&& echo added".format(
            ANDROID_IP,
            MANAGED_ROUTE_PREF
        )
    )

    ours, _ = _routing_rule_state()

    if "added" not in result or not ours:
        return (
            False,
            "Could not install Android VPN routing rule"
        )

    return True, ""


def _remove_managed_route_rule():
    ours, _ = _routing_rule_state()

    if not ours:
        return

    _root_command(
        "{} rule del pref {} iif lo lookup main "
        "2>/dev/null || true".format(
            ANDROID_IP,
            MANAGED_ROUTE_PREF
        )
    )



def _profile_remote_hosts(profile_path):
    data = _root_command(
        "grep -E '^[[:space:]]*remote[[:space:]]+' "
        "{} 2>/dev/null".format(
            _shell_quote(profile_path)
        )
    )

    result = []

    for line in data.splitlines():
        parts = line.strip().split()

        if len(parts) < 2:
            continue

        host = parts[1].strip()

        if host and host not in result:
            result.append(host)

    return result


def _resolve_ipv4_hosts(hosts):
    addresses = []

    for host in hosts:
        try:
            socket.inet_aton(host)

            if host not in addresses:
                addresses.append(host)

            continue

        except Exception:
            pass

        try:
            infos = socket.getaddrinfo(
                host,
                None,
                socket.AF_INET,
                socket.SOCK_DGRAM
            )

            for info in infos:
                address = info[4][0]

                if address not in addresses:
                    addresses.append(address)

        except Exception:
            pass

    return addresses



def _remove_stale_remote_routes(remote_addresses):
    #
    # OpenVPN installs an exact host route in table main for its
    # server so the VPN transport itself stays on the physical
    # interface.  Android can leave that route behind after the
    # tunnel stops.
    #
    # Remove ONLY exact /32 routes for this profile's resolved
    # VPN server addresses.  Android's separate wlan0/netId
    # routing table is untouched.
    #
    routes = _root_command(
        "{} -4 route show table main 2>/dev/null".format(
            ANDROID_IP
        )
    )

    stale = []

    for line in routes.splitlines():
        parts = line.strip().split()

        if not parts:
            continue

        destination = parts[0]

        for address in remote_addresses:
            if (
                destination == address
                or destination == address + "/32"
            ):
                if address not in stale:
                    stale.append(address)

    for address in stale:
        _root_command(
            "{} -4 route del {} table main "
            "2>/dev/null || true".format(
                ANDROID_IP,
                _shell_quote(address)
            ),
            timeout=10
        )

    #
    # Verify that none of those exact host routes remain.
    #
    routes = _root_command(
        "{} -4 route show table main 2>/dev/null".format(
            ANDROID_IP
        )
    )

    for line in routes.splitlines():
        parts = line.strip().split()

        if not parts:
            continue

        destination = parts[0]

        for address in remote_addresses:
            if (
                destination == address
                or destination == address + "/32"
            ):
                return False

    return True



def _recorded_management_routes():
    data = _root_command(
        "cat {} 2>/dev/null || true".format(
            _shell_quote(MANAGEMENT_ROUTES_FILE)
        )
    )

    result = []

    for line in data.splitlines():
        value = line.strip()

        if not value:
            continue

        try:
            network = ipaddress.ip_network(
                value,
                strict=False
            )

            if network.version != 4:
                continue

            normalized = str(network)

            if normalized not in result:
                result.append(normalized)

        except Exception:
            continue

    return result


def _write_management_routes(routes):
    routes = list(dict.fromkeys(routes))

    if not routes:
        _root_command(
            "rm -f {}".format(
                _shell_quote(MANAGEMENT_ROUTES_FILE)
            )
        )

        return True

    payload = "\n".join(routes) + "\n"

    command = (
        "mkdir -p {runtime} && "
        "printf %s {payload} > {state}"
    ).format(
        runtime=_shell_quote(MANAGED_RUNTIME),
        payload=_shell_quote(payload),
        state=_shell_quote(MANAGEMENT_ROUTES_FILE)
    )

    _root_command(
        command,
        timeout=10
    )

    verify = _recorded_management_routes()

    return sorted(verify) == sorted(routes)



def _remove_management_routes():
    owned = _recorded_management_routes()

    if not owned:
        _root_command(
            "rm -f {}".format(
                _shell_quote(MANAGEMENT_ROUTES_FILE)
            )
        )
        return True

    for network in owned:
        _root_command(
            "{ip} -4 route del {network} "
            "proto {proto} table main "
            "2>/dev/null || true".format(
                ip=ANDROID_IP,
                network=_shell_quote(network),
                proto=MANAGEMENT_ROUTE_PROTO
            ),
            timeout=10
        )

    #
    # Verify only our exact proto-99 destinations disappeared.
    #
    routes = _root_command(
        "{} -4 route show table main 2>/dev/null".format(
            ANDROID_IP
        )
    )

    remaining = []

    for line in routes.splitlines():
        destination = _route_destination(line)

        if (
            destination in owned
            and re.search(
                r"(?:^|\s)proto\s+{}(?:\s|$)".format(
                    MANAGEMENT_ROUTE_PROTO
                ),
                line
            )
        ):
            if destination not in remaining:
                remaining.append(destination)

    if remaining:
        #
        # Preserve ownership state for anything that could not
        # be removed. Never forget a route we still own.
        #
        _write_management_routes(
            remaining
        )
        return False

    _root_command(
        "rm -f {}".format(
            _shell_quote(MANAGEMENT_ROUTES_FILE)
        )
    )

    return True

def _route_destination(line):
    parts = line.strip().split()

    if not parts:
        return ""

    value = parts[0]

    if value == "default":
        return "0.0.0.0/0"

    try:
        return str(
            ipaddress.ip_network(
                value,
                strict=False
            )
        )
    except Exception:
        try:
            address = ipaddress.ip_address(
                value
            )

            if address.version == 4:
                return "{}/32".format(address)

        except Exception:
            pass

    return ""


def _sync_management_routes(
    physical,
    settings
):
    iface = physical.get("iface", "")
    gateway = physical.get("gateway", "")
    subnet = physical.get("subnet", "")

    trusted = settings.get(
        "trusted_ipv4",
        []
    )

    old_owned = _recorded_management_routes()

    physical_network = None

    if subnet:
        try:
            physical_network = ipaddress.ip_network(
                subnet,
                strict=False
            )
        except Exception:
            physical_network = None

    desired = []

    for value in trusted:
        network = ipaddress.ip_network(
            value,
            strict=False
        )

        #
        # A destination already contained completely within the
        # directly connected LAN requires no manager route.
        #
        if (
            physical_network is not None
            and network.subnet_of(physical_network)
        ):
            continue

        desired.append(str(network))

    if desired and (not iface or not gateway):
        return (
            False,
            "Trusted management routes require a physical gateway"
        )

    routes_text = _root_command(
        "{} -4 route show table main 2>/dev/null".format(
            ANDROID_IP
        )
    )

    existing = {}

    for line in routes_text.splitlines():
        destination = _route_destination(line)

        if destination:
            existing[destination] = line.strip()

    newly_owned = []

    #
    # Install/refresh desired manager-owned routes first.
    # Existing non-manager routes are never overwritten.
    #
    for network in desired:
        current = existing.get(
            network,
            ""
        )

        if current and network not in old_owned:
            #
            # Another route already owns this exact destination.
            # Leave it untouched rather than replacing it.
            #
            continue

        command = (
            "{ip} -4 route replace {network} "
            "via {gateway} dev {iface} "
            "proto {proto} table main"
        ).format(
            ip=ANDROID_IP,
            network=_shell_quote(network),
            gateway=_shell_quote(gateway),
            iface=_shell_quote(iface),
            proto=MANAGEMENT_ROUTE_PROTO
        )

        _root_command(
            command,
            timeout=10
        )

        verify = _root_command(
            "{} -4 route show table main 2>/dev/null".format(
                ANDROID_IP
            )
        )

        found = False

        for line in verify.splitlines():
            if (
                _route_destination(line) == network
                and " proto {} ".format(
                    MANAGEMENT_ROUTE_PROTO
                ) in " {} ".format(line)
            ):
                found = True
                break

        if not found:
            return (
                False,
                "Could not install trusted management route: {}".format(
                    network
                )
            )

        newly_owned.append(network)

    #
    # Remove only routes that our previous state file says we
    # owned and that are no longer required.
    #
    for network in old_owned:
        if network in newly_owned:
            continue

        _root_command(
            "{ip} -4 route del {network} "
            "proto {proto} table main "
            "2>/dev/null || true".format(
                ip=ANDROID_IP,
                network=_shell_quote(network),
                proto=MANAGEMENT_ROUTE_PROTO
            ),
            timeout=10
        )

    if not _write_management_routes(
        newly_owned
    ):
        return (
            False,
            "Could not record trusted management routes"
        )

    return True, ""


def _sync_management_firewall(
    physical,
    settings
):
    iface = physical.get("iface", "")
    subnet = physical.get("subnet", "")

    if not iface:
        return (
            False,
            "Physical network interface is unavailable"
        )

    #
    # Remove the old beta11-style directly embedded LAN rule.
    # From beta12 onward local/trusted access lives only in the
    # dedicated KVM_MGMT subchain.
    #
    if subnet:
        _root_command(
            "while iptables -D {main} "
            "-d {subnet} -o {iface} -j ACCEPT "
            "2>/dev/null; do :; done".format(
                main=FILTER_CHAIN,
                subnet=_shell_quote(subnet),
                iface=_shell_quote(iface)
            )
        )

    commands = [
        "iptables -N {chain} "
        "2>/dev/null || true".format(
            chain=MANAGEMENT_CHAIN
        ),
        "iptables -F {chain}".format(
            chain=MANAGEMENT_CHAIN
        ),
    ]

    if (
        settings.get(
            "allow_local_lan",
            True
        )
        and subnet
    ):
        commands.append(
            "iptables -A {chain} "
            "-d {subnet} -o {iface} "
            "-j ACCEPT".format(
                chain=MANAGEMENT_CHAIN,
                subnet=_shell_quote(subnet),
                iface=_shell_quote(iface)
            )
        )

    for network in settings.get(
        "trusted_ipv4",
        []
    ):
        commands.append(
            "iptables -A {chain} "
            "-d {network} -o {iface} "
            "-j ACCEPT".format(
                chain=MANAGEMENT_CHAIN,
                network=_shell_quote(network),
                iface=_shell_quote(iface)
            )
        )

    commands.append(
        "iptables -A {chain} -j RETURN".format(
            chain=MANAGEMENT_CHAIN
        )
    )

    result = _root_command(
        " && ".join(commands)
        + " && echo management_ready",
        timeout=20
    )

    if "management_ready" not in result:
        return (
            False,
            "Could not configure trusted management firewall"
        )

    #
    # Hook the subchain into KVM_OUT without duplicating it.
    #
    hook = _root_command(
        "iptables -C {main} -j {chain} "
        "2>/dev/null || "
        "iptables -I {main} 2 -j {chain}; "
        "iptables -C {main} -j {chain} "
        "2>/dev/null && echo hooked".format(
            main=FILTER_CHAIN,
            chain=MANAGEMENT_CHAIN
        ),
        timeout=10
    )

    if "hooked" not in hook:
        return (
            False,
            "Could not hook trusted management firewall"
        )

    return True, ""


def _prepare_management_access(
    physical
):
    settings = _trusted_management_settings()

    errors = settings.get(
        "errors",
        []
    )

    if errors:
        return (
            False,
            "; ".join(errors),
            settings
        )

    ok, reason = _sync_management_routes(
        physical,
        settings
    )

    if not ok:
        return False, reason, settings

    ok, reason = _sync_management_firewall(
        physical,
        settings
    )

    if not ok:
        return False, reason, settings

    return True, "", settings


def _physical_network(remote_addresses=None):
    route = ""

    #
    # If connected, route to the VPN server itself identifies
    # the physical transport.  Before connection, use the normal
    # Internet route.
    #
    for address in remote_addresses or []:
        route = _root_command(
            "{} -4 route get {} 2>/dev/null".format(
                ANDROID_IP,
                address
            )
        )

        if route and " dev tun" not in route:
            break

    if not route or " dev tun" in route:
        route = _root_command(
            "{} -4 route get 1.1.1.1 2>/dev/null".format(
                ANDROID_IP
            )
        )

    match = re.search(
        r"\bdev\s+([A-Za-z0-9_.:-]+)",
        route
    )

    iface = match.group(1) if match else ""

    if not iface or iface.startswith("tun"):
        return {
            "iface": "",
            "subnet": "",
            "gateway": "",
            "dns": "",
        }

    gateway_match = re.search(
        r"\bvia\s+([0-9.]+)",
        route
    )

    gateway = (
        gateway_match.group(1)
        if gateway_match
        else ""
    )

    subnet = ""

    routes = _root_command(
        "{} -4 route show dev {} 2>/dev/null".format(
            ANDROID_IP,
            _shell_quote(iface)
        )
    )

    for line in routes.splitlines():
        first = line.strip().split()

        if not first:
            continue

        candidate = first[0]

        if "/" in candidate and re.match(
            r"^[0-9.]+/[0-9]+$",
            candidate
        ):
            subnet = candidate
            break

    dns = _root_command(
        "{} net.dns1".format(
            GETPROP
        )
    ).strip()

    return {
        "iface": iface,
        "subnet": subnet,
        "gateway": gateway,
        "dns": dns,
    }



def _remove_firewall():
    commands = [
        "while iptables -D OUTPUT -j {c} "
        "2>/dev/null; do :; done".format(
            c=FILTER_CHAIN
        ),

        "iptables -F {c} 2>/dev/null || true".format(
            c=FILTER_CHAIN
        ),
        "iptables -X {c} 2>/dev/null || true".format(
            c=FILTER_CHAIN
        ),

        "iptables -F {c} 2>/dev/null || true".format(
            c=MANAGEMENT_CHAIN
        ),
        "iptables -X {c} 2>/dev/null || true".format(
            c=MANAGEMENT_CHAIN
        ),

        "while iptables -t nat -D OUTPUT -j {c} "
        "2>/dev/null; do :; done".format(
            c=DNS_CHAIN
        ),
        "iptables -t nat -F {c} "
        "2>/dev/null || true".format(
            c=DNS_CHAIN
        ),
        "iptables -t nat -X {c} "
        "2>/dev/null || true".format(
            c=DNS_CHAIN
        ),

        "while ip6tables -D OUTPUT -j {c} "
        "2>/dev/null; do :; done".format(
            c=IP6_FILTER_CHAIN
        ),
        "ip6tables -F {c} "
        "2>/dev/null || true".format(
            c=IP6_FILTER_CHAIN
        ),
        "ip6tables -X {c} "
        "2>/dev/null || true".format(
            c=IP6_FILTER_CHAIN
        ),
    ]

    _root_command(
        "; ".join(commands),
        timeout=20
    )

def _firewall_active():
    result = _root_command(
        "iptables -C OUTPUT -j {} "
        "2>/dev/null && echo active".format(
            FILTER_CHAIN
        )
    )

    return result.strip() == "active"


def _install_ipv6_firewall(physical_iface):
    commands = [
        "ip6tables -N {c}".format(
            c=IP6_FILTER_CHAIN
        ),
        "ip6tables -A {c} -o lo -j ACCEPT".format(
            c=IP6_FILTER_CHAIN
        ),
        "ip6tables -A {c} -o tun+ -j ACCEPT".format(
            c=IP6_FILTER_CHAIN
        ),
    ]

    #
    # Preserve local IPv6 link-local communication only.
    #
    if physical_iface:
        commands.append(
            "ip6tables -A {c} -o {iface} "
            "-d fe80::/10 -j ACCEPT".format(
                c=IP6_FILTER_CHAIN,
                iface=_shell_quote(physical_iface)
            )
        )

    commands.extend([
        "ip6tables -A {c} -j REJECT".format(
            c=IP6_FILTER_CHAIN
        ),
        "ip6tables -I OUTPUT 1 -j {c}".format(
            c=IP6_FILTER_CHAIN
        ),
    ])

    result = _root_command(
        " && ".join(commands)
        + " && echo installed",
        timeout=20
    )

    return "installed" in result



def _install_bootstrap_firewall(
    physical,
    remote_addresses
):
    _remove_firewall()

    iface = physical.get("iface", "")
    dns = physical.get("dns", "")

    if not iface:
        return False, "Could not determine Android physical network interface"

    if not remote_addresses:
        return False, "Could not resolve VPN server address"

    #
    # Create the main chain first so KVM_MGMT can safely hook
    # into it.
    #
    result = _root_command(
        "iptables -N {c} && "
        "iptables -A {c} -o lo -j ACCEPT && "
        "echo base_ready".format(
            c=FILTER_CHAIN
        ),
        timeout=20
    )

    if "base_ready" not in result:
        _remove_firewall()

        return False, "Could not create Android IPv4 kill switch"

    management_ok, management_reason, settings = (
        _prepare_management_access(
            physical
        )
    )

    if not management_ok:
        _remove_firewall()
        _remove_management_routes()

        return False, management_reason

    commands = []

    #
    # DHCP renewal must remain possible.
    #
    commands.append(
        "iptables -A {c} -o {iface} "
        "-p udp --sport 68 --dport 67 "
        "-j ACCEPT".format(
            c=FILTER_CHAIN,
            iface=_shell_quote(iface)
        )
    )

    #
    # Bootstrap DNS is permitted only while OpenVPN establishes.
    #
    if dns and re.match(r"^[0-9.]+$", dns):
        commands.extend([
            "iptables -A {c} -o {iface} "
            "-d {dns} -p udp --dport 53 "
            "-j ACCEPT".format(
                c=FILTER_CHAIN,
                iface=_shell_quote(iface),
                dns=_shell_quote(dns)
            ),
            "iptables -A {c} -o {iface} "
            "-d {dns} -p tcp --dport 53 "
            "-j ACCEPT".format(
                c=FILTER_CHAIN,
                iface=_shell_quote(iface),
                dns=_shell_quote(dns)
            ),
        ])

    for address in remote_addresses:
        commands.append(
            "iptables -A {c} -o {iface} "
            "-d {address} -j ACCEPT".format(
                c=FILTER_CHAIN,
                iface=_shell_quote(iface),
                address=_shell_quote(address)
            )
        )

    commands.extend([
        "iptables -A {c} -o tun+ -j ACCEPT".format(
            c=FILTER_CHAIN
        ),
        "iptables -A {c} -j REJECT".format(
            c=FILTER_CHAIN
        ),
        "iptables -I OUTPUT 1 -j {c}".format(
            c=FILTER_CHAIN
        ),
    ])

    result = _root_command(
        " && ".join(commands)
        + " && echo installed",
        timeout=20
    )

    if "installed" not in result:
        _remove_firewall()
        _remove_management_routes()

        return False, "Could not install Android IPv4 kill switch"

    if not _install_ipv6_firewall(iface):
        _remove_firewall()
        _remove_management_routes()

        return False, "Could not install Android IPv6 kill switch"

    return True, ""


def _lock_firewall_to_tunnel(
    physical,
    remote_addresses,
    dns_address=None
):
    iface = physical.get("iface", "")

    if not iface:
        return False, "Physical network interface is unavailable"

    listener = _physical_ipv4_address(iface)

    if not listener:
        return False, "Could not determine Android DNS proxy listener address"

    if dns_address:
        try:
            candidate = ipaddress.ip_address(
                str(dns_address).strip()
            )

            if candidate.version != 4:
                raise ValueError()

            dns_address = str(candidate)

        except Exception:
            return False, "Invalid VPN DNS server"

    else:
        dns_address, dns_error = _vpn_dns_fallback()

        if dns_error:
            return False, dns_error

    settings = _trusted_management_settings()

    if settings.get("errors"):
        return (
            False,
            "; ".join(
                settings["errors"]
            )
        )

    ok, reason = _sync_management_routes(
        physical,
        settings
    )

    if not ok:
        return False, reason

    #
    # Rebuild KVM_OUT while keeping OUTPUT hooked throughout.
    #
    result = _root_command(
        "iptables -F {c} && "
        "iptables -A {c} -o lo -j ACCEPT && "
        "echo base_ready".format(
            c=FILTER_CHAIN
        ),
        timeout=20
    )

    if "base_ready" not in result:
        return False, "Could not rebuild Android IPv4 kill switch"

    ok, reason = _sync_management_firewall(
        physical,
        settings
    )

    if not ok:
        return False, reason

    commands = [
        "iptables -A {c} -o {iface} "
        "-p udp --sport 68 --dport 67 "
        "-j ACCEPT".format(
            c=FILTER_CHAIN,
            iface=_shell_quote(iface)
        )
    ]

    for address in remote_addresses:
        commands.append(
            "iptables -A {c} -o {iface} "
            "-d {address} -j ACCEPT".format(
                c=FILTER_CHAIN,
                iface=_shell_quote(iface),
                address=_shell_quote(address)
            )
        )

    #
    # Android/netd binds normal DNS to the physical network.
    # KVM_DNS rewrites those requests to this manager-owned
    # listener on the same physical IPv4 address.
    #
    commands.extend([
        "iptables -A {c} "
        "-d {listener} -p udp --dport {port} "
        "-j ACCEPT".format(
            c=FILTER_CHAIN,
            listener=_shell_quote(listener),
            port=DNSPROXY_LISTEN_PORT,
        ),
        "iptables -A {c} "
        "-d {listener} -p tcp --dport {port} "
        "-j ACCEPT".format(
            c=FILTER_CHAIN,
            listener=_shell_quote(listener),
            port=DNSPROXY_LISTEN_PORT,
        ),
        "iptables -A {c} -o tun+ -j ACCEPT".format(
            c=FILTER_CHAIN
        ),
        "iptables -A {c} -j REJECT".format(
            c=FILTER_CHAIN
        ),
    ])

    result = _root_command(
        " && ".join(commands)
        + " && echo locked",
        timeout=20
    )

    if "locked" not in result:
        return False, "Could not lock Android IPv4 kill switch"

    proxy_ok, proxy_reason = _start_dnsproxy(
        listener,
        dns_address
    )

    if not proxy_ok:
        return False, proxy_reason

    if not _install_dns_lock(
        listener=listener
    ):
        return False, "Could not install Android DNS lock"

    return True, ""

def _dns_lock_hooked():
    result = _root_command(
        "iptables -t nat -C OUTPUT -j {} "
        "2>/dev/null && echo active".format(
            DNS_CHAIN
        )
    )

    return result.strip() == "active"


def _suspend_dns_lock():
    #
    # During reconnect the IPv4/IPv6 kill switch remains armed.
    # Only the DNS DNAT hook is temporarily removed so the VPN
    # hostname can be resolved using the existing Android resolver.
    #
    _root_command(
        "while iptables -t nat -D OUTPUT -j {c} "
        "2>/dev/null; do :; done".format(
            c=DNS_CHAIN
        )
    )

    return not _dns_lock_hooked()


def _install_dns_lock(listener=None):
    #
    # Prefer the listener recorded by the active/previous
    # manager-owned DNS proxy. If none exists yet, redirect DNS
    # to a dead local sink so a failed fresh bootstrap remains
    # fail-closed rather than falling back to physical DNS.
    #
    if not listener:
        listener = _dnsproxy_state().get(
            "listener",
            ""
        )

    try:
        candidate = ipaddress.ip_address(
            str(listener).strip()
        )

        if candidate.version != 4:
            raise ValueError()

        listener = str(candidate)

    except Exception:
        listener = "127.0.0.1"

    destination = "{}:{}".format(
        listener,
        DNSPROXY_LISTEN_PORT
    )

    commands = [
        "while iptables -t nat -D OUTPUT -j {c} "
        "2>/dev/null; do :; done".format(
            c=DNS_CHAIN
        ),

        "iptables -t nat -N {c} "
        "2>/dev/null || true".format(
            c=DNS_CHAIN
        ),

        "iptables -t nat -F {c}".format(
            c=DNS_CHAIN
        ),

        #
        # DNS already selected for the tunnel belongs to the
        # manager-owned forwarder and must not be redirected
        # back into itself.
        #
        "iptables -t nat -A {c} "
        "-p udp --sport {source_port} --dport 53 "
        "-j RETURN".format(
            c=DNS_CHAIN,
            source_port=DNSPROXY_SOURCE_PORT,
        ),

        "iptables -t nat -A {c} "
        "-p tcp --sport {source_port} --dport 53 "
        "-j RETURN".format(
            c=DNS_CHAIN,
            source_port=DNSPROXY_SOURCE_PORT,
        ),

        "iptables -t nat -A {c} "
        "-p udp --dport 53 "
        "-j DNAT --to-destination {destination}".format(
            c=DNS_CHAIN,
            destination=_shell_quote(destination)
        ),

        "iptables -t nat -A {c} "
        "-p tcp --dport 53 "
        "-j DNAT --to-destination {destination}".format(
            c=DNS_CHAIN,
            destination=_shell_quote(destination)
        ),

        "iptables -t nat -I OUTPUT 1 -j {c}".format(
            c=DNS_CHAIN
        ),
    ]

    result = _root_command(
        "; ".join(commands)
        + "; iptables -t nat -C OUTPUT -j {c} "
          "2>/dev/null && echo dnslocked".format(
              c=DNS_CHAIN
          ),
        timeout=20
    )

    return "dnslocked" in result

def _extend_existing_firewall_for_bootstrap(
    physical,
    remote_addresses
):
    if not _firewall_active():
        return False, "Existing Android kill switch is not active"

    iface = physical.get("iface", "")

    if not iface:
        return False, "Could not determine Android physical network interface"

    if not remote_addresses:
        return False, "Could not resolve VPN server address"

    management_ok, management_reason, settings = (
        _prepare_management_access(
            physical
        )
    )

    if not management_ok:
        return False, management_reason

    for address in remote_addresses:
        command = (
            "iptables -C {chain} "
            "-d {address}/32 -o {iface} -j ACCEPT "
            "2>/dev/null || "
            "iptables -I {chain} 1 "
            "-d {address}/32 -o {iface} -j ACCEPT"
        ).format(
            chain=FILTER_CHAIN,
            address=_shell_quote(address),
            iface=_shell_quote(iface)
        )

        _root_command(
            command,
            timeout=10
        )

    verify = _root_command(
        "iptables -C OUTPUT -j {chain} "
        "2>/dev/null && "
        "iptables -C {chain} -j REJECT "
        "2>/dev/null && echo protected".format(
            chain=FILTER_CHAIN
        )
    )

    if "protected" not in verify:
        return False, "Existing Android kill switch failed validation"

    return True, ""

def _harden_failed_state():
    #
    # A failed/stopped VPN must not restore ordinary Internet.
    #
    if not _firewall_active():
        return False

    _root_command(
        "iptables -C {chain} -j REJECT "
        "2>/dev/null || "
        "iptables -A {chain} -j REJECT".format(
            chain=FILTER_CHAIN
        )
    )

    _install_dns_lock()

    return _firewall_active() and _dns_lock_hooked()


def _stop_managed_process():
    pid = _managed_pid()

    if not pid:
        _root_command(
            "rm -f {}".format(
                _shell_quote(MANAGED_PID)
            )
        )
        return False

    _root_command(
        "kill {} 2>/dev/null || true".format(
            pid
        )
    )

    for _ in range(40):
        if not _managed_running():
            _root_command(
                "rm -f {}".format(
                    _shell_quote(MANAGED_PID)
                )
            )
            return False

        time.sleep(0.25)

    _root_command(
        "kill -9 {} 2>/dev/null || true; "
        "rm -f {}".format(
            pid,
            _shell_quote(MANAGED_PID)
        )
    )

    return True

def connect(profile):
    if not can_manage_profile(profile):
        return {
            "ok": False,
            "code": None,
            "message": "Selected profile cannot be managed on this Android device",
        }

    profile_path = str(
        profile.get("path", "")
    ).strip()

    if not profile_path:
        return {
            "ok": False,
            "code": None,
            "message": "OpenVPN profile path is empty",
        }

    exists = _root_command(
        "test -f {} && echo exists".format(
            _shell_quote(profile_path)
        )
    )

    if exists.strip() != "exists":
        return {
            "ok": False,
            "code": None,
            "message": "OpenVPN profile not found",
        }

    #
    # A previous crash must not leave our policy rule active
    # without a managed VPN underneath it.
    #
    if not _managed_running():
        _remove_managed_route_rule()

    if _managed_running() and _managed_initialized():
        ok, reason = _install_managed_route_rule()

        if not ok:
            return {
                "ok": False,
                "code": None,
                "message": reason,
            }

        iface = _managed_route_interface()

        if iface:
            return {
                "ok": True,
                "code": 0,
                "message": "Managed OpenVPN is already connected",
                "state": "running",
                "interface": iface,
            }

    remote_hosts = _profile_remote_hosts(
        profile_path
    )

    had_firewall = _firewall_active()

    #
    # A fresh managed-VPN session must not inherit a stale DNS
    # proxy. Existing fail-closed reconnects deliberately keep it.
    #
    if not had_firewall:
        if not _stop_dnsproxy(remove_state=True):
            return {
                "ok": False,
                "code": None,
                "message": "Could not stop stale Android DNS proxy",
            }

    #
    # Preserve an existing fail-closed filter during reconnect.
    #
    if had_firewall:
        _suspend_dns_lock()

    remote_addresses = _resolve_ipv4_hosts(
        remote_hosts
    )

    if not remote_addresses:
        if had_firewall:
            _harden_failed_state()

        return {
            "ok": False,
            "code": None,
            "message": "Could not resolve VPN server address",
        }

    physical = _physical_network(
        remote_addresses
    )

    if had_firewall:
        #
        # A stopped/failed OpenVPN process may have left its
        # physical-interface bypass route in table main.
        # Remove only that exact VPN-server host route before
        # starting the replacement process.
        #
        if not _remove_stale_remote_routes(
            remote_addresses
        ):
            _harden_failed_state()

            return {
                "ok": False,
                "code": None,
                "message": "Could not remove stale VPN server route",
            }

        firewall_ok, firewall_reason = (
            _extend_existing_firewall_for_bootstrap(
                physical,
                remote_addresses
            )
        )
    else:
        firewall_ok, firewall_reason = (
            _install_bootstrap_firewall(
                physical,
                remote_addresses
            )
        )

    if not firewall_ok:
        if had_firewall:
            _harden_failed_state()

        return {
            "ok": False,
            "code": None,
            "message": firewall_reason,
        }

    profile_dir = os.path.dirname(
        profile_path
    ) or "/"

    engine = _OPENVPN_ENGINE

    command = (
        "mkdir -p {runtime} {tmpdir} && "
        "rm -f {pid} {log} && "
        "{engine} "
        "--cd {profile_dir} "
        "--config {profile} "
        "--dev-node /dev/tun "
        "--tmp-dir {tmpdir} "
        "--writepid {pid} "
        "--log-append {log} "
        "--daemon kodi-vpn-manager "
        "&& echo started"
    ).format(
        runtime=_shell_quote(MANAGED_RUNTIME),
        tmpdir=_shell_quote(MANAGED_TMP),
        pid=_shell_quote(MANAGED_PID),
        log=_shell_quote(MANAGED_LOG),
        engine=_shell_quote(engine),
        profile_dir=_shell_quote(profile_dir),
        profile=_shell_quote(profile_path),
    )

    result = _root_command(
        command,
        timeout=30
    )

    if "started" not in result:
        log = _managed_log_tail()

        _harden_failed_state()

        return {
            "ok": False,
            "code": None,
            "message": (
                "OpenVPN failed to start"
                + (
                    "\n\n{}".format(log)
                    if log
                    else ""
                )
            ),
        }

    #
    # Do not report success merely because the daemon exists.
    # Wait for the actual OpenVPN initialization handshake.
    #
    for _ in range(60):
        if not _managed_running():
            log = _managed_log_tail()

            _remove_managed_route_rule()
            _harden_failed_state()

            return {
                "ok": False,
                "code": None,
                "message": (
                    "OpenVPN stopped before connection completed"
                    + (
                        "\n\n{}".format(log)
                        if log
                        else ""
                    )
                ),
            }

        if _managed_initialized():
            ok, reason = _install_managed_route_rule()

            if not ok:
                _stop_managed_process()

                return {
                    "ok": False,
                    "code": None,
                    "message": reason,
                }

            iface = _managed_route_interface()

            if not iface:
                _remove_managed_route_rule()
                _harden_failed_state()
                _stop_managed_process()

                return {
                    "ok": False,
                    "code": None,
                    "message": "OpenVPN connected, but Android did not route Internet traffic through the tunnel",
                }

            firewall_ok, firewall_reason = (
                _lock_firewall_to_tunnel(
                    physical,
                    remote_addresses
                )
            )

            if not firewall_ok:
                _remove_managed_route_rule()
                _harden_failed_state()
                _stop_managed_process()

                return {
                    "ok": False,
                    "code": None,
                    "message": firewall_reason,
                }

            return {
                "ok": True,
                "code": 0,
                "message": "Managed OpenVPN connected (kill switch active)",
                "state": "running",
                "interface": iface,
            }

        time.sleep(0.5)

    log = _managed_log_tail()

    _remove_managed_route_rule()
    _harden_failed_state()
    _stop_managed_process()

    return {
        "ok": False,
        "code": None,
        "message": (
            "OpenVPN connection timed out"
            + (
                "\n\n{}".format(log)
                if log
                else ""
            )
        ),
    }

def disconnect(profile):
    #
    # Disconnect stops the managed VPN but deliberately leaves
    # fail-closed protection armed.  Ordinary Internet access is
    # NOT restored by this action.
    #
    _remove_managed_route_rule()

    if not _managed_pid():
        _harden_failed_state()

        return {
            "ok": True,
            "code": 0,
            "message": "Managed OpenVPN already stopped (protection remains active)",
            "state": "stopped",
        }

    forced = _stop_managed_process()

    _harden_failed_state()

    return {
        "ok": True,
        "code": 0,
        "message": (
            "Managed OpenVPN force-stopped (protection remains active)"
            if forced
            else "Managed OpenVPN stopped (protection remains active)"
        ),
        "state": "stopped",
    }


def disable_protection():
    #
    # Explicitly leave managed-VPN mode and restore ordinary
    # Android networking.
    #
    # This is intentionally separate from disconnect(), which
    # leaves fail-closed protection armed.
    #
    forced = False

    if _managed_pid():
        forced = _stop_managed_process()

    #
    # Stop the manager-owned DNS proxy while the kill switch is
    # still armed. If it cannot be stopped, keep protection active.
    #
    if not _stop_dnsproxy(remove_state=True):
        _harden_failed_state()

        return {
            "ok": False,
            "code": None,
            "message": (
                "Could not stop Android DNS proxy. "
                "VPN protection remains active."
            ),
            "state": "error",
        }

    #
    # Only after DNS forwarding is confirmed stopped may normal
    # Android networking be restored.
    #
    _remove_managed_route_rule()
    _remove_firewall()

    management_routes_clear = (
        _remove_management_routes()
    )

    #
    # Verify that manager-owned protection is actually gone.
    #
    process_running = bool(_managed_pid())
    dnsproxy_running = _dnsproxy_running()
    dnsproxy_state = _dnsproxy_state()
    dnsproxy_state_present = bool(
        dnsproxy_state.get("listener")
        or dnsproxy_state.get("upstream")
    )

    route_rule = _root_command(
        "{} rule show 2>/dev/null | "
        "grep '^{}:' || true".format(
            ANDROID_IP,
            MANAGED_ROUTE_PREF
        )
    ).strip()

    ipv4_active = _firewall_active()
    dns_active = _dns_lock_hooked()

    ipv6_active = (
        _root_command(
            "ip6tables -C OUTPUT -j {} "
            "2>/dev/null && echo active".format(
                IP6_FILTER_CHAIN
            )
        ).strip()
        == "active"
    )

    if (
        process_running
        or dnsproxy_running
        or dnsproxy_state_present
        or route_rule
        or ipv4_active
        or dns_active
        or ipv6_active
        or not management_routes_clear
        or bool(_recorded_management_routes())
    ):
        return {
            "ok": False,
            "code": None,
            "message": (
                "Could not fully disable VPN protection. "
                "Managed networking rules are still active."
            ),
            "state": "error",
        }

    route = _root_command(
        "{} -4 route get 1.1.1.1 "
        "2>/dev/null | head -1".format(
            ANDROID_IP
        )
    ).strip()

    message = "VPN protection disabled; normal Android networking restored"

    if forced:
        message += " (OpenVPN force-stopped)"

    if route:
        message += "\n\nRoute: {}".format(route)

    return {
        "ok": True,
        "code": 0,
        "message": message,
        "state": "unprotected",
    }

