import json
import os
import re
import tempfile
import time


SUPPORTED_TYPES = ("openvpn", "wireguard")

SUPPORTED_AUTH_TYPES = (
    "none",
    "username_password",
    "token",
    "certificate",
    "keypair",
    "external",
)

SCHEMA_VERSION = 2
LEGACY_PROVIDER_ID = "legacy"


def _id(value):
    return str(value or "").strip()


def _dict(value):
    return value if isinstance(value, dict) else {}


def _default_data():
    return {
        "schema": SCHEMA_VERSION,
        "selected": None,
        "providers": [],
        "authentications": [],
        "profiles": [],
    }


def _normalize_provider(item):
    if not isinstance(item, dict):
        return None

    provider_id = _id(item.get("id"))
    name = str(item.get("name", "")).strip()

    if not provider_id or not name:
        return None

    return {
        "id": provider_id,
        "name": name,
        "enabled": bool(item.get("enabled", True)),
        "default_authentication_id":
            _id(item.get("default_authentication_id")) or None,
        "metadata": _dict(item.get("metadata")),
    }


def _normalize_authentication(item):
    if not isinstance(item, dict):
        return None

    auth_id = _id(item.get("id"))
    provider_id = _id(item.get("provider_id"))
    label = str(item.get("label", "")).strip()

    auth_type = str(
        item.get("type", "none")
    ).strip().lower()

    if auth_type not in SUPPORTED_AUTH_TYPES:
        auth_type = "external"

    if not auth_id or not provider_id or not label:
        return None

    return {
        "id": auth_id,
        "provider_id": provider_id,
        "label": label,
        "type": auth_type,
        "username": str(
            item.get("username", "")
        ).strip(),
        "secret_ref":
            _id(item.get("secret_ref")) or None,
        "options": _dict(item.get("options")),
    }


def _normalize_profile(item):
    if not isinstance(item, dict):
        return None

    profile_id = _id(item.get("id"))
    name = str(item.get("name", "")).strip()

    profile_type = str(
        item.get("type", "")
    ).strip().lower()

    if (
        not profile_id
        or not name
        or profile_type not in SUPPORTED_TYPES
    ):
        return None

    return {
        "id": profile_id,
        "name": name,
        "type": profile_type,
        "path": str(
            item.get("path", "")
        ).strip(),
        "enabled": bool(
            item.get("enabled", True)
        ),
        "provider_id":
            _id(item.get("provider_id"))
            or LEGACY_PROVIDER_ID,
        "country": str(
            item.get(
                "country",
                ""
            )
        ).strip() or "Unassigned",
        "authentication_id":
            _id(item.get("authentication_id"))
            or None,
        "protocol_options":
            _dict(item.get("protocol_options")),
    }


def _legacy_provider():
    return {
        "id": LEGACY_PROVIDER_ID,
        "name": "Existing profiles",
        "enabled": True,
        "default_authentication_id": None,
        "metadata": {
            "migrated": True,
        },
    }


def _unique(items, normalizer):
    result = []
    seen = set()

    if not isinstance(items, list):
        items = []

    for raw in items:
        item = normalizer(raw)

        if not item:
            continue

        if item["id"] in seen:
            continue

        seen.add(item["id"])
        result.append(item)

    return result


def _normalize_data(data):
    if not isinstance(data, dict):
        return _default_data()

    result = _default_data()

    result["profiles"] = _unique(
        data.get("profiles", []),
        _normalize_profile,
    )

    result["providers"] = _unique(
        data.get("providers", []),
        _normalize_provider,
    )

    provider_ids = {
        provider["id"]
        for provider in result["providers"]
    }

    required_provider_ids = {
        profile["provider_id"]
        for profile in result["profiles"]
    }

    for provider_id in sorted(
        required_provider_ids
    ):
        if provider_id in provider_ids:
            continue

        if provider_id == LEGACY_PROVIDER_ID:
            provider = _legacy_provider()
        else:
            provider = {
                "id": provider_id,
                "name": provider_id,
                "enabled": True,
                "default_authentication_id": None,
                "metadata": {},
            }

        result["providers"].append(provider)
        provider_ids.add(provider_id)

    result["authentications"] = [
        auth
        for auth in _unique(
            data.get("authentications", []),
            _normalize_authentication,
        )
        if auth["provider_id"] in provider_ids
    ]

    auth_ids = {
        auth["id"]
        for auth in result["authentications"]
    }

    for provider in result["providers"]:
        if (
            provider["default_authentication_id"]
            not in auth_ids
        ):
            provider[
                "default_authentication_id"
            ] = None

    for profile in result["profiles"]:
        if (
            profile["authentication_id"]
            not in auth_ids
        ):
            profile["authentication_id"] = None

    profile_ids = {
        profile["id"]
        for profile in result["profiles"]
    }

    selected = _id(
        data.get("selected")
    ) or None

    result["selected"] = (
        selected
        if selected in profile_ids
        else None
    )

    return result


def load(path):
    if not path or not os.path.exists(path):
        return _default_data()

    try:
        with open(
            path,
            "r",
            encoding="utf-8",
        ) as handle:
            data = json.load(handle)

    except (
        OSError,
        ValueError,
        TypeError,
    ):
        return _default_data()

    return _normalize_data(data)


def save(path, data):
    data = _normalize_data(data)

    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)

    fd, temp_path = tempfile.mkstemp(
        prefix=".profiles-",
        suffix=".tmp",
        dir=directory,
    )

    try:
        with os.fdopen(
            fd,
            "w",
            encoding="utf-8",
        ) as handle:

            json.dump(
                data,
                handle,
                indent=2,
                sort_keys=True,
            )

            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())

        try:
            os.chmod(
                temp_path,
                0o600,
            )
        except OSError:
            pass

        os.replace(
            temp_path,
            path,
        )

        try:
            os.chmod(
                path,
                0o600,
            )
        except OSError:
            pass

    finally:
        if os.path.exists(temp_path):
            try:
                os.unlink(temp_path)
            except OSError:
                pass

    return data


def profiles(data):
    return list(
        _normalize_data(data)["profiles"]
    )


def profiles_for_provider(
    data,
    provider_id,
):
    provider_id = _id(provider_id)

    return [
        profile
        for profile in profiles(data)
        if (
            profile["provider_id"]
            == provider_id
        )
    ]


def selected_profile(data):
    normalized = _normalize_data(data)

    selected = normalized["selected"]

    return next(
        (
            profile
            for profile
            in normalized["profiles"]
            if profile["id"] == selected
        ),
        None,
    )


def set_selected(
    data,
    profile_id,
):
    normalized = _normalize_data(data)

    profile_id = (
        _id(profile_id) or None
    )

    if (
        profile_id is None
        or any(
            profile["id"] == profile_id
            for profile
            in normalized["profiles"]
        )
    ):
        normalized["selected"] = profile_id

    return normalized


def upsert(data, profile):
    normalized = _normalize_data(data)

    item = _normalize_profile(profile)

    if not item:
        return normalized

    if not any(
        provider["id"]
        == item["provider_id"]
        for provider
        in normalized["providers"]
    ):
        if (
            item["provider_id"]
            == LEGACY_PROVIDER_ID
        ):
            normalized[
                "providers"
            ].append(
                _legacy_provider()
            )

        else:
            normalized[
                "providers"
            ].append({
                "id":
                    item["provider_id"],
                "name":
                    item["provider_id"],
                "enabled": True,
                "default_authentication_id":
                    None,
                "metadata": {},
            })

    for index, current in enumerate(
        normalized["profiles"]
    ):
        if current["id"] == item["id"]:
            normalized[
                "profiles"
            ][index] = item
            break

    else:
        normalized[
            "profiles"
        ].append(item)

    return _normalize_data(normalized)


def remove(data, profile_id):
    normalized = _normalize_data(data)

    profile_id = _id(profile_id)

    normalized["profiles"] = [
        profile
        for profile
        in normalized["profiles"]
        if profile["id"] != profile_id
    ]

    if (
        normalized["selected"]
        == profile_id
    ):
        enabled = [
            profile
            for profile
            in normalized["profiles"]
            if profile["enabled"]
        ]

        candidates = (
            enabled
            or normalized["profiles"]
        )

        fallback = (
            candidates[0]
            if candidates
            else None
        )

        normalized["selected"] = (
            fallback["id"]
            if fallback
            else None
        )

    return _normalize_data(normalized)


def providers(data):
    return list(
        _normalize_data(data)["providers"]
    )


def provider(
    data,
    provider_id,
):
    provider_id = _id(provider_id)

    return next(
        (
            item
            for item in providers(data)
            if item["id"] == provider_id
        ),
        None,
    )


def upsert_provider(
    data,
    provider_record,
):
    normalized = _normalize_data(data)

    item = _normalize_provider(
        provider_record
    )

    if not item:
        return normalized

    for index, current in enumerate(
        normalized["providers"]
    ):
        if current["id"] == item["id"]:
            normalized[
                "providers"
            ][index] = item
            break

    else:
        normalized[
            "providers"
        ].append(item)

    return _normalize_data(normalized)


def remove_provider(
    data,
    provider_id,
):
    normalized = _normalize_data(data)

    provider_id = _id(provider_id)

    if any(
        profile["provider_id"]
        == provider_id
        for profile
        in normalized["profiles"]
    ):
        return normalized

    normalized["providers"] = [
        provider
        for provider
        in normalized["providers"]
        if provider["id"] != provider_id
    ]

    normalized[
        "authentications"
    ] = [
        auth
        for auth
        in normalized["authentications"]
        if (
            auth["provider_id"]
            != provider_id
        )
    ]

    return _normalize_data(normalized)


def authentications(
    data,
    provider_id=None,
):
    items = list(
        _normalize_data(
            data
        )["authentications"]
    )

    if provider_id is None:
        return items

    provider_id = _id(provider_id)

    return [
        auth
        for auth in items
        if (
            auth["provider_id"]
            == provider_id
        )
    ]


def authentication(
    data,
    authentication_id,
):
    authentication_id = _id(
        authentication_id
    )

    return next(
        (
            auth
            for auth in authentications(data)
            if (
                auth["id"]
                == authentication_id
            )
        ),
        None,
    )


def upsert_authentication(
    data,
    authentication_record,
):
    normalized = _normalize_data(data)

    item = _normalize_authentication(
        authentication_record
    )

    if not item:
        return normalized

    if not any(
        provider["id"]
        == item["provider_id"]
        for provider
        in normalized["providers"]
    ):
        return normalized

    for index, current in enumerate(
        normalized["authentications"]
    ):
        if current["id"] == item["id"]:
            normalized[
                "authentications"
            ][index] = item
            break

    else:
        normalized[
            "authentications"
        ].append(item)

    return _normalize_data(normalized)


def remove_authentication(
    data,
    authentication_id,
):
    normalized = _normalize_data(data)

    authentication_id = _id(
        authentication_id
    )

    normalized[
        "authentications"
    ] = [
        auth
        for auth
        in normalized["authentications"]
        if auth["id"] != authentication_id
    ]

    for provider in normalized["providers"]:
        if (
            provider[
                "default_authentication_id"
            ]
            == authentication_id
        ):
            provider[
                "default_authentication_id"
            ] = None

    for profile in normalized["profiles"]:
        if (
            profile[
                "authentication_id"
            ]
            == authentication_id
        ):
            profile[
                "authentication_id"
            ] = None

    return _normalize_data(normalized)


def make_id(prefix):
    prefix = re.sub(
        r"[^a-z0-9]+",
        "-",
        str(
            prefix or "item"
        ).lower(),
    ).strip("-") or "item"

    now = time.time()

    return "{}-{}-{:06d}".format(
        prefix,
        int(now),
        int(
            (now % 1)
            * 1000000
        ),
    )
