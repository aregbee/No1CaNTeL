import os
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.backend_loader import (
    backend_capabilities,
    get_backend,
)
from resources.lib import profiles


ADDON = xbmcaddon.Addon()
WINDOW = xbmcgui.Window(10000)
DIALOG = xbmcgui.Dialog()

BACKEND = get_backend()
CAPABILITIES = backend_capabilities(
    BACKEND,
    interactive=True
)

REGISTRY = xbmcvfs.translatePath(
    "special://profile/addon_data/"
    "service.vpn.manager/profiles.json"
)

SECRET_STORE = xbmcvfs.translatePath(
    "special://profile/addon_data/"
    "service.vpn.manager/secrets.json"
)


def prop(name):
    value = WINDOW.getProperty(
        "VPNManager." + name
    )

    return value if value else "N/A"


def selected_profile():
    data = profiles.load(REGISTRY)

    return (
        data,
        profiles.selected_profile(data)
    )


def profile_name(profile):
    if not profile:
        return "None"

    return profile.get(
        "name",
        profile.get("id", "Unknown")
    )


def show_status():
    data, selected = selected_profile()

    message = (
        "Platform: {platform}\n"
        "Mode: {mode}\n"
        "\n"
        "VPN path: {path}\n"
        "Status: {status}\n"
        "Public IP: {public_ip}\n"
        "Interface: {interface}\n"
        "Tunnel IP: {tunnel_ip}\n"
        "Server: {server}\n"
        "Kill switch: {killswitch}\n"
        "Verification: {verification}\n"
        "\n"
        "Selected profile: {profile}"
    ).format(
        platform=CAPABILITIES["name"],
        mode=CAPABILITIES["mode"].title(),
        path=prop("VPNPath"),
        status=prop("VPNStatus"),
        public_ip=prop("PublicIP"),
        interface=prop("VPNInterface"),
        tunnel_ip=prop("VPNTunnelIP"),
        server=prop("VPNServer"),
        killswitch=prop("VPNKillSwitch"),
        verification=prop("VPNVerification"),
        profile=profile_name(selected),
    )

    DIALOG.textviewer(
        "Kodi VPN Manager",
        message
    )


def refresh_now():
    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )

    started = time.monotonic()

    while time.monotonic() - started < 60:
        xbmc.sleep(250)

        requested = WINDOW.getProperty(
            "VPNManager.RefreshVPN"
        )

        status = prop("VPNStatus")
        verification = prop(
            "VPNVerification"
        )

        if (
            requested != "1"
            and status != "Refreshing..."
            and verification != "Checking now..."
        ):
            break

    show_status()


def choose_profile():
    data = profiles.load(REGISTRY)

    available = [
        profile
        for profile in profiles.profiles(data)
        if profile.get("enabled", True)
    ]

    if not available:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No enabled managed VPN profiles are configured."
        )
        return

    current = profiles.selected_profile(data)

    labels = []

    for profile in available:
        prefix = (
            "✓ "
            if current
            and profile["id"] == current["id"]
            else ""
        )

        labels.append(
            "{}{} [{}]".format(
                prefix,
                profile["name"],
                profile["type"].upper(),
            )
        )

    choice = DIALOG.select(
        "Select VPN Profile",
        labels
    )

    if choice < 0:
        return

    selected = available[choice]

    data = profiles.set_selected(
        data,
        selected["id"]
    )

    profiles.save(
        REGISTRY,
        data
    )

    DIALOG.notification(
        "Kodi VPN Manager",
        "Selected: {}".format(
            selected["name"]
        ),
        xbmcgui.NOTIFICATION_INFO,
        3000
    )


def supported_profile_types():
    getter = getattr(
        BACKEND,
        "supported_profile_types",
        None
    )

    if not getter:
        return []

    try:
        return list(getter())
    except Exception:
        return []


def add_profile():
    types = supported_profile_types()

    if not types:
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform has no supported managed VPN profile types."
        )
        return

    if len(types) == 1:
        profile_type = types[0]

    else:
        labels = [
            item.upper()
            for item in types
        ]

        choice = DIALOG.select(
            "VPN Profile Type",
            labels
        )

        if choice < 0:
            return

        profile_type = types[choice]

    if profile_type == "openvpn":
        mask = ".ovpn"
        heading = "Select OpenVPN Profile"

    elif profile_type == "wireguard":
        mask = ".conf"
        heading = "Select WireGuard Profile"

    else:
        return

    selected_path = DIALOG.browseSingle(
        1,
        heading,
        "",
        mask,
        False,
        False,
        ""
    )

    if not selected_path:
        return

    selected_path = xbmcvfs.translatePath(
        selected_path
    )

    default_name = os.path.splitext(
        os.path.basename(selected_path)
    )[0]

    name = DIALOG.input(
        "Profile Name",
        defaultt=default_name
    ).strip()

    if not name:
        return

    data = profiles.load(REGISTRY)

    profile = {
        "id": profiles.make_id(profile_type),
        "name": name,
        "type": profile_type,
        "path": selected_path,
        "enabled": True,
    }

    data = profiles.upsert(
        data,
        profile
    )

    #
    # First profile becomes selected automatically.
    #
    if not profiles.selected_profile(data):
        data = profiles.set_selected(
            data,
            profile["id"]
        )

    profiles.save(
        REGISTRY,
        data
    )

    DIALOG.notification(
        "Kodi VPN Manager",
        "Added: {}".format(name),
        xbmcgui.NOTIFICATION_INFO,
        3000
    )


def remove_profile():
    data = profiles.load(REGISTRY)
    available = profiles.profiles(data)

    if not available:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No managed VPN profiles are configured."
        )
        return

    current = profiles.selected_profile(data)

    labels = []

    for profile in available:
        prefix = (
            "✓ "
            if current
            and profile["id"] == current["id"]
            else ""
        )

        labels.append(
            "{}{} [{}]".format(
                prefix,
                profile["name"],
                profile["type"].upper(),
            )
        )

    choice = DIALOG.select(
        "Remove VPN Profile",
        labels
    )

    if choice < 0:
        return

    profile = available[choice]

    if not DIALOG.yesno(
        "Kodi VPN Manager",
        "Remove profile '{}' ?".format(
            profile["name"]
        )
    ):
        return

    data = profiles.remove(
        data,
        profile["id"]
    )

    profiles.save(
        REGISTRY,
        data
    )

    DIALOG.notification(
        "Kodi VPN Manager",
        "Removed: {}".format(
            profile["name"]
        ),
        xbmcgui.NOTIFICATION_INFO,
        3000
    )


def can_manage(profile):
    if not CAPABILITIES["can_manage"]:
        return False

    checker = getattr(
        BACKEND,
        "can_manage_profile",
        None
    )

    if not checker:
        return False

    return bool(checker(profile))


def show_result(title, result):
    if not isinstance(result, dict):
        DIALOG.ok(
            title,
            str(result)
        )
        return

    ok = bool(result.get("ok"))

    message = result.get(
        "message",
        "Completed" if ok else "Failed"
    )

    state = result.get("state")

    if state:
        message += "\n\nState: {}".format(
            state
        )

    DIALOG.ok(
        title,
        message
    )


def connect_selected():
    data, profile = selected_profile()

    if not profile:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No VPN profile is selected."
        )
        return

    if not can_manage(profile):
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform cannot manage the selected profile."
        )
        return

    connector = getattr(
        BACKEND,
        "connect",
        None
    )

    if not connector:
        return

    result = connector(profile)

    show_result(
        "VPN Connection",
        result
    )

    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )


def disconnect_selected():
    data, profile = selected_profile()

    if not profile:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No VPN profile is selected."
        )
        return

    if not can_manage(profile):
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform cannot manage the selected profile."
        )
        return

    disconnect = getattr(
        BACKEND,
        "disconnect",
        None
    )

    if not disconnect:
        return

    result = disconnect(profile)

    show_result(
        "VPN Disconnect",
        result
    )

    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )



def disable_protection_selected():
    disable = getattr(
        BACKEND,
        "disable_protection",
        None
    )

    if not disable:
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform does not support disabling managed VPN protection."
        )
        return

    confirmed = DIALOG.yesno(
        "Disable VPN Protection",
        (
            "This will stop the managed VPN, disable the kill switch "
            "and DNS lock, and restore normal Internet access.\n\n"
            "Continue?"
        )
    )

    if not confirmed:
        return

    result = disable()

    show_result(
        "VPN Protection",
        result
    )

    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )


def publish_dashboard_properties():
    data, selected = selected_profile()

    WINDOW.setProperty(
        "VPNManager.Platform",
        CAPABILITIES["name"]
    )

    WINDOW.setProperty(
        "VPNManager.Mode",
        CAPABILITIES["mode"].title()
    )

    WINDOW.setProperty(
        "VPNManager.SelectedProfile",
        profile_name(selected)
    )



class ProfileManagerWindow(xbmcgui.WindowXMLDialog):

    PROVIDER_LIST = 200
    PROFILE_LIST = 201

    ADD_BUTTON = 210
    IMPORT_BUTTON = 211
    EDIT_BUTTON = 212
    DELETE_BUTTON = 213
    CREDENTIALS_BUTTON = 214
    CLOSE_BUTTON = 215

    def onInit(self):
        self._data = profiles.load(REGISTRY)
        self._active_provider_id = None

        current = profiles.selected_profile(
            self._data
        )

        preferred_provider = (
            current.get("provider_id")
            if current
            else None
        )

        self._load_providers(
            preferred_provider
        )

    def _load_providers(
        self,
        preferred_provider=None,
    ):
        control = self.getControl(
            self.PROVIDER_LIST
        )

        control.reset()

        available = profiles.providers(
            self._data
        )

        chosen_index = 0

        for index, provider in enumerate(
            available
        ):
            provider_id = provider["id"]

            provider_profiles = (
                profiles.profiles_for_provider(
                    self._data,
                    provider_id,
                )
            )

            count = len(provider_profiles)

            item = xbmcgui.ListItem(
                label=provider["name"],
                label2="{} profile{}".format(
                    count,
                    "" if count == 1 else "s",
                ),
            )

            item.setProperty(
                "provider_id",
                provider_id,
            )

            control.addItem(item)

            if (
                provider_id
                == preferred_provider
            ):
                chosen_index = index

        if not available:
            self._active_provider_id = None
            self._load_profiles(None)
            return

        control.selectItem(chosen_index)

        self._active_provider_id = (
            available[
                chosen_index
            ]["id"]
        )

        self._load_profiles(
            self._active_provider_id
        )

    def _active_profile_id(self):
        # Prefer a backend-provided verified profile identity.
        getter = getattr(
            BACKEND,
            "active_profile_id",
            None,
        )

        if getter:
            try:
                profile_id = getter()

                if profile_id:
                    return profile_id

            except Exception:
                pass

        # Compatibility fallback for backends that expose only
        # their live profile/config path.
        getter = getattr(
            BACKEND,
            "active_profile_path",
            None,
        )

        if not getter:
            return None

        try:
            running_path = getter()
        except Exception:
            return None

        if not running_path:
            return None

        for profile in profiles.profiles(
            self._data
        ):
            if (
                str(profile.get("path") or "")
                == str(running_path)
            ):
                return profile.get("id")

        return None

    def _load_profiles(
        self,
        provider_id,
    ):
        control = self.getControl(
            self.PROFILE_LIST
        )

        control.reset()

        if not provider_id:
            return

        active_id = (
            self._active_profile_id()
        )

        selected = profiles.selected_profile(
            self._data
        )

        preferred_id = (
            selected.get("id")
            if selected
            else None
        )

        available = (
            profiles.profiles_for_provider(
                self._data,
                provider_id,
            )
        )

        chosen_index = 0

        for index, profile in enumerate(
            available
        ):
            profile_id = profile["id"]

            protocol = str(
                profile.get(
                    "type",
                    "unknown",
                )
            ).upper()

            state = ""

            if profile_id == active_id:
                state = "ACTIVE"
                chosen_index = index

            elif (
                active_id is None
                and profile_id
                == preferred_id
            ):
                state = "FALLBACK"
                chosen_index = index

            item = xbmcgui.ListItem(
                label=profile["name"],
                label2=protocol,
            )

            item.setProperty(
                "profile_id",
                profile_id,
            )

            item.setProperty(
                "vpn_status",
                state,
            )

            control.addItem(item)

        if available:
            control.selectItem(
                chosen_index
            )

    def _selected_provider_id(self):
        item = self.getControl(
            self.PROVIDER_LIST
        ).getSelectedItem()

        if not item:
            return None

        return item.getProperty(
            "provider_id"
        ) or None

    def _selected_profile_id(self):
        item = self.getControl(
            self.PROFILE_LIST
        ).getSelectedItem()

        if not item:
            return None

        return item.getProperty(
            "profile_id"
        ) or None

    def _activate_profile(self):
        profile_id = (
            self._selected_profile_id()
        )

        if not profile_id:
            return

        target = next(
            (
                profile
                for profile
                in profiles.profiles(
                    self._data
                )
                if profile["id"]
                == profile_id
            ),
            None,
        )

        if not target:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected VPN profile "
                "could not be found.",
            )
            return

        executor = getattr(
            BACKEND,
            "execute_handoff",
            None,
        )

        if not executor:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Protected profile switching "
                "is not available on this "
                "platform yet.",
            )
            return

        target_name = target.get(
            "name",
            profile_id,
        )

        #
        # Always ask the backend to prove the transaction is
        # safe before allowing any mutation.
        #
        try:
            preview = executor(
                target,
                dry_run=True,
            )

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Profile validation failed.\n\n"
                "{}".format(exc),
            )
            return

        if not preview.get("ok"):
            errors = (
                preview.get("errors")
                or []
            )

            detail = (
                str(errors[0])
                if errors
                else "No additional details."
            )

            DIALOG.ok(
                "Kodi VPN Manager",
                "Profile validation failed.\n\n"
                "Stage: {}\n\n{}".format(
                    preview.get(
                        "stage",
                        "preflight",
                    ),
                    detail,
                ),
            )
            return

        action = preview.get("action")

        if action == "already_active":
            DIALOG.notification(
                "Kodi VPN Manager",
                "Already active: {}".format(
                    target_name
                ),
                time=2500,
                sound=False,
            )
            return

        if (
            action
            == "router_selection_unchanged"
        ):
            DIALOG.notification(
                "Kodi VPN Manager",
                "Already preferred fallback: "
                "{}".format(
                    target_name
                ),
                time=2500,
                sound=False,
            )
            return

        #
        # Changing the preferred fallback while the router VPN
        # is authoritative does not touch networking.
        #
        if action == "select_fallback":
            confirmed = True

        #
        # A local-to-local handoff changes the live tunnel.
        # Require an explicit confirmation.
        #
        elif action == "protected_switch":
            previous_id = preview.get(
                "previous_profile_id"
            )

            previous = next(
                (
                    profile
                    for profile
                    in profiles.profiles(
                        self._data
                    )
                    if profile.get("id")
                    == previous_id
                ),
                None,
            )

            previous_name = (
                previous.get("name")
                if previous
                else previous_id
                or "current VPN"
            )

            confirmed = DIALOG.yesno(
                "Kodi VPN Manager",
                "Switch local VPN from "
                "{} to {}?\n\n"
                "Traffic remains fail-closed. "
                "If the new VPN cannot be "
                "verified, the previous profile "
                "will be restored automatically."
                .format(
                    previous_name,
                    target_name,
                ),
            )

        else:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The backend returned an "
                "unsupported profile action:\n\n"
                "{}".format(
                    action or "unknown"
                ),
            )
            return

        if not confirmed:
            return

        #
        # Execute only after the dry-run path succeeded.
        #
        try:
            result = executor(
                target,
                dry_run=False,
            )

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Profile transaction failed "
                "before completion.\n\n"
                "{}".format(exc),
            )
            return

        #
        # Reload registry and verified live state regardless of
        # success/failure so the list never displays stale data.
        #
        try:
            self._data = profiles.load(
                REGISTRY
            )

            self._load_profiles(
                self._active_provider_id
            )

        except Exception:
            pass

        if result.get("ok"):
            stage = result.get("stage")

            if stage == "fallback_selected":
                DIALOG.notification(
                    "Kodi VPN Manager",
                    "Preferred fallback: "
                    "{}".format(
                        target_name
                    ),
                    time=3000,
                    sound=False,
                )

            elif stage == "committed":
                DIALOG.notification(
                    "Kodi VPN Manager",
                    "VPN active: {}".format(
                        target_name
                    ),
                    time=3000,
                    sound=False,
                )

            else:
                DIALOG.notification(
                    "Kodi VPN Manager",
                    "{}".format(
                        target_name
                    ),
                    time=2500,
                    sound=False,
                )

            return

        errors = (
            result.get("errors")
            or []
        )

        detail = (
            str(errors[0])
            if errors
            else "No additional details."
        )

        stage = result.get(
            "stage",
            "unknown",
        )

        if result.get("rolled_back"):
            message = (
                "VPN switch failed at stage:\n"
                "{}\n\n"
                "The previous VPN profile was "
                "restored automatically.\n\n"
                "{}"
            ).format(
                stage,
                detail,
            )

        else:
            message = (
                "VPN switch failed at stage:\n"
                "{}\n\n"
                "Automatic rollback was not "
                "confirmed. Check VPN status "
                "before retrying.\n\n"
                "{}"
            ).format(
                stage,
                detail,
            )

        DIALOG.ok(
            "Kodi VPN Manager",
            message,
        )

    def _not_ready(self, feature):
        xbmcgui.Dialog().notification(
            "Kodi VPN Manager",
            "{} is next in beta17 development.".format(
                feature
            ),
            time=2500,
            sound=False,
        )

    def onClick(self, control_id):

        if control_id == self.PROVIDER_LIST:
            provider_id = (
                self._selected_provider_id()
            )

            if provider_id:
                self._active_provider_id = (
                    provider_id
                )

                self._load_profiles(
                    provider_id
                )

            return

        if control_id == self.PROFILE_LIST:
            self._activate_profile()
            return

        if control_id == self.ADD_BUTTON:
            self._not_ready("Add")
            return

        if control_id == self.IMPORT_BUTTON:
            self._not_ready("Import")
            return

        if control_id == self.EDIT_BUTTON:
            self._not_ready("Edit")
            return

        if control_id == self.DELETE_BUTTON:
            self._not_ready("Delete")
            return

        if (
            control_id
            == self.CREDENTIALS_BUTTON
        ):
            self._not_ready("Credentials")
            return

        if control_id == self.CLOSE_BUTTON:
            self.close()

    def onAction(self, action):
        if action.getId() in (
            9,
            10,
            92,
        ):
            self.close()


def open_profile_manager():
    window = ProfileManagerWindow(
        "VPNProfileManager.xml",
        ADDON.getAddonInfo("path"),
        "Default",
        "720p",
    )

    window.doModal()

    del window


class DashboardWindow(xbmcgui.WindowXMLDialog):
    REFRESH_BUTTON = 100
    SETTINGS_BUTTON = 101
    CHANGE_PROFILE_BUTTON = 102
    BACK_ACTIONS = (9, 10, 92)

    def onInit(self):
        publish_dashboard_properties()
        self.setFocusId(self.REFRESH_BUTTON)

    def onClick(self, control_id):
        if control_id == self.REFRESH_BUTTON:
            WINDOW.setProperty(
                "VPNManager.RefreshVPN",
                "1"
            )

        elif control_id == self.SETTINGS_BUTTON:
            ADDON.openSettings()
            publish_dashboard_properties()

        elif control_id == self.CHANGE_PROFILE_BUTTON:
            open_profile_manager()
            publish_dashboard_properties()

    def onAction(self, action):
        if action.getId() in self.BACK_ACTIONS:
            self.close()


def main():
    publish_dashboard_properties()

    dashboard = DashboardWindow(
        "VPNManagerDashboard.xml",
        ADDON.getAddonInfo("path"),
        "Default",
        "720p"
    )

    dashboard.doModal()
    del dashboard


if __name__ == "__main__":
    main()
