import sys
import xbmcgui

import manager


def main():
    command = (
        sys.argv[1]
        if len(sys.argv) > 1
        else ""
    )

    actions = {
        "profile-select":
            manager.choose_profile,

        "profile-add":
            manager.add_profile,

        "profile-remove":
            manager.remove_profile,

        "profile-connect":
            manager.connect_selected,

        "profile-disconnect":
            manager.disconnect_selected,

        "protection-disable":
            manager.disable_protection_selected,
    }

    action = actions.get(command)

    if action is None:
        xbmcgui.Dialog().ok(
            "Kodi VPN Manager",
            "Unknown settings action: {}".format(
                command or "None"
            )
        )
        return

    action()


if __name__ == "__main__":
    main()
