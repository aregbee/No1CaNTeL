import json
import shutil
import subprocess
import urllib.error
import urllib.request


CURL = shutil.which("curl")


def _run(args, timeout=12):
    if not args or not args[0]:
        return ""

    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=timeout
        )

        if result.returncode == 0:
            return result.stdout.strip()

    except Exception:
        pass

    return ""


def _urllib_fetch(url, post=False, timeout=10):
    try:
        data = b"{}" if post else None

        request = urllib.request.Request(
            url,
            data=data,
            headers={
                "User-Agent": "Kodi-VPN-Manager/0.1",
                "Accept": "application/json,text/plain,*/*",
            },
            method="POST" if post else "GET",
        )

        if post:
            request.add_header(
                "Content-Type",
                "application/json"
            )

        with urllib.request.urlopen(
            request,
            timeout=timeout
        ) as response:
            return response.read().decode(
                "utf-8",
                errors="replace"
            ).strip()

    except Exception:
        return ""


def fetch(url, interface=None, post=False):
    #
    # Binding to a specific interface is primarily useful on Linux
    # when checking upstream connectivity independently of a local
    # VPN tunnel. urllib cannot do that portably, so use curl when
    # interface binding is explicitly requested.
    #
    if interface and CURL:
        args = [
            CURL,
            "-4fsS",
            "--connect-timeout", "5",
            "--max-time", "10",
            "--interface", interface,
        ]

        if post:
            args.extend([
                "-X", "POST",
                "-H", "Content-Type: application/json",
                "-d", "{}",
            ])

        args.append(url)

        return _run(args)

    #
    # Portable path for Android, Windows, Linux and CoreELEC.
    #
    value = _urllib_fetch(
        url,
        post=post
    )

    if value:
        return value

    #
    # Fallback for appliance environments where Python HTTPS
    # certificate handling may be incomplete.
    #
    if CURL:
        args = [
            CURL,
            "-4fsS",
            "--connect-timeout", "5",
            "--max-time", "10",
        ]

        if post:
            args.extend([
                "-X", "POST",
                "-H", "Content-Type: application/json",
                "-d", "{}",
            ])

        args.append(url)

        return _run(args)

    return ""


def json_data(text):
    try:
        return json.loads(text)
    except Exception:
        return None


def _boolish(value):
    if isinstance(value, bool):
        return value

    if isinstance(value, (int, float)):
        return bool(value)

    if isinstance(value, str):
        value = value.strip().lower()

        if value in ("true", "yes", "1"):
            return True

        if value in ("false", "no", "0"):
            return False

    return None


def public_ip(interface=None):
    value = fetch(
        "https://api.ipify.org",
        interface=interface
    )

    return value if value else "Unavailable"


def external_vpn_check(interface=None):
    first = json_data(
        fetch(
            "https://api.ipapi.is/",
            interface=interface
        )
    )

    second = json_data(
        fetch(
            "https://iplogs.com/v1/check",
            interface=interface,
            post=True
        )
    )

    detector1 = None
    detector2 = None
    pub = "Unavailable"

    if isinstance(first, dict):
        if first.get("ip"):
            pub = str(first["ip"])

        if "is_vpn" in first:
            detector1 = _boolish(
                first.get("is_vpn")
            )

    if isinstance(second, dict):
        raw = _boolish(
            second.get("is_vpn")
        )

        verdict = str(
            second.get("verdict", "")
        ).lower()

        if raw is not None:
            detector2 = (
                raw
                and verdict == "vpn_detected"
            )

    if pub == "Unavailable":
        pub = public_ip(interface)

    detectors = [
        value
        for value in (
            detector1,
            detector2,
        )
        if value is not None
    ]

    positive = sum(
        value is True
        for value in detectors
    )

    negative = sum(
        value is False
        for value in detectors
    )

    #
    # Only count detectors that actually returned a verdict.
    # One positive response plus one unavailable service is
    # not a disagreement.
    #
    if detectors and positive == len(detectors):
        verdict = "vpn"

    elif detectors and negative == len(detectors):
        verdict = "not_detected"

    elif positive and negative:
        verdict = "probable_vpn"

    else:
        verdict = "unknown"

    #
    # Collect useful exit-node metadata. Prefer IPLogs because
    # its current response includes a structured ip_info block.
    #
    exit_info = {}

    if isinstance(second, dict):
        info = second.get("ip_info")
        if isinstance(info, dict):
            exit_info.update(info)

    if isinstance(first, dict):
        for key in (
            "city",
            "region",
            "state",
            "province",
            "country",
            "country_code",
            "asn",
            "org",
            "organization",
            "isp",
        ):
            if key not in exit_info and first.get(key):
                exit_info[key] = first.get(key)

    location_parts = []

    for key in (
        "city",
        "region",
        "state",
        "province",
        "country",
    ):
        value = exit_info.get(key)

        if value:
            value = str(value)

            if value not in location_parts:
                location_parts.append(value)

    exit_location = (
        ", ".join(location_parts)
        if location_parts
        else "Unavailable"
    )

    asn = str(exit_info.get("asn") or "").strip()

    organization = str(
        exit_info.get("org")
        or exit_info.get("organization")
        or exit_info.get("isp")
        or ""
    ).strip()

    network_parts = []

    if asn:
        network_parts.append(asn)

    if organization and organization not in network_parts:
        network_parts.append(organization)

    exit_network = (
        " - ".join(network_parts)
        if network_parts
        else "Unavailable"
    )

    return {
        "public_ip": pub,
        "verdict": verdict,
        "detector1": detector1,
        "detector2": detector2,
        "detectors_responded": len(detectors),
        "detectors_positive": positive,
        "exit_location": exit_location,
        "exit_network": exit_network,
    }


def merge_state(state, external):
    result = dict(state or {})
    external = external or {}

    verdict = external.get("verdict", "unknown")
    local_tunnel = bool(
        result.get("local_tunnel", False)
    )
    backend_verified = bool(
        result.get("backend_verified", False)
    )

    result["external_verdict"] = verdict

    #
    # Strong backend evidence remains authoritative.
    # External services are supplementary and may disagree.
    #
    if backend_verified:
        if verdict == "vpn":
            result["verification"] = (
                "{}; exit IP classified as VPN/proxy".format(
                    result.get("verification", "Backend verified")
                )
            )

        elif verdict == "probable_vpn":
            result["verification"] = (
                "{}; exit IP possibly classified as VPN/proxy".format(
                    result.get("verification", "Backend verified")
                )
            )

        elif verdict == "not_detected":
            result["verification"] = (
                "{}; exit IP not identified as VPN/proxy".format(
                    result.get("verification", "Backend verified")
                )
            )

        return result

    #
    # A local tunnel exists, but that alone does not prove
    # it is a privacy VPN. Android firewall/ad-blocking apps
    # may also create VPN-style tunnel interfaces.
    #
    if local_tunnel:
        if verdict == "vpn":
            result["status"] = "Protected"
            result["verification"] = (
                "Local tunnel route confirmed; exit IP classified as VPN/proxy"
            )

        elif verdict == "probable_vpn":
            result["status"] = "PROBABLE VPN"
            result["verification"] = (
                "Local tunnel detected; exit IP possibly classified as VPN/proxy"
            )

        elif verdict == "not_detected":
            result["status"] = (
                "TUNNEL ACTIVE - VPN NOT CONFIRMED"
            )
            result["verification"] = (
                "Local tunnel detected; exit IP not identified as VPN/proxy"
            )

        else:
            result["status"] = (
                "VPN TUNNEL ACTIVE - VERIFYING"
            )

        return result

    #
    # No local tunnel is visible. External detection can therefore
    # indicate a router/upstream VPN without requiring local control.
    #
    if verdict == "vpn":
        result.update({
            "path": "Router / upstream VPN",
            "status": "Protected",
            "server": "Upstream / externally detected",
            "killswitch": "Upstream-managed",
            "verification": "Exit IP classified as VPN/proxy",
        })

    elif verdict == "probable_vpn":
        result.update({
            "path": "Possible router / upstream VPN",
            "status": "PROBABLE VPN",
            "server": "Upstream / externally detected",
            "killswitch": "Upstream-managed",
            "verification": "Exit IP possibly classified as VPN/proxy",
        })

    elif verdict == "not_detected":
        result["status"] = "VPN NOT DETECTED"
        result["verification"] = (
            "No local tunnel; exit IP not identified as VPN/proxy"
        )

    return result
