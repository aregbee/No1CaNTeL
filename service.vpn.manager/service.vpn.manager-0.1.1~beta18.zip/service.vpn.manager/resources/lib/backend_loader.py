import xbmc

from resources.lib.backends import android, linux, windows


def platform_name():
    # Android must be checked before Linux.
    if xbmc.getCondVisibility("System.Platform.Android"):
        return "android"

    if xbmc.getCondVisibility("System.Platform.Windows"):
        return "windows"

    if xbmc.getCondVisibility("System.Platform.Linux"):
        return "linux"

    return "unknown"


def get_backend():
    platform = platform_name()

    if platform == "android":
        return android

    if platform == "windows":
        return windows

    if platform == "linux":
        return linux

    raise RuntimeError(
        "Unsupported VPN Manager platform: {}".format(platform)
    )


def backend_capabilities(backend, interactive=False):
    result = {
        "id": getattr(backend, "BACKEND_ID", "unknown"),
        "name": getattr(backend, "BACKEND_NAME", "Unknown"),
        "mode": getattr(backend, "MODE", "monitor"),
        "can_monitor": bool(
            getattr(backend, "CAN_MONITOR", False)
        ),
        "can_manage": bool(
            getattr(backend, "CAN_MANAGE", False)
        ),
    }

    runtime = getattr(
        backend,
        "runtime_capabilities",
        None
    )

    if runtime:
        try:
            extra = runtime(
                interactive=interactive
            )

            if isinstance(extra, dict):
                result.update(extra)

        except Exception:
            pass

    return result
