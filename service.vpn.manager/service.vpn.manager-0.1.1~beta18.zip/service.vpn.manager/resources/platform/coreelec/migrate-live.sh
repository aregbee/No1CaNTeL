#!/bin/sh
set -eu

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DEV="$(cd "$SCRIPT_DIR/../../.." && pwd)"
CFG="/storage/.config"
SYSTEMD="$CFG/system.d"
ORIGINAL_BACKUP="/storage/vpn-manager-pre-migration"
BACKUP="/storage/vpn-manager-migration-rollback"

STATE_FILE="/run/vpn-selector.state"

OLD_SERVICE="purevpn-openvpn.service"
NEW_SERVICE="vpn-manager-openvpn.service"
SELECTOR_SERVICE="vpn-selector.service"
SELECTOR_TIMER="vpn-selector.timer"

OLD_SELECTOR="$CFG/vpn-selector.sh"
OLD_LAUNCHER="$CFG/vpn-manager-openvpn-launcher.py"
OLD_KILLSWITCH="$CFG/openvpn-killswitch.sh"
OLD_DNSLOCK="$CFG/openvpn-dns-lock.sh"
OLD_BOOTGUARD="$CFG/vpn-bootstrap-guard.sh"
OLD_UNIT="$SYSTEMD/$NEW_SERVICE"

NEW_SELECTOR="$DEV/resources/platform/coreelec/vpn-selector.sh"
NEW_LAUNCHER="$DEV/resources/platform/coreelec/vpn-manager-openvpn-launcher.py"
NEW_KILLSWITCH="$DEV/resources/platform/coreelec/openvpn-killswitch.sh"
NEW_DNSLOCK="$DEV/resources/platform/coreelec/openvpn-dns-lock.sh"
NEW_BOOTGUARD="$DEV/resources/platform/coreelec/vpn-bootstrap-guard.sh"
NEW_UNIT="$DEV/resources/platform/coreelec/vpn-manager-openvpn.service"

fail()
{
    echo "MIGRATION ABORTED: $*" >&2
    exit 1
}

backup_file_once()
{
    base="$1"
    src="$2"
    name="$3"

    if [ -e "$base/$name" ] ||
       [ -e "$base/$name.absent" ]; then
        return
    fi

    if [ -e "$src" ]; then
        cp -a "$src" "$base/$name"
    else
        : > "$base/$name.absent"
    fi
}

restore_file()
{
    dst="$1"
    name="$2"

    if [ -e "$BACKUP/$name" ]; then
        rm -f "$dst"
        cp -a "$BACKUP/$name" "$dst"
    elif [ -e "$BACKUP/$name.absent" ]; then
        rm -f "$dst"
    fi
}

install_atomic()
{
    src="$1"
    dst="$2"
    mode="$3"

    cp "$src" "$dst.new" || return 1
    chmod "$mode" "$dst.new" || {
        rm -f "$dst.new"
        return 1
    }
    mv "$dst.new" "$dst" || {
        rm -f "$dst.new"
        return 1
    }
}

echo "=== Kodi VPN Manager CoreELEC migration ==="

#
# Preflight
#
[ -f "$NEW_SELECTOR" ] ||
    fail "Packaged selector missing"

[ -f "$NEW_LAUNCHER" ] ||
    fail "Packaged OpenVPN launcher missing"

[ -f "$NEW_KILLSWITCH" ] ||
    fail "Packaged OpenVPN kill switch missing"

[ -f "$NEW_DNSLOCK" ] ||
    fail "Packaged OpenVPN DNS lock missing"

[ -f "$NEW_BOOTGUARD" ] ||
    fail "Packaged bootstrap guard missing"

[ -f "$NEW_UNIT" ] ||
    fail "Packaged OpenVPN service unit missing"

sh -n "$NEW_SELECTOR" ||
    fail "Packaged selector has a shell syntax error"

sh -n "$NEW_KILLSWITCH" ||
    fail "Packaged kill switch has a shell syntax error"

sh -n "$NEW_DNSLOCK" ||
    fail "Packaged DNS lock has a shell syntax error"

sh -n "$NEW_BOOTGUARD" ||
    fail "Packaged bootstrap guard has a shell syntax error"

python3 "$NEW_LAUNCHER" --check ||
    fail "Selected OpenVPN profile failed validation"

CURRENT_STATE="$(cat "$STATE_FILE" 2>/dev/null || true)"

[ "$CURRENT_STATE" = "router" ] ||
    fail "Current protected path is '$CURRENT_STATE', not router"

if systemctl is-active --quiet "$OLD_SERVICE"; then
    fail "Old local PureVPN service is still active"
fi

echo "Preflight: OK"
echo "Current path: router"
echo

#
# Preserve every live file this migration can replace.
#
# The original historical rollback set is intentionally
# read-only. Never add or replace files in it here.
if [ -d "$ORIGINAL_BACKUP" ]; then
    echo "Historical rollback retained unchanged: $ORIGINAL_BACKUP"
fi

# Automatic rollback must restore the state immediately
# preceding THIS migration attempt.
rm -rf "$BACKUP"
mkdir -p "$BACKUP"

backup_file_once "$BACKUP" "$OLD_SELECTOR"   "vpn-selector.sh"
backup_file_once "$BACKUP" "$OLD_LAUNCHER"   "vpn-manager-openvpn-launcher.py"
backup_file_once "$BACKUP" "$OLD_KILLSWITCH" "openvpn-killswitch.sh"
backup_file_once "$BACKUP" "$OLD_DNSLOCK"    "openvpn-dns-lock.sh"
backup_file_once "$BACKUP" "$OLD_BOOTGUARD"  "vpn-bootstrap-guard.sh"
backup_file_once "$BACKUP" "$OLD_UNIT"       "$NEW_SERVICE"
backup_file_once "$BACKUP" "$SYSTEMD/$OLD_SERVICE" "$OLD_SERVICE"

echo "Historical rollback: $ORIGINAL_BACKUP"
echo "Transaction rollback: $BACKUP"

#
# Prevent selector activity from racing the migration.
#
TIMER_WAS_ACTIVE=0

if systemctl is-active --quiet "$SELECTOR_TIMER"; then
    TIMER_WAS_ACTIVE=1
    systemctl stop "$SELECTOR_TIMER"
fi

systemctl stop "$SELECTOR_SERVICE" 2>/dev/null || true

rollback()
{
    echo
    echo "Migration validation failed -- restoring previous files."

    systemctl stop "$SELECTOR_SERVICE" 2>/dev/null || true
    systemctl stop "$NEW_SERVICE" 2>/dev/null || true

    restore_file "$OLD_SELECTOR"   "vpn-selector.sh"
    restore_file "$OLD_LAUNCHER"   "vpn-manager-openvpn-launcher.py"
    restore_file "$OLD_KILLSWITCH" "openvpn-killswitch.sh"
    restore_file "$OLD_DNSLOCK"    "openvpn-dns-lock.sh"
    restore_file "$OLD_BOOTGUARD"  "vpn-bootstrap-guard.sh"
    restore_file "$OLD_UNIT"       "$NEW_SERVICE"

    systemctl daemon-reload
    systemctl start "$SELECTOR_SERVICE" 2>/dev/null || true

    if [ "$TIMER_WAS_ACTIVE" -eq 1 ]; then
        systemctl start "$SELECTOR_TIMER" 2>/dev/null || true
    fi

    echo "Rollback attempted."
    echo "Selector state: $(cat "$STATE_FILE" 2>/dev/null || echo unknown)"
    exit 1
}

#
# Install the complete generic protection stack atomically.
#
install_atomic \
    "$NEW_LAUNCHER" \
    "$OLD_LAUNCHER" \
    755 || rollback

install_atomic \
    "$NEW_KILLSWITCH" \
    "$OLD_KILLSWITCH" \
    755 || rollback

install_atomic \
    "$NEW_DNSLOCK" \
    "$OLD_DNSLOCK" \
    755 || rollback

install_atomic \
    "$NEW_BOOTGUARD" \
    "$OLD_BOOTGUARD" \
    755 || rollback

install_atomic \
    "$NEW_UNIT" \
    "$OLD_UNIT" \
    644 || rollback

install_atomic \
    "$NEW_SELECTOR" \
    "$OLD_SELECTOR" \
    755 || rollback

systemctl daemon-reload || rollback

#
# Run the protected selector using the new architecture.
#
if ! systemctl start "$SELECTOR_SERVICE"; then
    rollback
fi

NEW_STATE="$(cat "$STATE_FILE" 2>/dev/null || true)"

case "$NEW_STATE" in
    router)
        if systemctl is-active --quiet "$NEW_SERVICE"; then
            rollback
        fi

        echo "Verified path after migration: router"
        ;;

    local)
        if ! systemctl is-active --quiet "$NEW_SERVICE"; then
            rollback
        fi

        if ! ip route get 1.1.1.1 2>/dev/null |
             grep -q 'dev tun0'; then
            rollback
        fi

        echo "Verified path after migration: managed local OpenVPN"
        ;;

    *)
        rollback
        ;;
esac

if [ "$TIMER_WAS_ACTIVE" -eq 1 ]; then
    systemctl start "$SELECTOR_TIMER"
fi

echo
echo "=== MIGRATION SUCCESSFUL ==="
echo "Selector state: $NEW_STATE"
echo "Legacy PureVPN unit left untouched for rollback."
echo "Generic service: $NEW_SERVICE"
