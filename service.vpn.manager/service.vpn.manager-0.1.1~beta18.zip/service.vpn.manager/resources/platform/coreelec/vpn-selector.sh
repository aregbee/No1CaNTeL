#!/bin/sh

OVPN_SERVICE="vpn-manager-openvpn.service"
KILLSWITCH="/storage/.config/openvpn-killswitch.sh"
BOOTGUARD="/storage/.config/vpn-bootstrap-guard.sh"
DNSLOCK="/storage/.config/openvpn-dns-lock.sh"
ADDON_ROOT="/storage/.kodi/addons/service.vpn.manager"
RUNTIME_TARGET="/run/vpn-manager-openvpn.target.json"
EFFECTIVE_CONFIG="/run/vpn-manager-openvpn.effective.ovpn"
IPT="/usr/sbin/iptables"

STATE_FILE="/run/vpn-selector.state"
UPSTREAM_IP_FILE="/run/vpn-selector.upstream-ip"

get_lan_interface()
{
    LANIF="$(ip -4 route show table main default 2>/dev/null |
        awk '/^default / {
            for (i=1;i<=NF;i++)
                if ($i=="dev") { print $(i+1); exit }
        }')"

    [ -n "$LANIF" ]
}

get_current_path()
{
    if systemctl is-active --quiet "$OVPN_SERVICE" &&
       ip route get 1.1.1.1 2>/dev/null | grep -q 'dev tun0'; then
        echo local
        return
    fi

    SAVED="$(cat "$STATE_FILE" 2>/dev/null)"

    if [ "$SAVED" = "router" ]; then
        echo router
    else
        echo unknown
    fi
}

get_upstream_ip()
{
    curl --interface "$LANIF" -4fsS \
        --connect-timeout 5 --max-time 10 \
        https://api.ipify.org 2>/dev/null
}

check_iplogs()
{
    DATA="$(curl --interface "$LANIF" -4fsS \
        --connect-timeout 5 --max-time 10 \
        -X POST https://iplogs.com/v1/check \
        -H 'Content-Type: application/json' \
        -d '{}' 2>/dev/null |
        tr -d '[:space:]')" || {
            echo X
            return
        }

    printf '%s' "$DATA" | grep -Fq "\"ip\":\"$UPIP\"" || {
        echo X
        return
    }

    if printf '%s' "$DATA" | grep -Fq '"is_vpn":true' &&
       printf '%s' "$DATA" | grep -Fq '"verdict":"vpn_detected"'; then
        echo 1
    elif printf '%s' "$DATA" | grep -Fq '"is_vpn":false'; then
        echo 0
    else
        echo X
    fi
}

check_proxycheck()
{
    DATA="$(curl --interface "$LANIF" -4fsS \
        --connect-timeout 5 --max-time 10 \
        "https://proxycheck.io/v2/$UPIP?vpn=2" 2>/dev/null |
        tr -d '[:space:]')" || {
            echo X
            return
        }

    printf '%s' "$DATA" | grep -Fq '"status":"ok"' || {
        echo X
        return
    }

    if printf '%s' "$DATA" | grep -Fq '"proxy":"yes"' &&
       printf '%s' "$DATA" | grep -Fq '"type":"VPN"'; then
        echo 1
    elif printf '%s' "$DATA" | grep -Fq '"proxy":"no"'; then
        echo 0
    else
        echo X
    fi
}

# SELECTOR_REDESIGN_V1

start_local_probe()
{
    DETECTOR_IPS="$(
        {
            getent ahostsv4 api.ipify.org 2>/dev/null
            getent ahostsv4 iplogs.com 2>/dev/null
            getent ahostsv4 proxycheck.io 2>/dev/null
        } | awk '/^[0-9]+\./ && !seen[$1]++ {print $1}'
    )"

    [ -n "$DETECTOR_IPS" ] || return 1

    $IPT -N CE_VPN_PROBE 2>/dev/null || true
    $IPT -F CE_VPN_PROBE

    while $IPT -D OUTPUT -j CE_VPN_PROBE 2>/dev/null; do :; done

    for IP in $DETECTOR_IPS; do
        $IPT -A CE_VPN_PROBE -o "$LANIF" \
            -d "$IP" -p tcp --dport 443 -j ACCEPT
    done

    $IPT -A CE_VPN_PROBE -j RETURN
    $IPT -I OUTPUT 1 -j CE_VPN_PROBE
}

stop_local_probe()
{
    while $IPT -D OUTPUT -j CE_VPN_PROBE 2>/dev/null; do :; done
    $IPT -F CE_VPN_PROBE 2>/dev/null || true
    $IPT -X CE_VPN_PROBE 2>/dev/null || true
}

verify_upstream()
{
    echo "Running full VPN verification..."

    IPLOGS="$(check_iplogs)"
    PROXYCHECK="$(check_proxycheck)"

    echo "IPLogs VPN:     $IPLOGS"
    echo "Proxycheck VPN: $PROXYCHECK"

    [ "$IPLOGS" = "1" ] && [ "$PROXYCHECK" = "1" ]
}

bootstrap_guard_active()
{
    $IPT -C OUTPUT -j CE_VPN_BOOT >/dev/null 2>&1
}


clear_runtime_target()
{
    rm -f "$RUNTIME_TARGET" "$EFFECTIVE_CONFIG"
}


stage_local_target()
{
    [ -d "$ADDON_ROOT" ] || {
        echo "ERROR: VPN Manager add-on root is unavailable."
        return 1
    }

    STAGED="$(
        cd "$ADDON_ROOT" || exit 1

        python3 - <<'PY_STAGE'
import sys

from resources.lib import profiles
from resources.lib.backends import linux

REG = (
    "/storage/.kodi/userdata/addon_data/"
    "service.vpn.manager/profiles.json"
)

try:
    data = profiles.load(REG)

    profile_id = data.get("selected")

    if not profile_id:
        raise RuntimeError(
            "No preferred local VPN profile is selected"
        )

    profile = next(
        (
            item
            for item in profiles.profiles(data)
            if item.get("id") == profile_id
        ),
        None,
    )

    if profile is None:
        raise RuntimeError(
            "Selected VPN profile is missing from registry"
        )

    plan = linux.build_handoff_plan(profile)

    if not plan.get("ok"):
        errors = plan.get("errors") or [
            "Selected profile failed preflight"
        ]
        raise RuntimeError("; ".join(errors))

    endpoints = plan.get("staged_endpoints") or []

    if not endpoints:
        raise RuntimeError(
            "No preflighted target endpoint is available"
        )

    chosen = endpoints[0]

    address = chosen.get("address")
    port = chosen.get("port")
    proto = chosen.get("proto")
    host = chosen.get("host")

    if not address or not port or not proto:
        raise RuntimeError(
            "Preflight returned an incomplete endpoint"
        )

    transaction = {
        "target_profile_id": profile_id,
        "endpoint": {
            "address": address,
            "port": port,
            "proto": proto,
            "host": host,
        },
    }

    linux._write_runtime_target(transaction)

    print(
        "{}|{}|{}|{}".format(
            profile_id,
            address,
            port,
            proto,
        )
    )

except Exception as exc:
    print(
        "ERROR: {}".format(exc),
        file=sys.stderr,
    )
    sys.exit(1)
PY_STAGE
    )" || return 1

    [ -n "$STAGED" ] || {
        echo "ERROR: Runtime target staging returned no result."
        return 1
    }

    OLDIFS="$IFS"
    IFS='|'
    set -- $STAGED
    IFS="$OLDIFS"

    STAGED_PROFILE_ID="$1"
    STAGED_ADDRESS="$2"
    STAGED_PORT="$3"
    STAGED_PROTO="$4"

    [ -n "$STAGED_PROFILE_ID" ] &&
    [ -n "$STAGED_ADDRESS" ] &&
    [ -n "$STAGED_PORT" ] &&
    [ -n "$STAGED_PROTO" ] || {
        echo "ERROR: Invalid staged target result."
        return 1
    }

    echo "Pinned local fallback:"
    echo " profile=$STAGED_PROFILE_ID"
    echo " endpoint=$STAGED_ADDRESS:$STAGED_PORT $STAGED_PROTO"

    return 0
}


verify_staged_target()
{
    [ -n "${STAGED_PROFILE_ID:-}" ] || return 1

    (
        cd "$ADDON_ROOT" || exit 1

        python3 - "$STAGED_PROFILE_ID" <<'PY_VERIFY'
import sys

from resources.lib.backends import linux

profile_id = sys.argv[1]

ok = linux._wait_profile_active(
    profile_id,
    timeout=45,
)

sys.exit(0 if ok else 1)
PY_VERIFY
    )
}


keep_local()
{
    printf '%s\n' local > "$STATE_FILE"

    if [ -n "$UPIP" ]; then
        printf '%s\n' "$UPIP" > "$UPSTREAM_IP_FILE"
    fi

    echo "Keeping local OpenVPN protection."
    exit 0
}

use_router()
{
    echo "UPSTREAM VPN CONFIRMED"

    if systemctl is-active --quiet "$OVPN_SERVICE"; then
        echo "Stopping unnecessary local managed OpenVPN..."
        systemctl stop "$OVPN_SERVICE"
    fi

    clear_runtime_target

    "$DNSLOCK" unlock 2>/dev/null || true
    "$KILLSWITCH" down 2>/dev/null || true
    "$BOOTGUARD" down

    printf '%s\n' router > "$STATE_FILE"
    printf '%s\n' "$UPIP" > "$UPSTREAM_IP_FILE"

    echo "Using router/upstream VPN."
    exit 0
}

use_local()
{
    printf '%s\n' failed > "$STATE_FILE"

    echo "Upstream VPN not confirmed."
    echo "Entering fail-closed local fallback."

    #
    # Never let a previous failed transaction influence the
    # bootstrap transport rules for a new fallback attempt.
    #
    clear_runtime_target

    #
    # First establish the bootstrap guard. In UNKNOWN/startup
    # mode it may already be active; in ROUTER mode this closes
    # the WAN before target preflight/staging begins.
    #
    if bootstrap_guard_active; then
        echo "Bootstrap guard already ACTIVE."
    else
        echo "Activating bootstrap guard..."

        "$BOOTGUARD" up || {
            echo "ERROR: Bootstrap guard could not initialize."
            echo "Local OpenVPN will NOT be started."
            exit 1
        }
    fi

    #
    # Resolve/preflight while only DNS, LAN and approved VPN
    # transports are available. Then pin ONE exact endpoint in
    # the runtime target file.
    #
    echo "Preflighting preferred local fallback..."

    if ! stage_local_target; then
        echo "ERROR: Local fallback preflight/staging failed."
        echo "Bootstrap guard remains ACTIVE."
        echo "Local OpenVPN will NOT be started."
        exit 1
    fi

    #
    # The launcher now reports only the exact staged endpoint,
    # so the kill switch and OpenVPN effective config are built
    # from the same IP/port/protocol.
    #
    echo "Installing pinned OpenVPN kill switch..."

    "$KILLSWITCH" up || {
        echo "ERROR: Could not activate pinned OpenVPN kill switch."
        echo "Bootstrap guard remains ACTIVE."
        echo "Local OpenVPN will NOT be started."
        exit 1
    }

    #
    # CE_OVPN_KS is now fail-closed around the exact endpoint.
    # Bootstrap protection is redundant and can be removed.
    #
    "$BOOTGUARD" down 2>/dev/null || true

    if systemctl is-active --quiet "$OVPN_SERVICE"; then
        echo "Local managed OpenVPN already running."
    else
        echo "Starting pinned local OpenVPN fallback..."

        if ! systemctl start "$OVPN_SERVICE"; then
            printf '%s\n' failed > "$STATE_FILE"
            echo "ERROR: Could not start local OpenVPN."
            echo "Pinned OpenVPN kill switch remains ACTIVE."
            exit 1
        fi
    fi

    echo "Verifying exact local VPN profile and Internet path..."

    if ! verify_staged_target; then
        echo "ERROR: Local VPN failed protected verification."

        #
        # Do not leave Restart=on-failure churning indefinitely.
        # Stop it explicitly while keeping the kill switch up.
        #
        systemctl stop "$OVPN_SERVICE" 2>/dev/null || true

        printf '%s\n' failed > "$STATE_FILE"

        echo "Local OpenVPN has been stopped."
        echo "Pinned OpenVPN kill switch remains ACTIVE."
        echo "WAN remains fail-closed."
        exit 1
    fi

    "$DNSLOCK" lock || {
        echo "ERROR: Could not lock DNS to the VPN tunnel."
        echo "Pinned OpenVPN kill switch remains ACTIVE."
        exit 1
    }

    #
    # Re-evaluate protection now that DNS is locked. Because
    # RUNTIME_TARGET remains present, this still uses the same
    # exact pinned endpoint and requires no hostname resolution.
    #
    "$KILLSWITCH" up || {
        echo "ERROR: Could not finalize kill switch after DNS lock."
        echo "Existing fail-closed protection remains in place."
        exit 1
    }

    printf '%s\n' local > "$STATE_FILE"

    if [ -n "${UPIP:-}" ]; then
        printf '%s\n' "$UPIP" > "$UPSTREAM_IP_FILE"
    fi

    echo "LOCAL OPENVPN ACTIVE"
    echo "Verified profile: $STAGED_PROFILE_ID"
    exit 0
}



if ! get_lan_interface; then
    printf '%s\n' failed > "$STATE_FILE"
    echo "ERROR: Could not determine physical Internet interface."
    exit 1
fi


CURRENT="$(get_current_path)"
LASTIP="$(cat "$UPSTREAM_IP_FILE" 2>/dev/null)"

echo "Physical Internet interface: $LANIF"
echo "Current VPN path: $CURRENT"

#
# LOCAL MODE
# Keep the working tunnel and kill switch intact.
# Resolve detector hosts through VPN DNS, then temporarily permit
# only those HTTPS probes on the physical interface.
#
if [ "$CURRENT" = "local" ]; then
    echo "Checking whether router/upstream VPN has returned..."

    if ! start_local_probe; then
        echo "WARNING: Could not prepare safe upstream probe."
        keep_local
    fi

    trap 'stop_local_probe' 0 2 15

    UPIP="$(get_upstream_ip)"

    if [ -z "$UPIP" ]; then
        echo "Physical upstream IP unavailable; keeping local VPN."
        stop_local_probe
        trap - 0 2 15
        keep_local
    fi

    echo "Physical upstream IP: $UPIP"
    echo "Previous upstream IP: ${LASTIP:-unknown}"

    if [ -n "$LASTIP" ] && [ "$UPIP" = "$LASTIP" ]; then
        echo "Physical upstream IP unchanged."
        stop_local_probe
        trap - 0 2 15
        keep_local
    fi

    if verify_upstream; then
        stop_local_probe
        trap - 0 2 15
        use_router
    fi

    stop_local_probe
    trap - 0 2 15
    keep_local
fi

#
# ROUTER MODE
# Do not install the bootstrap firewall merely to verify an
# already-established router/upstream VPN.
#
if [ "$CURRENT" = "router" ]; then
    UPIP="$(get_upstream_ip)"

    if [ -z "$UPIP" ]; then
        echo "ERROR: Physical upstream IP unavailable."
        use_local
    fi

    echo "Physical upstream IP: $UPIP"
    echo "Previous upstream IP: ${LASTIP:-unknown}"

    if [ -n "$LASTIP" ] && [ "$UPIP" = "$LASTIP" ]; then
        echo "Upstream IP unchanged; keeping verified router VPN."
        "$KILLSWITCH" down 2>/dev/null || true
        "$BOOTGUARD" down 2>/dev/null || true
        printf '%s\n' router > "$STATE_FILE"
        exit 0
    fi

    echo "Upstream IP changed."

    if verify_upstream; then
        use_router
    fi

    use_local
fi

#
# UNKNOWN / STARTUP MODE
# This is where bootstrap fail-close belongs: before we know
# whether any trusted VPN path exists.
#
printf '%s\n' failed > "$STATE_FILE"

echo "VPN path unknown; activating bootstrap protection."

"$BOOTGUARD" up || {
    echo "ERROR: Bootstrap guard could not initialize."
    echo "WAN remains blocked if guard rules were installed."
    exit 1
}

UPIP="$(get_upstream_ip)"

if [ -z "$UPIP" ]; then
    echo "ERROR: Could not determine physical upstream public IP."
    use_local
fi

echo "Physical upstream IP: $UPIP"
echo "Previous upstream IP: ${LASTIP:-unknown}"

if verify_upstream; then
    use_router
fi

use_local
