#!/bin/sh

IPT=/usr/sbin/iptables
IP6T=/usr/sbin/ip6tables
LAUNCHER="/storage/.config/vpn-manager-openvpn-launcher.py"
VPNIF="tun0"

get_network()
{
    LANIF="$(ip -4 route show table main default 2>/dev/null |
        awk '/^default / {
            for (i=1;i<=NF;i++)
                if ($i=="dev") { print $(i+1); exit }
        }')"

    DNSIP="$(awk '/^nameserver[[:space:]]+/ {print $2; exit}' /etc/resolv.conf)"
    LAN="$(ip -4 route show table main dev "$LANIF" scope link 2>/dev/null |
        awk '$1 ~ /^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+\/[0-9]+$/ {
            print $1; exit
        }')"

    [ -n "$LANIF" ] && [ -n "$LAN" ]
}

get_transports()
{
    "$LAUNCHER" --transport
}

case "$1" in
  transport)
    get_transports
    exit $?
    ;;

  up)
    get_network || {
        echo "ERROR: Cannot determine LAN interface/subnet"
        exit 1
    }


    TRANSPORTS="$(get_transports 2>/dev/null)" || {
        echo "ERROR: Cannot determine selected VPN transport."
        exit 1
    }

    [ -n "$TRANSPORTS" ] || {
        echo "ERROR: Selected VPN profile has no transport."
        exit 1
    }

    echo "OpenVPN kill switch:"
    echo " LAN interface: $LANIF"
    echo " LAN subnet:    $LAN"
    echo " VPN transport(s):"
    printf '%s\n' "$TRANSPORTS" | sed 's/^/  /'

    $IPT -N CE_OVPN_KS 2>/dev/null || true
    $IPT -F CE_OVPN_KS

    while $IPT -D OUTPUT -j CE_OVPN_KS 2>/dev/null; do :; done

    # Local machine
    $IPT -A CE_OVPN_KS -o lo -j RETURN

    # Local LAN / SSH / Kodi LAN sources
    $IPT -A CE_OVPN_KS -o "$LANIF" -d "$LAN" -j RETURN

    # DHCP
    $IPT -A CE_OVPN_KS -o "$LANIF" \
        -p udp --sport 68 --dport 67 -j RETURN

    # Permit DNS through the physical interface only when routing requires it.
    # While tun0 is up, public DNS normally routes through the VPN instead.
    if [ -n "$DNSIP" ] && [ ! -f /run/x96-vpn-dns.locked ]; then
        $IPT -A CE_OVPN_KS -o "$LANIF" -d "$DNSIP" -p udp --dport 53 -j RETURN
        $IPT -A CE_OVPN_KS -o "$LANIF" -d "$DNSIP" -p tcp --dport 53 -j RETURN
    fi

    # Allow only the selected OpenVPN transport endpoint(s)
    while IFS='|' read -r VPNHOST VPNPORT VPNPROTO; do
        [ -n "$VPNHOST" ] || continue
        [ -n "$VPNPORT" ] || {
            echo "ERROR: Missing VPN port."
            exit 1
        }

        case "$VPNPROTO" in
            tcp*) VPNPROTO="tcp" ;;
            udp*) VPNPROTO="udp" ;;
            *)
                echo "ERROR: Unsupported VPN protocol: $VPNPROTO"
                exit 1
                ;;
        esac

        if echo "$VPNHOST" |
            grep -Eq '^[0-9]+(\.[0-9]+){3}$'; then
            VPNIPS="$VPNHOST"
        else
            VPNIPS="$(getent ahostsv4 "$VPNHOST" 2>/dev/null |
                awk '{print $1}' | sort -u)"
        fi

        [ -n "$VPNIPS" ] || {
            echo "ERROR: Cannot resolve VPN endpoint: $VPNHOST"
            exit 1
        }

        for VPNIP in $VPNIPS; do
            $IPT -A CE_OVPN_KS -o "$LANIF" \
                -d "$VPNIP" -p "$VPNPROTO" \
                --dport "$VPNPORT" -j RETURN || exit 1
        done
    done <<EOF
$TRANSPORTS
EOF

    # Anything routed through OpenVPN is allowed
    $IPT -A CE_OVPN_KS -o "$VPNIF" -j RETURN

    # Everything else attempting to leave outside the tunnel is blocked
    $IPT -A CE_OVPN_KS -j REJECT

    $IPT -I OUTPUT 1 -j CE_OVPN_KS

    # IPv6 fail-closed protection.
    # Permit only local/link-local IPv6. Global IPv6 cannot bypass
    # the IPv4-only OpenVPN tunnel.
    $IP6T -N CE_OVPN_KS6 2>/dev/null || true
    $IP6T -F CE_OVPN_KS6

    while $IP6T -D OUTPUT -j CE_OVPN_KS6 2>/dev/null; do :; done

    $IP6T -A CE_OVPN_KS6 -o lo -j RETURN
    $IP6T -A CE_OVPN_KS6 -d fe80::/10 -j RETURN
    $IP6T -A CE_OVPN_KS6 -d ff00::/8 -j RETURN
    $IP6T -A CE_OVPN_KS6 -j REJECT

    $IP6T -I OUTPUT 1 -j CE_OVPN_KS6
    ;;

  down)
    while $IPT -D OUTPUT -j CE_OVPN_KS 2>/dev/null; do :; done
    $IPT -F CE_OVPN_KS 2>/dev/null || true
    $IPT -X CE_OVPN_KS 2>/dev/null || true

    while $IP6T -D OUTPUT -j CE_OVPN_KS6 2>/dev/null; do :; done
    $IP6T -F CE_OVPN_KS6 2>/dev/null || true
    $IP6T -X CE_OVPN_KS6 2>/dev/null || true
    ;;

  *)
    echo "Usage: $0 {up|down}"
    exit 1
    ;;
esac
