#!/bin/sh
set -eu

CFG="/storage/.config"
BACKUP="/storage/vpn-manager-pre-migration"

SELECTOR_SERVICE="vpn-selector.service"
SELECTOR_TIMER="vpn-selector.timer"
NEW_SERVICE="vpn-manager-openvpn.service"

[ -f "$BACKUP/vpn-selector.sh" ] || {
    echo "Rollback selector backup not found." >&2
    exit 1
}

echo "Stopping selector timer..."
systemctl stop "$SELECTOR_TIMER" 2>/dev/null || true

echo "Stopping generic managed OpenVPN..."
systemctl stop "$NEW_SERVICE" 2>/dev/null || true

echo "Restoring original selector..."
cp "$BACKUP/vpn-selector.sh" "$CFG/vpn-selector.sh"
chmod 755 "$CFG/vpn-selector.sh"

systemctl daemon-reload

echo "Running original protected selector..."
systemctl start "$SELECTOR_SERVICE"

echo "Restarting selector timer..."
systemctl start "$SELECTOR_TIMER"

echo
echo "=== ROLLBACK COMPLETE ==="
echo "Selector state: $(cat /run/vpn-selector.state 2>/dev/null || echo unknown)"
