#!/bin/sh

RESOLV="/run/connman/resolv.conf"
BACKUP="/run/x96-dns.pre-vpn"
LOCK="/run/x96-vpn-dns.locked"

DNS1="1.1.1.1"
DNS2="9.9.9.9"

lock_dns()
{
    ip route get "$DNS1" 2>/dev/null | grep -q 'dev tun0' || {
        echo "ERROR: $DNS1 is not routed through tun0"
        return 1
    }

    ip route get "$DNS2" 2>/dev/null | grep -q 'dev tun0' || {
        echo "ERROR: $DNS2 is not routed through tun0"
        return 1
    }

    if [ ! -f "$BACKUP" ]; then
        cp "$RESOLV" "$BACKUP" || return 1
    fi

    {
        echo "# X96 local OpenVPN DNS"
        echo "nameserver $DNS1"
        echo "nameserver $DNS2"
    } > "$RESOLV" || {
        [ -f "$BACKUP" ] && cat "$BACKUP" > "$RESOLV"
        rm -f "$LOCK"
        return 1
    }

    touch "$LOCK"

    echo "VPN DNS locked:"
    echo " $DNS1"
    echo " $DNS2"
}

unlock_dns()
{
    if [ -f "$BACKUP" ]; then
        cat "$BACKUP" > "$RESOLV"
        rm -f "$BACKUP"
    fi

    rm -f "$LOCK"

    echo "Normal network DNS restored."
}

case "$1" in
    lock)
        lock_dns
        ;;
    unlock)
        unlock_dns
        ;;
    *)
        echo "Usage: $0 {lock|unlock}"
        exit 2
        ;;
esac
