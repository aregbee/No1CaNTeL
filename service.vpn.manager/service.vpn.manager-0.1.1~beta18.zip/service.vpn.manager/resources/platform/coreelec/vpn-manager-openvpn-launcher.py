#!/usr/bin/env python3

import argparse
import ipaddress
import json
import os
import shutil
import sys


DEFAULT_REGISTRY = (
    "/storage/.kodi/userdata/addon_data/"
    "service.vpn.manager/profiles.json"
)


DEFAULT_TARGET = (
    "/run/vpn-manager-openvpn.target.json"
)


DEFAULT_EFFECTIVE_CONFIG = (
    "/run/vpn-manager-openvpn.effective.ovpn"
)


DEFAULT_SECRET_STORE = (
    "/storage/.kodi/userdata/addon_data/"
    "service.vpn.manager/secrets.json"
)


DEFAULT_AUTH_DIR = (
    "/run/vpn-manager-openvpn-auth"
)


def fail(message, code=1):
    print(
        "VPN Manager OpenVPN: ERROR: {}".format(message),
        file=sys.stderr
    )
    raise SystemExit(code)


def load_selected_profile(registry_path):
    try:
        with open(
            registry_path,
            "r",
            encoding="utf-8"
        ) as f:
            data = json.load(f)

    except FileNotFoundError:
        fail(
            "Profile registry not found: {}".format(
                registry_path
            )
        )

    except Exception as exc:
        fail(
            "Could not read profile registry: {}".format(
                exc
            )
        )

    if not isinstance(data, dict):
        fail("Invalid profile registry")

    selected = data.get("selected")

    if not selected:
        fail("No VPN profile selected")

    for profile in data.get("profiles", []):
        if not isinstance(profile, dict):
            continue

        if profile.get("id") != selected:
            continue

        if not profile.get("enabled", True):
            fail("Selected VPN profile is disabled")

        if str(
            profile.get("type", "")
        ).strip().lower() != "openvpn":
            fail(
                "Selected profile is not OpenVPN"
            )

        profile_path = str(
            profile.get("path", "")
        ).strip()

        if not profile_path:
            fail(
                "Selected profile has no config path"
            )

        if not os.path.isfile(profile_path):
            fail(
                "OpenVPN config not found: {}".format(
                    profile_path
                )
            )

        return profile

    fail(
        "Selected profile '{}' not found".format(
            selected
        )
    )



def load_target_profile(
    registry_path,
    target_path,
):
    try:
        with open(
            target_path,
            "r",
            encoding="utf-8",
        ) as f:
            target = json.load(f)

    except FileNotFoundError:
        return None

    except Exception as exc:
        fail(
            "Could not read runtime VPN target: {}".format(
                exc
            )
        )

    if not isinstance(target, dict):
        fail("Invalid runtime VPN target")

    target_id = str(
        target.get("profile_id", "")
    ).strip()

    if not target_id:
        fail(
            "Runtime VPN target has no profile_id"
        )

    try:
        with open(
            registry_path,
            "r",
            encoding="utf-8",
        ) as f:
            data = json.load(f)

    except FileNotFoundError:
        fail(
            "Profile registry not found: {}".format(
                registry_path
            )
        )

    except Exception as exc:
        fail(
            "Could not read profile registry: {}".format(
                exc
            )
        )

    if not isinstance(data, dict):
        fail("Invalid profile registry")

    for profile in data.get("profiles", []):
        if not isinstance(profile, dict):
            continue

        if profile.get("id") != target_id:
            continue

        if not profile.get("enabled", True):
            fail("Runtime target profile is disabled")

        if str(
            profile.get("type", "")
        ).strip().lower() != "openvpn":
            fail(
                "Runtime target profile is not OpenVPN"
            )

        profile_path = str(
            profile.get("path", "")
        ).strip()

        if not profile_path:
            fail(
                "Runtime target profile has no config path"
            )

        if not os.path.isfile(profile_path):
            fail(
                "OpenVPN config not found: {}".format(
                    profile_path
                )
            )

        runtime_target = dict(target)

        remote_address = str(
            runtime_target.get(
                "remote_address",
                ""
            )
        ).strip()

        if remote_address:
            try:
                address = ipaddress.ip_address(
                    remote_address
                )
            except ValueError:
                fail(
                    "Invalid runtime target IPv4 address"
                )

            if address.version != 4:
                fail(
                    "Runtime target endpoint must be IPv4"
                )

            remote_port = str(
                runtime_target.get(
                    "remote_port",
                    ""
                )
            ).strip()

            if (
                not remote_port.isdigit()
                or not 1 <= int(remote_port) <= 65535
            ):
                fail(
                    "Invalid runtime target port"
                )

            remote_proto = str(
                runtime_target.get(
                    "remote_proto",
                    ""
                )
            ).strip().lower()

            if remote_proto.startswith("tcp"):
                remote_proto = "tcp"
            elif remote_proto.startswith("udp"):
                remote_proto = "udp"
            else:
                fail(
                    "Invalid runtime target protocol"
                )

            runtime_target[
                "remote_address"
            ] = str(address)

            runtime_target[
                "remote_port"
            ] = remote_port

            runtime_target[
                "remote_proto"
            ] = remote_proto

        profile = dict(profile)
        profile["_runtime_target"] = runtime_target

        return profile

    fail(
        "Runtime target profile '{}' not found".format(
            target_id
        )
    )


def load_effective_profile(
    registry_path,
    target_path,
):
    target = load_target_profile(
        registry_path,
        target_path,
    )

    if target is not None:
        return target

    return load_selected_profile(
        registry_path
    )



def load_profile_credentials(
    profile,
    registry_path,
    secret_store_path,
):
    auth_id = str(
        profile.get(
            "authentication_id",
            ""
        )
    ).strip()

    if not auth_id:
        return None

    try:
        with open(
            registry_path,
            "r",
            encoding="utf-8",
        ) as f:
            registry = json.load(f)
    except Exception as exc:
        fail(
            "Could not read profile registry "
            "for credentials: {}".format(
                exc
            )
        )

    auth = next(
        (
            item
            for item in registry.get(
                "authentications",
                [],
            )
            if (
                isinstance(item, dict)
                and str(
                    item.get("id", "")
                ).strip() == auth_id
            )
        ),
        None,
    )

    if not auth:
        fail(
            "Authentication record '{}' "
            "not found".format(auth_id)
        )

    auth_type = str(
        auth.get(
            "type",
            ""
        )
    ).strip().lower()

    if auth_type != "username_password":
        return None

    username = str(
        auth.get(
            "username",
            ""
        )
    )

    secret_ref = str(
        auth.get(
            "secret_ref",
            ""
        )
    ).strip()

    if not secret_ref:
        fail(
            "Authentication record has no "
            "secret reference"
        )

    try:
        with open(
            secret_store_path,
            "r",
            encoding="utf-8",
        ) as f:
            secret_data = json.load(f)
    except Exception as exc:
        fail(
            "Could not read credential store: "
            "{}".format(exc)
        )

    secret = (
        secret_data.get(
            "items",
            {}
        ).get(secret_ref)
    )

    if not isinstance(secret, dict):
        fail(
            "Credential secret '{}' "
            "not found".format(secret_ref)
        )

    values = secret.get(
        "values",
        {}
    )

    if not isinstance(values, dict):
        values = {}

    password = str(
        values.get(
            "password",
            ""
        )
    )

    if not username or not password:
        fail(
            "Username/password credentials "
            "are incomplete"
        )

    if (
        "\n" in username
        or "\r" in username
        or "\n" in password
        or "\r" in password
    ):
        fail(
            "Credentials contain invalid "
            "line breaks"
        )

    return {
        "username": username,
        "password": password,
    }


def materialize_auth_file(
    profile,
    credentials,
    auth_dir=DEFAULT_AUTH_DIR,
):
    profile_id = str(
        profile.get(
            "id",
            "profile"
        )
    )

    safe_id = "".join(
        ch
        if (
            ch.isalnum()
            or ch in "-_."
        )
        else "_"
        for ch in profile_id
    )

    if not safe_id:
        safe_id = "profile"

    os.makedirs(
        auth_dir,
        exist_ok=True,
    )

    try:
        os.chmod(
            auth_dir,
            0o700,
        )
    except OSError:
        pass

    auth_path = os.path.join(
        auth_dir,
        safe_id + ".auth",
    )

    tmp_path = auth_path + ".tmp"

    try:
        with open(
            tmp_path,
            "w",
            encoding="utf-8",
        ) as f:
            f.write(
                credentials["username"]
                + "\n"
            )
            f.write(
                credentials["password"]
                + "\n"
            )
            f.flush()
            os.fsync(f.fileno())

        os.chmod(
            tmp_path,
            0o600,
        )

        os.replace(
            tmp_path,
            auth_path,
        )

        os.chmod(
            auth_path,
            0o600,
        )

    except Exception as exc:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass

        fail(
            "Could not create runtime "
            "credential file: {}".format(
                exc
            )
        )

    return auth_path


def materialize_effective_config(
    profile,
    credentials=None,
    output_path=DEFAULT_EFFECTIVE_CONFIG,
):
    """
    Build a temporary OpenVPN config pinned to the exact endpoint
    chosen during preflight.

    The original .ovpn file is never modified.
    """
    runtime = profile.get(
        "_runtime_target"
    ) or {}

    address = str(
        runtime.get(
            "remote_address",
            ""
        )
    ).strip()

    if not address and not credentials:
        return profile["path"]

    port = (
        runtime.get("remote_port")
        if address
        else None
    )

    proto = (
        runtime.get("remote_proto")
        if address
        else None
    )

    auth_path = (
        materialize_auth_file(
            profile,
            credentials,
        )
        if credentials
        else None
    )

    source_path = profile["path"]

    try:
        with open(
            source_path,
            "r",
            encoding="utf-8",
            errors="replace",
        ) as f:
            lines = f.readlines()

    except Exception as exc:
        fail(
            "Could not read source OpenVPN config: {}".format(
                exc
            )
        )

    output = []
    remote_written = False
    auth_written = False

    for line in lines:
        stripped = line.strip()

        key = None

        if (
            stripped
            and not stripped.startswith(
                ("#", ";")
            )
        ):
            key = (
                stripped.split()[0]
                .lower()
            )

        if (
            address
            and key == "remote"
        ):
            if not remote_written:
                output.append(
                    "remote {} {} {}\n".format(
                        address,
                        port,
                        proto,
                    )
                )
                remote_written = True

            # Suppress all original remote directives so OpenVPN
            # cannot independently resolve/select another endpoint.
            continue

        if (
            auth_path
            and key == "auth-user-pass"
        ):
            if not auth_written:
                output.append(
                    "auth-user-pass {}\n".format(
                        auth_path
                    )
                )
                auth_written = True

            # Manager-owned credentials replace any original
            # auth-user-pass path for this effective launch.
            continue

        output.append(line)

    if address and not remote_written:
        fail(
            "Source OpenVPN profile has no remote directive"
        )

    if auth_path and not auth_written:
        output.append(
            "auth-user-pass {}\n".format(
                auth_path
            )
        )

    tmp_path = output_path + ".tmp"

    try:
        with open(
            tmp_path,
            "w",
            encoding="utf-8",
        ) as f:
            f.writelines(output)
            f.flush()
            os.fsync(f.fileno())

        os.replace(
            tmp_path,
            output_path,
        )

        os.chmod(
            output_path,
            0o600,
        )

    except Exception as exc:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass

        fail(
            "Could not create effective OpenVPN config: {}".format(
                exc
            )
        )

    return output_path


def cleanup_runtime_files():
    """
    Remove manager-generated OpenVPN runtime files.

    The runtime target JSON is deliberately preserved here.
    Handoff/rollback logic owns that file.
    """
    try:
        if os.path.lexists(
            DEFAULT_EFFECTIVE_CONFIG
        ):
            os.unlink(
                DEFAULT_EFFECTIVE_CONFIG
            )
    except OSError:
        pass

    try:
        if os.path.isdir(
            DEFAULT_AUTH_DIR
        ):
            for name in os.listdir(
                DEFAULT_AUTH_DIR
            ):
                path = os.path.join(
                    DEFAULT_AUTH_DIR,
                    name,
                )

                if (
                    name.endswith(".auth")
                    and os.path.lexists(path)
                ):
                    try:
                        os.unlink(path)
                    except OSError:
                        pass

            try:
                if not os.listdir(
                    DEFAULT_AUTH_DIR
                ):
                    os.rmdir(
                        DEFAULT_AUTH_DIR
                    )
            except OSError:
                pass
    except OSError:
        pass

    return 0


def find_openvpn():
    executable = (
        shutil.which("openvpn")
        or (
            "/usr/sbin/openvpn"
            if os.path.isfile("/usr/sbin/openvpn")
            else None
        )
    )

    if not executable:
        fail("OpenVPN executable not found")

    return executable


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--registry",
        default=os.environ.get(
            "VPN_MANAGER_REGISTRY",
            DEFAULT_REGISTRY
        )
    )

    parser.add_argument(
        "--secrets",
        default=os.environ.get(
            "VPN_MANAGER_SECRETS",
            DEFAULT_SECRET_STORE
        ),
        help="VPN Manager credential store"
    )

    parser.add_argument(
        "--target",
        default=os.environ.get(
            "VPN_MANAGER_TARGET",
            DEFAULT_TARGET
        ),
        help="Temporary runtime target profile"
    )

    parser.add_argument(
        "--check",
        action="store_true",
        help="Validate selection without starting OpenVPN"
    )

    parser.add_argument(
        "--cleanup",
        action="store_true",
        help="Remove generated OpenVPN runtime files"
    )

    parser.add_argument(
        "--transport",
        action="store_true",
        help="Print selected OpenVPN transport endpoints"
    )

    args = parser.parse_args()

    if args.cleanup:
        return cleanup_runtime_files()

    profile = load_effective_profile(
        args.registry,
        args.target,
    )

    executable = find_openvpn()

    if not args.transport:
        print(
            "VPN Manager OpenVPN: selected={} path={}".format(
                profile.get("name", profile["id"]),
                profile["path"]
            )
        )

    if args.transport:
        runtime = profile.get(
            "_runtime_target"
        ) or {}

        remote_address = str(
            runtime.get(
                "remote_address",
                ""
            )
        ).strip()

        if remote_address:
            print("{}|{}|{}".format(
                remote_address,
                runtime["remote_port"],
                runtime["remote_proto"],
            ))
            return 0

        with open(
            profile["path"],
            "r",
            encoding="utf-8",
            errors="replace"
        ) as f:
            lines = [
                x.strip()
                for x in f
                if x.strip()
                and not x.lstrip().startswith(("#", ";"))
            ]

        proto = "udp"
        port = "1194"

        for line in lines:
            parts = line.split()
            key = parts[0].lower()

            if key == "proto" and len(parts) >= 2:
                proto = (
                    "tcp"
                    if parts[1].lower().startswith("tcp")
                    else "udp"
                )

            elif key == "port" and len(parts) >= 2:
                port = parts[1]

        found = False

        for line in lines:
            parts = line.split()

            if parts[0].lower() != "remote" or len(parts) < 2:
                continue

            host = parts[1]
            remote_port = port
            remote_proto = proto

            if len(parts) >= 3:
                if parts[2].isdigit():
                    remote_port = parts[2]
                    if len(parts) >= 4:
                        remote_proto = parts[3]
                else:
                    remote_proto = parts[2]

            remote_proto = (
                "tcp"
                if remote_proto.lower().startswith("tcp")
                else "udp"
            )

            print("{}|{}|{}".format(
                host,
                remote_port,
                remote_proto
            ))
            found = True

        if not found:
            fail("Selected OpenVPN profile has no remote directive")

        return 0

    if args.check:
        print(
            "VPN Manager OpenVPN: executable={}".format(
                executable
            )
        )
        return 0

    credentials = load_profile_credentials(
        profile,
        args.registry,
        args.secrets,
    )

    config_path = materialize_effective_config(
        profile,
        credentials=credentials,
    )

    os.execv(
        executable,
        [
            executable,
            "--config",
            config_path,
        ]
    )


if __name__ == "__main__":
    raise SystemExit(main())
