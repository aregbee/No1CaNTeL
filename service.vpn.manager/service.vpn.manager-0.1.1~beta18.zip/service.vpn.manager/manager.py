import os
import shlex
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.backend_loader import (
    backend_capabilities,
    get_backend,
)
from resources.lib import profiles
from resources.lib import secrets as secret_store


ADDON = xbmcaddon.Addon()
WINDOW = xbmcgui.Window(10000)
DIALOG = xbmcgui.Dialog()

BACKEND = get_backend()
CAPABILITIES = backend_capabilities(
    BACKEND,
    interactive=True
)

REGISTRY = xbmcvfs.translatePath(
    "special://profile/addon_data/"
    "service.vpn.manager/profiles.json"
)

SECRET_STORE = xbmcvfs.translatePath(
    "special://profile/addon_data/"
    "service.vpn.manager/secrets.json"
)

MANAGED_PROFILE_ROOT = xbmcvfs.translatePath(
    "special://profile/addon_data/"
    "service.vpn.manager/imported"
)


def prop(name):
    value = WINDOW.getProperty(
        "VPNManager." + name
    )

    return value if value else "N/A"


def selected_profile():
    data = profiles.load(REGISTRY)

    return (
        data,
        profiles.selected_profile(data)
    )


def profile_name(profile):
    if not profile:
        return "None"

    return profile.get(
        "name",
        profile.get("id", "Unknown")
    )


def show_status():
    data, selected = selected_profile()

    message = (
        "Platform: {platform}\n"
        "Mode: {mode}\n"
        "\n"
        "VPN path: {path}\n"
        "Status: {status}\n"
        "Public IP: {public_ip}\n"
        "Interface: {interface}\n"
        "Tunnel IP: {tunnel_ip}\n"
        "Server: {server}\n"
        "Kill switch: {killswitch}\n"
        "Verification: {verification}\n"
        "\n"
        "Selected profile: {profile}"
    ).format(
        platform=CAPABILITIES["name"],
        mode=CAPABILITIES["mode"].title(),
        path=prop("VPNPath"),
        status=prop("VPNStatus"),
        public_ip=prop("PublicIP"),
        interface=prop("VPNInterface"),
        tunnel_ip=prop("VPNTunnelIP"),
        server=prop("VPNServer"),
        killswitch=prop("VPNKillSwitch"),
        verification=prop("VPNVerification"),
        profile=profile_name(selected),
    )

    DIALOG.textviewer(
        "Kodi VPN Manager",
        message
    )


def refresh_now():
    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )

    started = time.monotonic()

    while time.monotonic() - started < 60:
        xbmc.sleep(250)

        requested = WINDOW.getProperty(
            "VPNManager.RefreshVPN"
        )

        status = prop("VPNStatus")
        verification = prop(
            "VPNVerification"
        )

        if (
            requested != "1"
            and status != "Refreshing..."
            and verification != "Checking now..."
        ):
            break

    show_status()


def choose_profile():
    data = profiles.load(REGISTRY)

    available = [
        profile
        for profile in profiles.profiles(data)
        if profile.get("enabled", True)
    ]

    if not available:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No enabled managed VPN profiles are configured."
        )
        return

    current = profiles.selected_profile(data)

    labels = []

    for profile in available:
        prefix = (
            "✓ "
            if current
            and profile["id"] == current["id"]
            else ""
        )

        labels.append(
            "{}{} [{}]".format(
                prefix,
                profile["name"],
                profile["type"].upper(),
            )
        )

    choice = DIALOG.select(
        "Select VPN Profile",
        labels
    )

    if choice < 0:
        return

    selected = available[choice]

    data = profiles.set_selected(
        data,
        selected["id"]
    )

    profiles.save(
        REGISTRY,
        data
    )

    DIALOG.notification(
        "Kodi VPN Manager",
        "Selected: {}".format(
            selected["name"]
        ),
        xbmcgui.NOTIFICATION_INFO,
        3000
    )


def supported_profile_types():
    getter = getattr(
        BACKEND,
        "supported_profile_types",
        None
    )

    if not getter:
        return []

    try:
        return list(getter())
    except Exception:
        return []


def add_profile():
    types = supported_profile_types()

    if not types:
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform has no supported managed VPN profile types."
        )
        return

    if len(types) == 1:
        profile_type = types[0]

    else:
        labels = [
            item.upper()
            for item in types
        ]

        choice = DIALOG.select(
            "VPN Profile Type",
            labels
        )

        if choice < 0:
            return

        profile_type = types[choice]

    if profile_type == "openvpn":
        mask = ".ovpn"
        heading = "Select OpenVPN Profile"

    elif profile_type == "wireguard":
        mask = ".conf"
        heading = "Select WireGuard Profile"

    else:
        return

    selected_path = DIALOG.browseSingle(
        1,
        heading,
        "",
        mask,
        False,
        False,
        ""
    )

    if not selected_path:
        return

    selected_path = xbmcvfs.translatePath(
        selected_path
    )

    default_name = os.path.splitext(
        os.path.basename(selected_path)
    )[0]

    name = DIALOG.input(
        "Profile Name",
        defaultt=default_name
    ).strip()

    if not name:
        return

    data = profiles.load(REGISTRY)

    profile = {
        "id": profiles.make_id(profile_type),
        "name": name,
        "type": profile_type,
        "path": selected_path,
        "enabled": True,
    }

    data = profiles.upsert(
        data,
        profile
    )

    #
    # First profile becomes selected automatically.
    #
    if not profiles.selected_profile(data):
        data = profiles.set_selected(
            data,
            profile["id"]
        )

    profiles.save(
        REGISTRY,
        data
    )

    DIALOG.notification(
        "Kodi VPN Manager",
        "Added: {}".format(name),
        xbmcgui.NOTIFICATION_INFO,
        3000
    )


def remove_profile():
    data = profiles.load(REGISTRY)
    available = profiles.profiles(data)

    if not available:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No managed VPN profiles are configured."
        )
        return

    current = profiles.selected_profile(data)

    labels = []

    for profile in available:
        prefix = (
            "✓ "
            if current
            and profile["id"] == current["id"]
            else ""
        )

        labels.append(
            "{}{} [{}]".format(
                prefix,
                profile["name"],
                profile["type"].upper(),
            )
        )

    choice = DIALOG.select(
        "Remove VPN Profile",
        labels
    )

    if choice < 0:
        return

    profile = available[choice]

    if not DIALOG.yesno(
        "Kodi VPN Manager",
        "Remove profile '{}' ?".format(
            profile["name"]
        )
    ):
        return

    data = profiles.remove(
        data,
        profile["id"]
    )

    profiles.save(
        REGISTRY,
        data
    )

    DIALOG.notification(
        "Kodi VPN Manager",
        "Removed: {}".format(
            profile["name"]
        ),
        xbmcgui.NOTIFICATION_INFO,
        3000
    )


def can_manage(profile):
    if not CAPABILITIES["can_manage"]:
        return False

    checker = getattr(
        BACKEND,
        "can_manage_profile",
        None
    )

    if not checker:
        return False

    return bool(checker(profile))


def show_result(title, result):
    if not isinstance(result, dict):
        DIALOG.ok(
            title,
            str(result)
        )
        return

    ok = bool(result.get("ok"))

    message = result.get(
        "message",
        "Completed" if ok else "Failed"
    )

    state = result.get("state")

    if state:
        message += "\n\nState: {}".format(
            state
        )

    DIALOG.ok(
        title,
        message
    )


def connect_selected():
    data, profile = selected_profile()

    if not profile:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No VPN profile is selected."
        )
        return

    if not can_manage(profile):
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform cannot manage the selected profile."
        )
        return

    connector = getattr(
        BACKEND,
        "connect",
        None
    )

    if not connector:
        return

    result = connector(profile)

    show_result(
        "VPN Connection",
        result
    )

    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )


def disconnect_selected():
    data, profile = selected_profile()

    if not profile:
        DIALOG.ok(
            "Kodi VPN Manager",
            "No VPN profile is selected."
        )
        return

    if not can_manage(profile):
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform cannot manage the selected profile."
        )
        return

    disconnect = getattr(
        BACKEND,
        "disconnect",
        None
    )

    if not disconnect:
        return

    result = disconnect(profile)

    show_result(
        "VPN Disconnect",
        result
    )

    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )



def disable_protection_selected():
    disable = getattr(
        BACKEND,
        "disable_protection",
        None
    )

    if not disable:
        DIALOG.ok(
            "Kodi VPN Manager",
            "This platform does not support disabling managed VPN protection."
        )
        return

    confirmed = DIALOG.yesno(
        "Disable VPN Protection",
        (
            "This will stop the managed VPN, disable the kill switch "
            "and DNS lock, and restore normal Internet access.\n\n"
            "Continue?"
        )
    )

    if not confirmed:
        return

    result = disable()

    show_result(
        "VPN Protection",
        result
    )

    WINDOW.setProperty(
        "VPNManager.RefreshVPN",
        "1"
    )


def publish_dashboard_properties():
    data, selected = selected_profile()

    WINDOW.setProperty(
        "VPNManager.Platform",
        CAPABILITIES["name"]
    )

    WINDOW.setProperty(
        "VPNManager.Mode",
        CAPABILITIES["mode"].title()
    )

    WINDOW.setProperty(
        "VPNManager.SelectedProfile",
        profile_name(selected)
    )



class ProfileManagerWindow(xbmcgui.WindowXMLDialog):

    PROVIDER_LIST = 200
    PROFILE_LIST = 201

    ADD_BUTTON = 210
    IMPORT_BUTTON = 211
    EDIT_BUTTON = 212
    DELETE_BUTTON = 213
    CREDENTIALS_BUTTON = 214
    CLOSE_BUTTON = 215

    def onInit(self):
        self._data = profiles.load(REGISTRY)
        self._active_provider_id = None

        current = profiles.selected_profile(
            self._data
        )

        preferred_provider = (
            current.get("provider_id")
            if current
            else None
        )

        self._load_providers(
            preferred_provider
        )

    def _load_providers(
        self,
        preferred_provider=None,
    ):
        control = self.getControl(
            self.PROVIDER_LIST
        )

        control.reset()

        available = profiles.providers(
            self._data
        )

        chosen_index = 0

        for index, provider in enumerate(
            available
        ):
            provider_id = provider["id"]

            provider_profiles = (
                profiles.profiles_for_provider(
                    self._data,
                    provider_id,
                )
            )

            count = len(provider_profiles)

            item = xbmcgui.ListItem(
                label=provider["name"],
                label2="{} profile{}".format(
                    count,
                    "" if count == 1 else "s",
                ),
            )

            item.setProperty(
                "provider_id",
                provider_id,
            )

            control.addItem(item)

            if (
                provider_id
                == preferred_provider
            ):
                chosen_index = index

        if not available:
            self._active_provider_id = None
            self._load_profiles(None)
            return

        control.selectItem(chosen_index)

        self._active_provider_id = (
            available[
                chosen_index
            ]["id"]
        )

        self._load_profiles(
            self._active_provider_id
        )

    def _active_profile_id(self):
        # Prefer a backend-provided verified profile identity.
        getter = getattr(
            BACKEND,
            "active_profile_id",
            None,
        )

        if getter:
            try:
                profile_id = getter()

                if profile_id:
                    return profile_id

            except Exception:
                pass

        # Compatibility fallback for backends that expose only
        # their live profile/config path.
        getter = getattr(
            BACKEND,
            "active_profile_path",
            None,
        )

        if not getter:
            return None

        try:
            running_path = getter()
        except Exception:
            return None

        if not running_path:
            return None

        for profile in profiles.profiles(
            self._data
        ):
            if (
                str(profile.get("path") or "")
                == str(running_path)
            ):
                return profile.get("id")

        return None

    def _load_profiles(
        self,
        provider_id,
    ):
        control = self.getControl(
            self.PROFILE_LIST
        )

        control.reset()

        if not provider_id:
            return

        active_id = (
            self._active_profile_id()
        )

        selected = profiles.selected_profile(
            self._data
        )

        preferred_id = (
            selected.get("id")
            if selected
            else None
        )

        available = (
            profiles.profiles_for_provider(
                self._data,
                provider_id,
            )
        )

        chosen_index = 0

        for index, profile in enumerate(
            available
        ):
            profile_id = profile["id"]

            protocol = str(
                profile.get(
                    "type",
                    "unknown",
                )
            ).upper()

            state = ""

            if profile_id == active_id:
                state = "ACTIVE"
                chosen_index = index

            elif (
                active_id is None
                and profile_id
                == preferred_id
            ):
                state = "FALLBACK"
                chosen_index = index

            item = xbmcgui.ListItem(
                label=profile["name"],
                label2=protocol,
            )

            item.setProperty(
                "profile_id",
                profile_id,
            )

            item.setProperty(
                "vpn_status",
                state,
            )

            control.addItem(item)

        if available:
            control.selectItem(
                chosen_index
            )

    def _selected_provider_id(self):
        item = self.getControl(
            self.PROVIDER_LIST
        ).getSelectedItem()

        if not item:
            return None

        return item.getProperty(
            "provider_id"
        ) or None

    def _selected_profile_id(self):
        item = self.getControl(
            self.PROFILE_LIST
        ).getSelectedItem()

        if not item:
            return None

        return item.getProperty(
            "profile_id"
        ) or None

    def _activate_profile(self):
        profile_id = (
            self._selected_profile_id()
        )

        if not profile_id:
            return

        target = next(
            (
                profile
                for profile
                in profiles.profiles(
                    self._data
                )
                if profile["id"]
                == profile_id
            ),
            None,
        )

        if not target:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected VPN profile "
                "could not be found.",
            )
            return

        executor = getattr(
            BACKEND,
            "execute_handoff",
            None,
        )

        if not executor:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Protected profile switching "
                "is not available on this "
                "platform yet.",
            )
            return

        target_name = target.get(
            "name",
            profile_id,
        )

        #
        # Always ask the backend to prove the transaction is
        # safe before allowing any mutation.
        #
        try:
            preview = executor(
                target,
                dry_run=True,
            )

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Profile validation failed.\n\n"
                "{}".format(exc),
            )
            return

        if not preview.get("ok"):
            errors = (
                preview.get("errors")
                or []
            )

            detail = (
                str(errors[0])
                if errors
                else "No additional details."
            )

            DIALOG.ok(
                "Kodi VPN Manager",
                "Profile validation failed.\n\n"
                "Stage: {}\n\n{}".format(
                    preview.get(
                        "stage",
                        "preflight",
                    ),
                    detail,
                ),
            )
            return

        action = preview.get("action")

        if action == "already_active":
            DIALOG.notification(
                "Kodi VPN Manager",
                "Already active: {}".format(
                    target_name
                ),
                time=2500,
                sound=False,
            )
            return

        if (
            action
            == "router_selection_unchanged"
        ):
            DIALOG.notification(
                "Kodi VPN Manager",
                "Already preferred fallback: "
                "{}".format(
                    target_name
                ),
                time=2500,
                sound=False,
            )
            return

        #
        # Changing the preferred fallback while the router VPN
        # is authoritative does not touch networking.
        #
        if action == "select_fallback":
            confirmed = True

        #
        # A local-to-local handoff changes the live tunnel.
        # Require an explicit confirmation.
        #
        elif action == "protected_switch":
            previous_id = preview.get(
                "previous_profile_id"
            )

            previous = next(
                (
                    profile
                    for profile
                    in profiles.profiles(
                        self._data
                    )
                    if profile.get("id")
                    == previous_id
                ),
                None,
            )

            previous_name = (
                previous.get("name")
                if previous
                else previous_id
                or "current VPN"
            )

            confirmed = DIALOG.yesno(
                "Kodi VPN Manager",
                "Switch local VPN from "
                "{} to {}?\n\n"
                "Traffic remains fail-closed. "
                "If the new VPN cannot be "
                "verified, the previous profile "
                "will be restored automatically."
                .format(
                    previous_name,
                    target_name,
                ),
            )

        else:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The backend returned an "
                "unsupported profile action:\n\n"
                "{}".format(
                    action or "unknown"
                ),
            )
            return

        if not confirmed:
            return

        #
        # Execute only after the dry-run path succeeded.
        #
        try:
            result = executor(
                target,
                dry_run=False,
            )

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Profile transaction failed "
                "before completion.\n\n"
                "{}".format(exc),
            )
            return

        #
        # Reload registry and verified live state regardless of
        # success/failure so the list never displays stale data.
        #
        try:
            self._data = profiles.load(
                REGISTRY
            )

            self._load_profiles(
                self._active_provider_id
            )

        except Exception:
            pass

        if result.get("ok"):
            stage = result.get("stage")

            if stage == "fallback_selected":
                DIALOG.notification(
                    "Kodi VPN Manager",
                    "Preferred fallback: "
                    "{}".format(
                        target_name
                    ),
                    time=3000,
                    sound=False,
                )

            elif stage == "committed":
                DIALOG.notification(
                    "Kodi VPN Manager",
                    "VPN active: {}".format(
                        target_name
                    ),
                    time=3000,
                    sound=False,
                )

            else:
                DIALOG.notification(
                    "Kodi VPN Manager",
                    "{}".format(
                        target_name
                    ),
                    time=2500,
                    sound=False,
                )

            return

        errors = (
            result.get("errors")
            or []
        )

        detail = (
            str(errors[0])
            if errors
            else "No additional details."
        )

        stage = result.get(
            "stage",
            "unknown",
        )

        if result.get("rolled_back"):
            message = (
                "VPN switch failed at stage:\n"
                "{}\n\n"
                "The previous VPN profile was "
                "restored automatically.\n\n"
                "{}"
            ).format(
                stage,
                detail,
            )

        else:
            message = (
                "VPN switch failed at stage:\n"
                "{}\n\n"
                "Automatic rollback was not "
                "confirmed. Check VPN status "
                "before retrying.\n\n"
                "{}"
            ).format(
                stage,
                detail,
            )

        DIALOG.ok(
            "Kodi VPN Manager",
            message,
        )

    def _add_openvpn_profile(self):
        if (
            "openvpn"
            not in supported_profile_types()
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "OpenVPN profile creation is not "
                "supported on this platform.",
            )
            return

        name = DIALOG.input(
            "Profile Name"
        ).strip()

        if not name:
            return

        import ipaddress as _ipaddress
        import re as _re
        import socket as _socket

        while True:
            host = DIALOG.input(
                "VPN Server",
            ).strip()

            if not host:
                return

            if (
                "://" in host
                or "/" in host
                or "\\" in host
                or any(
                    ch.isspace()
                    for ch in host
                )
            ):
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "Enter only a VPN server "
                    "hostname or IP address.\n\n"
                    "Do not enter a URL, path, "
                    "or port number.",
                )
                continue

            is_ip = False

            try:
                _ipaddress.ip_address(host)
                is_ip = True

            except ValueError:
                dns_host = host.rstrip(".")

                try:
                    ascii_host = (
                        dns_host
                        .encode("idna")
                        .decode("ascii")
                    )
                except Exception:
                    ascii_host = ""

                labels = ascii_host.split(".")

                valid_hostname = (
                    bool(ascii_host)
                    and len(ascii_host) <= 253
                    and all(
                        len(label) <= 63
                        and _re.fullmatch(
                            r"[A-Za-z0-9]"
                            r"(?:[A-Za-z0-9-]{0,61}"
                            r"[A-Za-z0-9])?",
                            label,
                        )
                        for label in labels
                    )
                )

                if not valid_hostname:
                    DIALOG.ok(
                        "Kodi VPN Manager",
                        "The VPN server name is "
                        "not valid.",
                    )
                    continue

                host = ascii_host

            if not is_ip:
                try:
                    _socket.getaddrinfo(
                        host,
                        None,
                    )

                except _socket.gaierror:
                    choice = DIALOG.select(
                        "Server could not be resolved",
                        [
                            "Retry server name",
                            "Save Anyway",
                            "Cancel",
                        ],
                    )

                    if choice == 0:
                        continue

                    if choice != 1:
                        return

            break

        port_text = DIALOG.input(
            "VPN Port",
            defaultt="1194",
        ).strip()

        if not port_text:
            return

        try:
            port = int(port_text)
        except ValueError:
            port = 0

        if not 1 <= port <= 65535:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The VPN port must be between "
                "1 and 65535.",
            )
            return

        protocol_index = DIALOG.select(
            "VPN Protocol",
            [
                "UDP",
                "TCP",
            ],
        )

        if protocol_index < 0:
            return

        protocol = (
            "udp"
            if protocol_index == 0
            else "tcp"
        )

        provider_id = (
            self._selected_provider_id()
            or self._active_provider_id
            or "legacy"
        )

        #
        # Keep the ID compatible with the existing
        # OpenVPN profile naming convention without
        # depending on UI-visible profile names.
        #
        import time as _time

        stamp = int(_time.time())
        suffix = int(
            _time.time() * 1000000
        ) % 1000000

        while True:
            profile_id = (
                "openvpn-{}-{:06d}".format(
                    stamp,
                    suffix,
                )
            )

            profile_dir = os.path.join(
                MANAGED_PROFILE_ROOT,
                profile_id,
            )

            if not os.path.exists(
                profile_dir
            ):
                break

            suffix = (
                suffix + 1
            ) % 1000000

        config_path = os.path.join(
            profile_dir,
            "profile.ovpn",
        )

        config_text = (
            "client\n"
            "dev tun\n"
            "proto {protocol}\n"
            "remote {host} {port}\n"
            "resolv-retry infinite\n"
            "nobind\n"
            "persist-key\n"
            "persist-tun\n"
            "verb 3\n"
        ).format(
            protocol=protocol,
            host=host,
            port=port,
        )

        try:
            os.makedirs(
                profile_dir,
                exist_ok=False,
            )

            with open(
                config_path,
                "x",
                encoding="utf-8",
            ) as f:
                f.write(config_text)

        except Exception as exc:
            try:
                if os.path.isfile(
                    config_path
                ):
                    os.unlink(config_path)

                if (
                    os.path.isdir(profile_dir)
                    and not os.listdir(
                        profile_dir
                    )
                ):
                    os.rmdir(profile_dir)

            except Exception:
                pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "The managed OpenVPN profile "
                "could not be created."
                "\n\n{}".format(exc),
            )
            return

        item = {
            "id": profile_id,
            "name": name,
            "type": "openvpn",
            "path": config_path,
            "enabled": True,
            "provider_id": provider_id,
            "authentication_id": None,
            "protocol_options": {},
        }

        data = profiles.upsert(
            self._data,
            item,
        )

        try:
            profiles.save(
                REGISTRY,
                data,
            )

        except Exception as exc:
            try:
                if os.path.isfile(
                    config_path
                ):
                    os.unlink(config_path)

                if (
                    os.path.isdir(profile_dir)
                    and not os.listdir(
                        profile_dir
                    )
                ):
                    os.rmdir(profile_dir)

            except Exception:
                pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "The profile could not be "
                "saved to the registry."
                "\n\n{}".format(exc),
            )
            return

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        control = self.getControl(
            self.PROFILE_LIST
        )

        for index in range(
            control.size()
        ):
            row = control.getListItem(
                index
            )

            if (
                row
                and row.getProperty(
                    "profile_id"
                ) == profile_id
            ):
                control.selectItem(index)
                break

        self.setFocusId(
            self.PROFILE_LIST
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            "Added: {}".format(name),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _import_openvpn_profile(self):
        if (
            "openvpn"
            not in supported_profile_types()
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "OpenVPN import is not supported "
                "on this platform.",
            )
            return

        provider_id = (
            self._selected_provider_id()
            or self._active_provider_id
        )

        if not provider_id:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Select a provider before importing "
                "an OpenVPN profile.",
            )
            return

        source_path = DIALOG.browseSingle(
            1,
            "Import OpenVPN Profile",
            "",
            ".ovpn",
            False,
            False,
            "",
        )

        if not source_path:
            return

        source_path = xbmcvfs.translatePath(
            source_path
        )

        if not os.path.isfile(source_path):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected OpenVPN profile "
                "could not be opened.",
            )
            return

        try:
            with open(
                source_path,
                "r",
                encoding="utf-8",
                errors="replace",
            ) as handle:
                source_lines = handle.readlines()

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Could not read the selected "
                "OpenVPN profile.\n\n{}".format(
                    exc
                ),
            )
            return

        file_directives = {
            "auth-user-pass",
            "ca",
            "cert",
            "crl-verify",
            "dh",
            "extra-certs",
            "key",
            "pkcs12",
            "tls-auth",
            "tls-crypt",
            "tls-crypt-v2",
        }

        remotes = []
        relative_files = []
        parse_errors = []

        for line_number, raw in enumerate(
            source_lines,
            1,
        ):
            stripped = raw.strip()

            if (
                not stripped
                or stripped.startswith("#")
                or stripped.startswith(";")
                or stripped.startswith("<")
            ):
                continue

            try:
                parts = shlex.split(
                    stripped,
                    comments=False,
                    posix=True,
                )

            except ValueError as exc:
                parse_errors.append(
                    "line {}: {}".format(
                        line_number,
                        exc,
                    )
                )
                continue

            if not parts:
                continue

            key = parts[0].lower()

            if key == "remote":
                if len(parts) < 2:
                    parse_errors.append(
                        "line {}: remote has no host".format(
                            line_number
                        )
                    )
                else:
                    remotes.append(parts[1:])

            if (
                key in file_directives
                and len(parts) >= 2
            ):
                reference = parts[1].strip()

                if reference == "[inline]":
                    continue

                if (
                    reference
                    and not os.path.isabs(reference)
                ):
                    relative_files.append(
                        "{} {}".format(
                            key,
                            reference,
                        )
                    )

        if parse_errors:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The OpenVPN profile contains an "
                "invalid directive.\n\n{}".format(
                    parse_errors[0]
                ),
            )
            return

        if not remotes:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The OpenVPN profile contains no "
                "remote server directive.",
            )
            return

        if relative_files:
            preview = "\n".join(
                relative_files[:5]
            )

            if len(relative_files) > 5:
                preview += "\n..."

            DIALOG.ok(
                "Kodi VPN Manager",
                "This profile uses relative external "
                "files. Moving only the .ovpn file "
                "would break those references.\n\n"
                "{}\n\n"
                "Companion-file import will be "
                "added separately.".format(
                    preview
                ),
            )
            return

        source_name = os.path.basename(
            source_path
        )

        default_name = os.path.splitext(
            source_name
        )[0]

        name = DIALOG.input(
            "Imported Profile Name",
            defaultt=default_name,
        ).strip()

        if not name:
            return

        profile_id = profiles.make_id(
            "openvpn"
        )

        destination_dir = os.path.join(
            MANAGED_PROFILE_ROOT,
            profile_id,
        )

        destination_path = os.path.join(
            destination_dir,
            "profile.ovpn",
        )

        try:
            os.makedirs(
                destination_dir,
                exist_ok=False,
            )

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "Could not create managed profile "
                "storage.\n\n{}".format(exc),
            )
            return

        try:
            copied = xbmcvfs.copy(
                source_path,
                destination_path,
            )

            if (
                not copied
                or not os.path.isfile(
                    destination_path
                )
            ):
                raise RuntimeError(
                    "Kodi could not copy the profile."
                )

            data = profiles.load(REGISTRY)

            profile = {
                "id": profile_id,
                "name": name,
                "type": "openvpn",
                "path": destination_path,
                "enabled": True,
                "provider_id": provider_id,
                "authentication_id": None,
                "protocol_options": {},
            }

            data = profiles.upsert(
                data,
                profile,
            )

            if not profiles.selected_profile(
                data
            ):
                data = profiles.set_selected(
                    data,
                    profile_id,
                )

            profiles.save(
                REGISTRY,
                data,
            )

        except Exception as exc:
            try:
                if os.path.isfile(
                    destination_path
                ):
                    os.unlink(destination_path)

                if os.path.isdir(
                    destination_dir
                ):
                    os.rmdir(destination_dir)

            except Exception:
                pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "OpenVPN profile import failed."
                "\n\n{}".format(exc),
            )
            return

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        control = self.getControl(
            self.PROFILE_LIST
        )

        for index in range(control.size()):
            item = control.getListItem(index)

            if (
                item
                and item.getProperty("profile_id")
                == profile_id
            ):
                control.selectItem(index)
                break

        self.setFocusId(
            self.PROFILE_LIST
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            "Imported: {}".format(name),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _credentials_for_selected_profile(self):
        profile_id = self._selected_profile_id()

        if not profile_id:
            return

        target = next(
            (
                profile
                for profile in profiles.profiles(
                    self._data
                )
                if profile.get("id")
                == profile_id
            ),
            None,
        )

        if not target:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected VPN profile "
                "could not be found.",
            )
            return

        if (
            str(
                target.get("type", "")
            ).strip().lower()
            != "openvpn"
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "Username/password credentials "
                "are currently supported only "
                "for OpenVPN profiles.",
            )
            return

        provider_id = (
            target.get("provider_id")
            or "legacy"
        )

        existing_auth = None

        existing_auth_id = target.get(
            "authentication_id"
        )

        if existing_auth_id:
            existing_auth = (
                profiles.authentication(
                    self._data,
                    existing_auth_id,
                )
            )

        current_username = ""

        if existing_auth:
            current_username = str(
                existing_auth.get(
                    "username",
                    ""
                )
            ).strip()

        secret_data_before = (
            secret_store.load(
                SECRET_STORE
            )
        )

        current_password = ""

        if existing_auth:
            old_ref = existing_auth.get(
                "secret_ref"
            )

            if old_ref:
                old_secret = (
                    secret_store.get_secret(
                        secret_data_before,
                        old_ref,
                    )
                )

                if old_secret:
                    current_password = str(
                        old_secret.get(
                            "values",
                            {}
                        ).get(
                            "password",
                            ""
                        )
                    )

        username = DIALOG.input(
            "VPN Username",
            defaultt=current_username,
        ).strip()

        if not username:
            return

        if (
            "\n" in username
            or "\r" in username
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The username cannot contain "
                "line breaks.",
            )
            return

        password_heading = (
            "VPN Password"
            if not current_password
            else
            "VPN Password "
            "(leave blank to keep current)"
        )

        entered_password = DIALOG.input(
            password_heading,
            "",
            xbmcgui.INPUT_ALPHANUM,
            xbmcgui.ALPHANUM_HIDE_INPUT,
        )

        if entered_password:
            confirmed_password = DIALOG.input(
                "Confirm VPN Password",
                "",
                xbmcgui.INPUT_ALPHANUM,
                xbmcgui.ALPHANUM_HIDE_INPUT,
            )

            if (
                entered_password
                != confirmed_password
            ):
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "The passwords do not match.\n\n"
                    "Credentials were not changed.",
                )
                return

            password = entered_password

        else:
            password = current_password

        if not password:
            DIALOG.ok(
                "Kodi VPN Manager",
                "A password is required.",
            )
            return

        if (
            "\n" in password
            or "\r" in password
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The password cannot contain "
                "line breaks.",
            )
            return

        auth_id = (
            existing_auth.get("id")
            if existing_auth
            else
            "auth-{}".format(profile_id)
        )

        secret_ref = (
            existing_auth.get("secret_ref")
            if existing_auth
            and existing_auth.get(
                "secret_ref"
            )
            else
            "secret-{}".format(auth_id)
        )

        auth_record = {
            "id": auth_id,
            "provider_id": provider_id,
            "label": "{} credentials".format(
                target.get(
                    "name",
                    profile_id,
                )
            ),
            "type": "username_password",
            "username": username,
            "secret_ref": secret_ref,
            "options": {},
        }

        new_secret_data = (
            secret_store.set_secret(
                secret_data_before,
                secret_ref,
                "username_password",
                {
                    "password": password,
                },
            )
        )

        new_data = (
            profiles.upsert_authentication(
                self._data,
                auth_record,
            )
        )

        updated_profile = dict(target)
        updated_profile[
            "authentication_id"
        ] = auth_id

        new_data = profiles.upsert(
            new_data,
            updated_profile,
        )

        try:
            secret_store.save(
                SECRET_STORE,
                new_secret_data,
            )

            profiles.save(
                REGISTRY,
                new_data,
            )

        except Exception as exc:
            try:
                secret_store.save(
                    SECRET_STORE,
                    secret_data_before,
                )
            except Exception:
                pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "The credentials could not "
                "be saved."
                "\n\n{}".format(exc),
            )
            return

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        control = self.getControl(
            self.PROFILE_LIST
        )

        for index in range(
            control.size()
        ):
            row = control.getListItem(
                index
            )

            if (
                row
                and row.getProperty(
                    "profile_id"
                ) == profile_id
            ):
                control.selectItem(index)
                break

        self.setFocusId(
            self.PROFILE_LIST
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            "Credentials saved: {}".format(
                target.get(
                    "name",
                    profile_id,
                )
            ),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _edit_selected_profile(self):
        profile_id = (
            self._selected_profile_id()
        )

        if not profile_id:
            return

        target = next(
            (
                profile
                for profile
                in profiles.profiles(
                    self._data
                )
                if profile.get("id")
                == profile_id
            ),
            None,
        )

        if not target:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected VPN profile "
                "could not be found.",
            )
            return

        current_name = target.get(
            "name",
            profile_id,
        )

        new_name = DIALOG.input(
            "Profile Name",
            defaultt=current_name,
        ).strip()

        if not new_name:
            return

        if new_name == current_name:
            return

        updated = dict(target)
        updated["name"] = new_name

        data = profiles.upsert(
            self._data,
            updated,
        )

        try:
            profiles.save(
                REGISTRY,
                data,
            )

        except Exception as exc:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The profile could not be updated."
                "\n\n{}".format(exc),
            )
            return

        provider_id = updated.get(
            "provider_id"
        )

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        control = self.getControl(
            self.PROFILE_LIST
        )

        for index in range(control.size()):
            item = control.getListItem(index)

            if (
                item
                and item.getProperty("profile_id")
                == profile_id
            ):
                control.selectItem(index)
                break

        self.setFocusId(
            self.PROFILE_LIST
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            "Renamed: {}".format(new_name),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _delete_selected_profile(self):
        profile_id = (
            self._selected_profile_id()
        )

        if not profile_id:
            return

        target = next(
            (
                profile
                for profile
                in profiles.profiles(
                    self._data
                )
                if profile.get("id")
                == profile_id
            ),
            None,
        )

        if not target:
            DIALOG.ok(
                "Kodi VPN Manager",
                "The selected VPN profile "
                "could not be found.",
            )
            return

        active_id = self._active_profile_id()

        if (
            active_id
            and active_id == profile_id
        ):
            DIALOG.ok(
                "Kodi VPN Manager",
                "The active local VPN profile "
                "cannot be deleted.\n\n"
                "Switch to another VPN profile "
                "first.",
            )
            return

        name = target.get(
            "name",
            profile_id,
        )

        if not DIALOG.yesno(
            "Kodi VPN Manager",
            "Delete profile '{}'?\n\n"
            "This removes it from VPN Manager."
            .format(name),
        ):
            return

        profile_path = str(
            target.get("path") or ""
        ).strip()

        provider_id = target.get(
            "provider_id"
        )

        auth_id = target.get(
            "authentication_id"
        )

        auth_record = (
            profiles.authentication(
                self._data,
                auth_id,
            )
            if auth_id
            else None
        )

        secret_ref = (
            auth_record.get("secret_ref")
            if auth_record
            else None
        )

        #
        # Remove the profile first in memory. Its authentication
        # record is removed only if nothing else still uses it.
        #
        data = profiles.remove(
            self._data,
            profile_id,
        )

        remove_auth = False

        if auth_id:
            profile_still_uses_auth = any(
                item.get(
                    "authentication_id"
                ) == auth_id
                for item
                in profiles.profiles(data)
            )

            provider_still_uses_auth = any(
                item.get(
                    "default_authentication_id"
                ) == auth_id
                for item
                in data.get(
                    "providers",
                    [],
                )
            )

            if (
                not profile_still_uses_auth
                and not provider_still_uses_auth
            ):
                data = (
                    profiles.remove_authentication(
                        data,
                        auth_id,
                    )
                )
                remove_auth = True

        secret_data_before = (
            secret_store.load(
                SECRET_STORE
            )
        )

        secret_data_after = (
            secret_data_before
        )

        remove_secret = False

        if (
            remove_auth
            and secret_ref
        ):
            secret_still_used = any(
                item.get("secret_ref")
                == secret_ref
                for item
                in profiles.authentications(
                    data
                )
            )

            if not secret_still_used:
                secret_data_after = (
                    secret_store.remove_secret(
                        secret_data_before,
                        secret_ref,
                    )
                )
                remove_secret = True

        #
        # Persist the secret-store change first. If the registry
        # write then fails, restore the prior secret store.
        #
        if remove_secret:
            try:
                secret_store.save(
                    SECRET_STORE,
                    secret_data_after,
                )

            except Exception as exc:
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "The profile was not deleted "
                    "because its stored credentials "
                    "could not be removed."
                    "\n\n{}".format(exc),
                )
                return

        try:
            profiles.save(
                REGISTRY,
                data,
            )

        except Exception as exc:
            if remove_secret:
                try:
                    secret_store.save(
                        SECRET_STORE,
                        secret_data_before,
                    )
                except Exception:
                    pass

            DIALOG.ok(
                "Kodi VPN Manager",
                "The profile could not be "
                "removed from the registry."
                "\n\n{}".format(exc),
            )
            return

        #
        # Delete physical files only for profiles that
        # VPN Manager imported into its own managed tree.
        # Externally referenced profiles remain untouched.
        #
        managed_file_removed = False

        if profile_path:
            try:
                root = os.path.realpath(
                    MANAGED_PROFILE_ROOT
                )

                candidate = os.path.realpath(
                    profile_path
                )

                if (
                    os.path.commonpath(
                        [root, candidate]
                    ) == root
                ):
                    if os.path.isfile(candidate):
                        os.unlink(candidate)
                        managed_file_removed = True

                    parent = os.path.dirname(
                        candidate
                    )

                    if (
                        parent != root
                        and os.path.isdir(parent)
                        and not os.listdir(parent)
                    ):
                        os.rmdir(parent)

            except Exception as exc:
                DIALOG.ok(
                    "Kodi VPN Manager",
                    "The profile was removed from "
                    "VPN Manager, but its managed "
                    "file could not be cleaned up."
                    "\n\n{}".format(exc),
                )

        #
        # Remove any stale runtime credential file belonging
        # specifically to this deleted profile.
        #
        try:
            safe_id = "".join(
                ch
                if (
                    ch.isalnum()
                    or ch in "-_."
                )
                else "_"
                for ch in str(profile_id)
            )

            runtime_auth_dir = (
                "/run/vpn-manager-openvpn-auth"
            )

            runtime_auth_path = os.path.join(
                runtime_auth_dir,
                safe_id + ".auth",
            )

            if os.path.isfile(
                runtime_auth_path
            ):
                os.unlink(
                    runtime_auth_path
                )

            if (
                os.path.isdir(
                    runtime_auth_dir
                )
                and not os.listdir(
                    runtime_auth_dir
                )
            ):
                os.rmdir(
                    runtime_auth_dir
                )

        except Exception:
            pass

        self._data = profiles.load(
            REGISTRY
        )

        self._load_providers(
            provider_id
        )

        DIALOG.notification(
            "Kodi VPN Manager",
            "Deleted: {}".format(name),
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )


    def _not_ready(self, feature):
        xbmcgui.Dialog().notification(
            "Kodi VPN Manager",
            "{} is next in beta18 development.".format(
                feature
            ),
            time=2500,
            sound=False,
        )

    def onClick(self, control_id):

        if control_id == self.PROVIDER_LIST:
            provider_id = (
                self._selected_provider_id()
            )

            if provider_id:
                self._active_provider_id = (
                    provider_id
                )

                self._load_profiles(
                    provider_id
                )

            return

        if control_id == self.PROFILE_LIST:
            self._activate_profile()
            return

        if control_id == self.ADD_BUTTON:
            self._add_openvpn_profile()
            return

        if control_id == self.IMPORT_BUTTON:
            self._import_openvpn_profile()
            return

        if control_id == self.EDIT_BUTTON:
            self._edit_selected_profile()
            return

        if control_id == self.DELETE_BUTTON:
            self._delete_selected_profile()
            return

        if (
            control_id
            == self.CREDENTIALS_BUTTON
        ):
            self._credentials_for_selected_profile()
            return

        if control_id == self.CLOSE_BUTTON:
            self.close()

    def onAction(self, action):
        action_id = action.getId()

        if (
            action_id == 7
            and self.getFocusId()
            == self.PROFILE_LIST
        ):
            self._activate_profile()
            return

        if action_id in (
            9,
            10,
            92,
        ):
            self.close()


def open_profile_manager():
    window = ProfileManagerWindow(
        "VPNProfileManager.xml",
        ADDON.getAddonInfo("path"),
        "Default",
        "720p",
    )

    window.doModal()

    del window


class DashboardWindow(xbmcgui.WindowXMLDialog):
    REFRESH_BUTTON = 100
    SETTINGS_BUTTON = 101
    CHANGE_PROFILE_BUTTON = 102
    BACK_ACTIONS = (9, 10, 92)

    def onInit(self):
        publish_dashboard_properties()
        self.setFocusId(self.REFRESH_BUTTON)

    def onClick(self, control_id):
        if control_id == self.REFRESH_BUTTON:
            WINDOW.setProperty(
                "VPNManager.RefreshVPN",
                "1"
            )

        elif control_id == self.SETTINGS_BUTTON:
            ADDON.openSettings()
            publish_dashboard_properties()

        elif control_id == self.CHANGE_PROFILE_BUTTON:
            open_profile_manager()
            publish_dashboard_properties()

    def onAction(self, action):
        if action.getId() in self.BACK_ACTIONS:
            self.close()


def main():
    publish_dashboard_properties()

    dashboard = DashboardWindow(
        "VPNManagerDashboard.xml",
        ADDON.getAddonInfo("path"),
        "Default",
        "720p"
    )

    dashboard.doModal()
    del dashboard


if __name__ == "__main__":
    main()
