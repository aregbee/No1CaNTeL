import xbmc
import xbmcgui

from resources.lib.backend_loader import (
    backend_capabilities,
    get_backend,
    platform_name,
)
from resources.lib import netverify

backend = get_backend()
PLATFORM = platform_name()
CAPABILITIES = backend_capabilities(backend)

import time


window = xbmcgui.Window(10000)
monitor = xbmc.Monitor()


def setprop(name, value):
    window.setProperty(name, str(value) if value else "N/A")


def _dashboard_interface(value):
    text = str(value or "").strip()

    if "(" in text and text.endswith(")"):
        return text.rsplit("(", 1)[1][:-1].strip()

    if text in ("", "N/A", "Unknown"):
        return ""

    return text


def _dashboard_path(value):
    text = str(value or "Unknown").strip()
    lower = text.lower()

    if "router" in lower or "upstream" in lower:
        return "Router/Upstream"

    if "local" in lower or "openvpn" in lower:
        return "Local OpenVPN"

    return text


def publish_dashboard_summary(state):
    state = state or {}

    status = str(
        state.get("status", "CHECK VPN")
    ).strip()

    path = _dashboard_path(
        state.get("path", "Unknown")
    )

    interface = _dashboard_interface(
        state.get("interface", "")
    )

    summary = "{} - {}".format(
        status,
        path
    )

    if interface:
        summary += " [{}]".format(interface)

    setprop(
        "VPNManager.StatusSummary",
        summary
    )

    path_lower = str(
        state.get("path", "")
    ).lower()

    status_lower = status.lower()

    if (
        ("local" in path_lower or "openvpn" in path_lower)
        and status_lower == "protected"
    ):
        activity = "Active"

    elif (
        ("router" in path_lower or "upstream" in path_lower)
        and status_lower == "protected"
    ):
        activity = "Standby"

    else:
        activity = "Inactive"

    setprop(
        "VPNManager.ProfileActivity",
        activity
    )


def publish_backend_state(state):
    state = state or {}

    publish_dashboard_summary(state)

    setprop("VPNManager.PublicIP", "Updating...")
    setprop("VPNManager.VPNExitLocation", "Updating...")
    setprop("VPNManager.VPNExitNetwork", "Updating...")
    setprop("VPNManager.VPNPath", state.get("path", "Unknown"))
    setprop("VPNManager.VPNStatus", state.get("status", "CHECK VPN"))
    setprop("VPNManager.VPNInterface", state.get("interface", "N/A"))
    setprop("VPNManager.VPNTunnelIP", state.get("tunnel_ip", "N/A"))
    setprop("VPNManager.VPNServer", state.get("server", "Unknown"))
    setprop("VPNManager.VPNKillSwitch", state.get("killswitch", "Unknown"))
    setprop(
        "VPNManager.VPNVerification",
        state.get("verification", "Backend state unavailable")
    )


def refresh():
    # Publish authoritative local/backend state first.
    # External IP classification is supplemental and must not delay
    # path/status/killswitch changes appearing in Kodi.
    backend_state = backend.vpn_state()
    publish_backend_state(backend_state)

    external = netverify.external_vpn_check()
    state = netverify.merge_state(
        backend_state,
        external
    )

    pub = external.get(
        "public_ip",
        "Unavailable"
    )

    path = state.get("path", "Unknown")
    status = state.get("status", "CHECK VPN")
    interface = state.get("interface", "N/A")
    tip = state.get("tunnel_ip", "N/A")
    server = state.get("server", "Unknown")
    killswitch = state.get("killswitch", "Unknown")
    verification = state.get(
        "verification",
        "Backend state unavailable"
    )

    setprop("VPNManager.PublicIP", pub)
    setprop(
        "VPNManager.VPNExitLocation",
        external.get("exit_location", "Unavailable")
    )
    setprop(
        "VPNManager.VPNExitNetwork",
        external.get("exit_network", "Unavailable")
    )
    setprop("VPNManager.VPNPath", path)
    setprop("VPNManager.VPNStatus", status)
    setprop("VPNManager.VPNInterface", interface)
    setprop("VPNManager.VPNTunnelIP", tip)
    setprop("VPNManager.VPNServer", server)
    setprop("VPNManager.VPNKillSwitch", killswitch)
    setprop("VPNManager.VPNVerification", verification)

    publish_dashboard_summary(state)

    xbmc.log(
        "Kodi VPN Manager: Public={} VPN={} Status={} Verify={}".format(
            pub,
            path,
            status,
            verification
        ),
        xbmc.LOGINFO
    )


AUTO_REFRESH_SECONDS = 300

FAILOVER_PROBE_SECONDS = 30
LOCAL_ROUTER_RECHECK_SECONDS = 120
UNKNOWN_RECHECK_SECONDS = 60
PROBE_FAILURE_CONFIRMATIONS = 2

FAILED_RETRY_DELAYS = (
    30,
    60,
    120,
    300,
)

next_auto_refresh = (
    time.monotonic()
    + AUTO_REFRESH_SECONDS
)

next_failover_probe = (
    time.monotonic()
    + 10
)

router_probe_failures = 0
detector_degraded = False
failed_retry_attempts = 0

last_state_token = backend.state_token()

# Initial display refresh, after backend state tracking exists.
refresh()

while not monitor.waitForAbort(1):

    current_state_token = backend.state_token()

    state_changed = (
        bool(current_state_token)
        and current_state_token != last_state_token
    )

    if state_changed:
        xbmc.log(
            "Kodi VPN Manager: VPN state changed {} -> {}".format(
                last_state_token or "unknown",
                current_state_token
            ),
            xbmc.LOGINFO
        )

        last_state_token = current_state_token

    #
    # Lightweight automatic failover watchdog v2.
    #
    now = time.monotonic()

    if now >= next_failover_probe:

        try:
            selector_mode = backend.selector_state()
        except Exception:
            selector_mode = "unknown"

        request_selector = False
        request_reason = None
        next_delay = FAILOVER_PROBE_SECONDS

        # ----------------------------------------------------
        # Router mode
        # ----------------------------------------------------
        if selector_mode == "router":

            failed_retry_attempts = 0

            try:
                probe = (
                    backend.lightweight_router_probe()
                    or {}
                )
            except Exception as exc:
                probe = {
                    "ok": False,
                    "changed": False,
                    "physical_internet": None,
                    "reason": str(exc),
                }

            if probe.get("ok"):

                router_probe_failures = 0
                detector_degraded = False

                if probe.get("changed"):
                    request_selector = True

                    request_reason = (
                        "router upstream fingerprint changed "
                        "{} -> {}".format(
                            probe.get(
                                "previous_ip",
                                "unknown",
                            ),
                            probe.get(
                                "current_ip",
                                "unknown",
                            ),
                        )
                    )

            elif probe.get("physical_internet") is True:

                # Internet still works. Failure of the public-IP
                # detector alone is NOT evidence of VPN loss.
                router_probe_failures = 0

                if not detector_degraded:
                    xbmc.log(
                        "Kodi VPN Manager: public-IP detector "
                        "degraded while physical Internet remains "
                        "reachable; selector suppressed: {}".format(
                            probe.get(
                                "reason",
                                "unknown",
                            )
                        ),
                        xbmc.LOGWARNING
                    )

                detector_degraded = True

            else:

                detector_degraded = False
                router_probe_failures += 1

                if (
                    router_probe_failures
                    >= PROBE_FAILURE_CONFIRMATIONS
                ):
                    request_selector = True

                    request_reason = (
                        "physical upstream unavailable "
                        "{} consecutive times".format(
                            router_probe_failures
                        )
                    )

                    router_probe_failures = 0

            next_delay = FAILOVER_PROBE_SECONDS

        # ----------------------------------------------------
        # Local mode
        # ----------------------------------------------------
        elif selector_mode == "local":

            router_probe_failures = 0
            detector_degraded = False
            failed_retry_attempts = 0

            request_selector = True
            request_reason = (
                "periodic protected router recovery check"
            )

            next_delay = LOCAL_ROUTER_RECHECK_SECONDS

        # ----------------------------------------------------
        # Fail-closed mode
        # ----------------------------------------------------
        elif selector_mode == "failed":

            router_probe_failures = 0
            detector_degraded = False

            index = min(
                failed_retry_attempts,
                len(FAILED_RETRY_DELAYS) - 1,
            )

            retry_delay = FAILED_RETRY_DELAYS[index]

            try:
                recovery = (
                    backend.failed_recovery_probe()
                    or {}
                )
            except Exception as exc:
                recovery = {
                    "ready": False,
                    "reason": str(exc),
                }

            if recovery.get("ready"):

                request_selector = True
                request_reason = (
                    "failed-path recovery signal: {}".format(
                        recovery.get(
                            "reason",
                            "ready",
                        )
                    )
                )

            else:

                xbmc.log(
                    "Kodi VPN Manager: fail-closed path "
                    "still has no recovery signal; selector "
                    "suppressed; retry in {}s".format(
                        retry_delay
                    ),
                    xbmc.LOGINFO
                )

            failed_retry_attempts += 1
            next_delay = retry_delay

        # ----------------------------------------------------
        # Unknown / startup state
        # ----------------------------------------------------
        else:

            router_probe_failures = 0
            detector_degraded = False
            failed_retry_attempts = 0

            request_selector = True
            request_reason = (
                "VPN path is {}".format(
                    selector_mode or "unknown"
                )
            )

            next_delay = UNKNOWN_RECHECK_SECONDS

        if request_selector:

            xbmc.log(
                "Kodi VPN Manager: automatic selector request: "
                "{}".format(
                    request_reason
                ),
                xbmc.LOGINFO
            )

            try:
                backend.request_refresh()

            except Exception as exc:
                xbmc.log(
                    "Kodi VPN Manager: automatic selector "
                    "request failed: {}".format(
                        exc
                    ),
                    xbmc.LOGERROR
                )

        # Re-base AFTER any blocking selector run.
        next_failover_probe = (
            time.monotonic()
            + next_delay
        )

    manual_refresh = (
        window.getProperty("VPNManager.RefreshVPN") == "1"
    )

    timed_refresh = (
        time.monotonic() >= next_auto_refresh
    )

    if manual_refresh or timed_refresh or state_changed:

        if manual_refresh:
            window.clearProperty("VPNManager.RefreshVPN")
            setprop("VPNManager.VPNStatus", "Refreshing...")
            setprop("VPNManager.VPNVerification", "Checking now...")

            xbmc.log(
                "Kodi VPN Manager: Manual VPN refresh requested",
                xbmc.LOGINFO
            )

            try:
                result = backend.request_refresh()

                # If a backend refresh is already running,
                # wait for it to finish before reading state.
                for _ in range(90):
                    if not backend.refresh_in_progress():
                        break

                    if monitor.waitForAbort(0.5):
                        break

                xbmc.log(
                    "Kodi VPN Manager: VPN refresh result={}".format(
                        result if result is not None else "unavailable"
                    ),
                    xbmc.LOGINFO
                )

            except Exception as exc:
                xbmc.log(
                    "Kodi VPN Manager: VPN refresh failed: {}".format(exc),
                    xbmc.LOGERROR
                )

        if state_changed and not manual_refresh:
            monitor.waitForAbort(2)

        refresh()

        # Prevent a manual backend refresh from causing a duplicate refresh.
        last_state_token = backend.state_token() or last_state_token

        next_auto_refresh = (
            time.monotonic() + AUTO_REFRESH_SECONDS
        )


for prop in (
    "VPNManager.PublicIP",
    "VPNManager.VPNExitLocation",
    "VPNManager.VPNExitNetwork",
    "VPNManager.VPNPath",
    "VPNManager.VPNStatus",
    "VPNManager.StatusSummary",
    "VPNManager.ProfileActivity",
    "VPNManager.VPNInterface",
    "VPNManager.VPNTunnelIP",
    "VPNManager.VPNServer",
    "VPNManager.VPNKillSwitch",
    "VPNManager.VPNVerification",
):
    window.clearProperty(prop)
