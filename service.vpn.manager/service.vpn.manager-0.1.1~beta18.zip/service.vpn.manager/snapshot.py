#!/usr/bin/env python3

import datetime
import os
import tarfile


ROOT = os.path.dirname(
    os.path.abspath(__file__)
)

SNAPSHOT_DIR = (
    os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
        "snapshots",
        "service.vpn.manager",
    )
)

with open(
    os.path.join(ROOT, "VERSION"),
    "r",
    encoding="utf-8"
) as f:
    version = f.read().strip()

stamp = datetime.datetime.now().strftime(
    "%Y%m%d-%H%M%S"
)

output = os.path.join(
    SNAPSHOT_DIR,
    "service.vpn.manager-{}-{}.tar.gz".format(
        version,
        stamp
    )
)

os.makedirs(
    SNAPSHOT_DIR,
    exist_ok=True
)

def exclude(info):
    parts = info.name.split("/")

    if "__pycache__" in parts:
        return None

    if (
        ".before-" in info.name
        or info.name.endswith(".backup")
        or info.name.endswith(".pyc")
    ):
        return None

    return info


with tarfile.open(
    output,
    "w:gz"
) as archive:

    archive.add(
        ROOT,
        arcname="service.vpn.manager",
        filter=exclude
    )

print(output)
