#!/usr/bin/env python3

import os
import zipfile


ROOT = os.path.dirname(
    os.path.abspath(__file__)
)

VERSION_FILE = os.path.join(
    ROOT,
    "VERSION"
)

with open(
    VERSION_FILE,
    "r",
    encoding="utf-8"
) as f:
    VERSION = f.read().strip()

OUTPUT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
    "builds",
    "service.vpn.manager",
)

OUTPUT = os.path.join(
    OUTPUT_DIR,
    "service.vpn.manager-{}.zip".format(
        VERSION
    )
)

EXCLUDED_PARTS = {
    "__pycache__",
}

EXCLUDED_MARKERS = (
    ".backup",
    ".before-",
    ".pyc",
)

os.makedirs(
    OUTPUT_DIR,
    exist_ok=True
)

if os.path.exists(OUTPUT):
    os.unlink(OUTPUT)

parent = os.path.dirname(ROOT)

with zipfile.ZipFile(
    OUTPUT,
    "w",
    compression=zipfile.ZIP_DEFLATED
) as archive:

    for base, dirs, files in os.walk(ROOT):

        dirs[:] = [
            d for d in dirs
            if d not in EXCLUDED_PARTS
        ]

        for filename in files:

            if any(
                marker in filename
                for marker in EXCLUDED_MARKERS
            ):
                continue

            full = os.path.join(
                base,
                filename
            )

            relative = os.path.relpath(
                full,
                parent
            )

            archive.write(
                full,
                relative
            )

print(OUTPUT)
