import xbmc
import xbmcgui

from resources.lib.backend_loader import (
    backend_capabilities,
    get_backend,
    platform_name,
)
from resources.lib import netverify

backend = get_backend()
PLATFORM = platform_name()
CAPABILITIES = backend_capabilities(backend)

import time


window = xbmcgui.Window(10000)
monitor = xbmc.Monitor()


def setprop(name, value):
    window.setProperty(name, str(value) if value else "N/A")


def refresh():
    backend_state = backend.vpn_state()
    external = netverify.external_vpn_check()
    state = netverify.merge_state(
        backend_state,
        external
    )

    pub = external.get(
        "public_ip",
        "Unavailable"
    )

    path = state.get("path", "Unknown")
    status = state.get("status", "CHECK VPN")
    interface = state.get("interface", "N/A")
    tip = state.get("tunnel_ip", "N/A")
    server = state.get("server", "Unknown")
    killswitch = state.get("killswitch", "Unknown")
    verification = state.get(
        "verification",
        "Backend state unavailable"
    )

    setprop("VPNManager.PublicIP", pub)
    setprop("VPNManager.VPNPath", path)
    setprop("VPNManager.VPNStatus", status)
    setprop("VPNManager.VPNInterface", interface)
    setprop("VPNManager.VPNTunnelIP", tip)
    setprop("VPNManager.VPNServer", server)
    setprop("VPNManager.VPNKillSwitch", killswitch)
    setprop("VPNManager.VPNVerification", verification)

    xbmc.log(
        "Kodi VPN Manager: Public={} VPN={} Status={} Verify={}".format(
            pub,
            path,
            status,
            verification
        ),
        xbmc.LOGINFO
    )


AUTO_REFRESH_SECONDS = 300
next_auto_refresh = time.monotonic() + AUTO_REFRESH_SECONDS
last_state_token = backend.state_token()

# Initial display refresh, after backend state tracking exists.
refresh()

while not monitor.waitForAbort(1):

    current_state_token = backend.state_token()

    state_changed = (
        bool(current_state_token)
        and current_state_token != last_state_token
    )

    if state_changed:
        xbmc.log(
            "Kodi VPN Manager: VPN state changed {} -> {}".format(
                last_state_token or "unknown",
                current_state_token
            ),
            xbmc.LOGINFO
        )

        last_state_token = current_state_token

    manual_refresh = (
        window.getProperty("VPNManager.RefreshVPN") == "1"
    )

    timed_refresh = (
        time.monotonic() >= next_auto_refresh
    )

    if manual_refresh or timed_refresh or state_changed:

        if manual_refresh:
            window.clearProperty("VPNManager.RefreshVPN")
            setprop("VPNManager.VPNStatus", "Refreshing...")
            setprop("VPNManager.VPNVerification", "Checking now...")

            xbmc.log(
                "Kodi VPN Manager: Manual VPN refresh requested",
                xbmc.LOGINFO
            )

            try:
                result = backend.request_refresh()

                # If a backend refresh is already running,
                # wait for it to finish before reading state.
                for _ in range(90):
                    if not backend.refresh_in_progress():
                        break

                    if monitor.waitForAbort(0.5):
                        break

                xbmc.log(
                    "Kodi VPN Manager: VPN refresh result={}".format(
                        result if result is not None else "unavailable"
                    ),
                    xbmc.LOGINFO
                )

            except Exception as exc:
                xbmc.log(
                    "Kodi VPN Manager: VPN refresh failed: {}".format(exc),
                    xbmc.LOGERROR
                )

        if state_changed and not manual_refresh:
            monitor.waitForAbort(2)

        refresh()

        # Prevent a manual backend refresh from causing a duplicate refresh.
        last_state_token = backend.state_token() or last_state_token

        next_auto_refresh = (
            time.monotonic() + AUTO_REFRESH_SECONDS
        )


for prop in (
    "VPNManager.PublicIP",
    "VPNManager.VPNPath",
    "VPNManager.VPNStatus",
    "VPNManager.VPNInterface",
    "VPNManager.VPNTunnelIP",
    "VPNManager.VPNServer",
    "VPNManager.VPNKillSwitch",
    "VPNManager.VPNVerification",
):
    window.clearProperty(prop)
