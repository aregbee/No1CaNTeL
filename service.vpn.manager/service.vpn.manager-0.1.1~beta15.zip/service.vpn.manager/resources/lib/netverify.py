import json
import shutil
import subprocess
import urllib.error
import urllib.request


CURL = shutil.which("curl")


def _run(args, timeout=12):
    if not args or not args[0]:
        return ""

    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=timeout
        )

        if result.returncode == 0:
            return result.stdout.strip()

    except Exception:
        pass

    return ""


def _urllib_fetch(url, post=False, timeout=10):
    try:
        data = b"{}" if post else None

        request = urllib.request.Request(
            url,
            data=data,
            headers={
                "User-Agent": "Kodi-VPN-Manager/0.1",
                "Accept": "application/json,text/plain,*/*",
            },
            method="POST" if post else "GET",
        )

        if post:
            request.add_header(
                "Content-Type",
                "application/json"
            )

        with urllib.request.urlopen(
            request,
            timeout=timeout
        ) as response:
            return response.read().decode(
                "utf-8",
                errors="replace"
            ).strip()

    except Exception:
        return ""


def fetch(url, interface=None, post=False):
    #
    # Binding to a specific interface is primarily useful on Linux
    # when checking upstream connectivity independently of a local
    # VPN tunnel. urllib cannot do that portably, so use curl when
    # interface binding is explicitly requested.
    #
    if interface and CURL:
        args = [
            CURL,
            "-4fsS",
            "--connect-timeout", "5",
            "--max-time", "10",
            "--interface", interface,
        ]

        if post:
            args.extend([
                "-X", "POST",
                "-H", "Content-Type: application/json",
                "-d", "{}",
            ])

        args.append(url)

        return _run(args)

    #
    # Portable path for Android, Windows, Linux and CoreELEC.
    #
    value = _urllib_fetch(
        url,
        post=post
    )

    if value:
        return value

    #
    # Fallback for appliance environments where Python HTTPS
    # certificate handling may be incomplete.
    #
    if CURL:
        args = [
            CURL,
            "-4fsS",
            "--connect-timeout", "5",
            "--max-time", "10",
        ]

        if post:
            args.extend([
                "-X", "POST",
                "-H", "Content-Type: application/json",
                "-d", "{}",
            ])

        args.append(url)

        return _run(args)

    return ""


def json_data(text):
    try:
        return json.loads(text)
    except Exception:
        return None


def _boolish(value):
    if isinstance(value, bool):
        return value

    if isinstance(value, (int, float)):
        return bool(value)

    if isinstance(value, str):
        value = value.strip().lower()

        if value in ("true", "yes", "1"):
            return True

        if value in ("false", "no", "0"):
            return False

    return None


def public_ip(interface=None):
    value = fetch(
        "https://api.ipify.org",
        interface=interface
    )

    return value if value else "Unavailable"


def external_vpn_check(interface=None):
    first = json_data(
        fetch(
            "https://api.ipapi.is/",
            interface=interface
        )
    )

    second = json_data(
        fetch(
            "https://iplogs.com/v1/check",
            interface=interface,
            post=True
        )
    )

    detector1 = None
    detector2 = None
    pub = "Unavailable"

    if isinstance(first, dict):
        if first.get("ip"):
            pub = str(first["ip"])

        if "is_vpn" in first:
            detector1 = _boolish(
                first.get("is_vpn")
            )

    if isinstance(second, dict):
        raw = _boolish(
            second.get("is_vpn")
        )

        verdict = str(
            second.get("verdict", "")
        ).lower()

        if raw is not None:
            detector2 = (
                raw
                and verdict == "vpn_detected"
            )

    if pub == "Unavailable":
        pub = public_ip(interface)

    positive = sum(
        value is True
        for value in (
            detector1,
            detector2,
        )
    )

    negative = sum(
        value is False
        for value in (
            detector1,
            detector2,
        )
    )

    if positive == 2:
        verdict = "vpn"

    elif positive == 1:
        verdict = "probable_vpn"

    elif negative == 2:
        verdict = "not_detected"

    else:
        verdict = "unknown"

    return {
        "public_ip": pub,
        "verdict": verdict,
        "detector1": detector1,
        "detector2": detector2,
    }


def merge_state(state, external):
    result = dict(state or {})
    external = external or {}

    verdict = external.get("verdict", "unknown")
    local_tunnel = bool(
        result.get("local_tunnel", False)
    )
    backend_verified = bool(
        result.get("backend_verified", False)
    )

    result["external_verdict"] = verdict

    #
    # Strong backend evidence remains authoritative.
    # External services are supplementary and may disagree.
    #
    if backend_verified:
        if verdict == "vpn":
            result["verification"] = (
                "{}; external VPN confirmed".format(
                    result.get("verification", "Backend verified")
                )
            )

        elif verdict == "probable_vpn":
            result["verification"] = (
                "{}; external VPN probable".format(
                    result.get("verification", "Backend verified")
                )
            )

        elif verdict == "not_detected":
            result["verification"] = (
                "{}; external detector disagrees".format(
                    result.get("verification", "Backend verified")
                )
            )

        return result

    #
    # A local tunnel exists, but that alone does not prove
    # it is a privacy VPN. Android firewall/ad-blocking apps
    # may also create VPN-style tunnel interfaces.
    #
    if local_tunnel:
        if verdict == "vpn":
            result["status"] = "Protected"
            result["verification"] = (
                "Local tunnel route + external VPN confirmed"
            )

        elif verdict == "probable_vpn":
            result["status"] = "PROBABLE VPN"
            result["verification"] = (
                "Local tunnel detected + external VPN probable"
            )

        elif verdict == "not_detected":
            result["status"] = (
                "TUNNEL ACTIVE - VPN NOT CONFIRMED"
            )
            result["verification"] = (
                "Local tunnel detected; external VPN not detected"
            )

        else:
            result["status"] = (
                "VPN TUNNEL ACTIVE - VERIFYING"
            )

        return result

    #
    # No local tunnel is visible. External detection can therefore
    # indicate a router/upstream VPN without requiring local control.
    #
    if verdict == "vpn":
        result.update({
            "path": "Router / upstream VPN",
            "status": "Protected",
            "server": "Upstream / externally detected",
            "killswitch": "Upstream-managed",
            "verification": "External VPN confirmed",
        })

    elif verdict == "probable_vpn":
        result.update({
            "path": "Possible router / upstream VPN",
            "status": "PROBABLE VPN",
            "server": "Upstream / externally detected",
            "killswitch": "Upstream-managed",
            "verification": "External VPN probable",
        })

    elif verdict == "not_detected":
        result["status"] = "VPN NOT DETECTED"
        result["verification"] = (
            "No local tunnel; external VPN not detected"
        )

    return result
