import json
import os
import tempfile
import time


SUPPORTED_TYPES = (
    "openvpn",
    "wireguard",
)

SCHEMA_VERSION = 1


def _default_data():
    return {
        "schema": SCHEMA_VERSION,
        "selected": None,
        "profiles": [],
    }


def _normalize_profile(profile):
    if not isinstance(profile, dict):
        return None

    profile_id = str(
        profile.get("id", "")
    ).strip()

    name = str(
        profile.get("name", "")
    ).strip()

    profile_type = str(
        profile.get("type", "")
    ).strip().lower()

    path = str(
        profile.get("path", "")
    ).strip()

    if not profile_id:
        return None

    if not name:
        return None

    if profile_type not in SUPPORTED_TYPES:
        return None

    if not path:
        return None

    return {
        "id": profile_id,
        "name": name,
        "type": profile_type,
        "path": path,
        "enabled": bool(
            profile.get("enabled", True)
        ),
    }


def load(path):
    if not os.path.isfile(path):
        return _default_data()

    try:
        with open(
            path,
            "r",
            encoding="utf-8"
        ) as f:
            raw = json.load(f)

    except Exception:
        return _default_data()

    if not isinstance(raw, dict):
        return _default_data()

    result = _default_data()

    selected = raw.get("selected")

    if selected is not None:
        result["selected"] = str(selected)

    seen = set()

    for item in raw.get("profiles", []):
        profile = _normalize_profile(item)

        if not profile:
            continue

        if profile["id"] in seen:
            continue

        seen.add(profile["id"])
        result["profiles"].append(profile)

    if result["selected"] not in seen:
        result["selected"] = None

    return result


def save(path, data):
    directory = os.path.dirname(path)

    if directory:
        os.makedirs(
            directory,
            exist_ok=True
        )

    clean = _default_data()

    seen = set()

    for item in data.get("profiles", []):
        profile = _normalize_profile(item)

        if not profile:
            continue

        if profile["id"] in seen:
            continue

        seen.add(profile["id"])
        clean["profiles"].append(profile)

    selected = data.get("selected")

    if selected in seen:
        clean["selected"] = selected

    fd, temp_path = tempfile.mkstemp(
        prefix=".vpn-profiles-",
        suffix=".tmp",
        dir=directory or None,
        text=True,
    )

    try:
        with os.fdopen(
            fd,
            "w",
            encoding="utf-8"
        ) as f:
            json.dump(
                clean,
                f,
                indent=2,
                sort_keys=True,
            )

            f.write("\n")
            f.flush()
            os.fsync(f.fileno())

        os.replace(
            temp_path,
            path
        )

    except Exception:
        try:
            os.unlink(temp_path)
        except Exception:
            pass

        raise


def profiles(data):
    return list(
        data.get("profiles", [])
    )


def selected_profile(data):
    selected = data.get("selected")

    if not selected:
        return None

    for profile in profiles(data):
        if profile["id"] == selected:
            return profile

    return None


def set_selected(data, profile_id):
    result = {
        "schema": SCHEMA_VERSION,
        "selected": None,
        "profiles": profiles(data),
    }

    for profile in result["profiles"]:
        if (
            profile["id"] == profile_id
            and profile["enabled"]
        ):
            result["selected"] = profile_id
            break

    return result


def upsert(data, profile):
    normalized = _normalize_profile(
        profile
    )

    if not normalized:
        raise ValueError(
            "Invalid VPN profile"
        )

    result = {
        "schema": SCHEMA_VERSION,
        "selected": data.get("selected"),
        "profiles": [],
    }

    replaced = False

    for existing in profiles(data):
        if existing["id"] == normalized["id"]:
            result["profiles"].append(
                normalized
            )
            replaced = True
        else:
            result["profiles"].append(
                existing
            )

    if not replaced:
        result["profiles"].append(
            normalized
        )

    return result


def remove(data, profile_id):
    result = {
        "schema": SCHEMA_VERSION,
        "selected": data.get("selected"),
        "profiles": [
            profile
            for profile in profiles(data)
            if profile["id"] != profile_id
        ],
    }

    if result["selected"] == profile_id:
        result["selected"] = None

    return result


def make_id(prefix="vpn"):
    return "{}-{}".format(
        prefix,
        int(time.time() * 1000)
    )
