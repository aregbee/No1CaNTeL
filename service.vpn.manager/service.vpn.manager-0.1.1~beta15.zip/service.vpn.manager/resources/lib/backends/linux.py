import os
import re
import shutil
import subprocess

from resources.lib import profiles as profile_registry


BACKEND_ID = "linux"
BACKEND_NAME = "CoreELEC / Linux"
MODE = "manager"

CAN_MONITOR = True
CAN_MANAGE = True



IP = shutil.which("ip")
IPTABLES = shutil.which("iptables")

STATE_FILE = "/run/vpn-selector.state"
OPENVPN_PROFILE = "/storage/.config/openvpn/purevpn.ovpn"
PROFILE_REGISTRY = (
    "/storage/.kodi/userdata/addon_data/"
    "service.vpn.manager/profiles.json"
)


def run(args, timeout=8):
    if not args or not args[0]:
        return ""

    try:
        result = subprocess.run(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=timeout
        )

        if result.returncode == 0:
            return result.stdout.strip()

    except Exception:
        pass

    return ""


def lan_interface():
    if not IP:
        return ""

    data = run([
        IP, "-4", "route", "show",
        "table", "main", "default"
    ])

    for line in data.splitlines():
        parts = line.split()

        if "dev" in parts:
            try:
                return parts[parts.index("dev") + 1]
            except Exception:
                pass

    return ""


def internet_route():
    if not IP:
        return ""

    return run([IP, "-4", "route", "get", "1.1.1.1"])


def tunnel_ip():
    if not IP:
        return ""

    data = run([
        IP, "-4", "-o", "addr", "show",
        "dev", "tun0"
    ])

    match = re.search(r"\binet\s+([0-9.]+)/", data)

    return match.group(1) if match else ""


def tunnel_exists():
    return os.path.exists("/sys/class/net/tun0")


def kill_switch_active():
    if not IPTABLES:
        return False

    data = run([IPTABLES, "-S", "OUTPUT"])

    return "-A OUTPUT -j CE_OVPN_KS" in data


def selected_openvpn_path():
    try:
        data = profile_registry.load(
            PROFILE_REGISTRY
        )

        profile = profile_registry.selected_profile(
            data
        )

        if (
            profile
            and profile.get("enabled", True)
            and str(
                profile.get("type", "")
            ).lower() == "openvpn"
        ):
            profile_path = str(
                profile.get("path", "")
            ).strip()

            if profile_path:
                return profile_path

    except Exception:
        pass

    # Temporary compatibility fallback for the current installation.
    return OPENVPN_PROFILE


def configured_server():
    profile_path = selected_openvpn_path()

    try:
        with open(
            profile_path,
            "r",
            encoding="utf-8"
        ) as f:
            for line in f:
                parts = line.strip().split()

                if len(parts) >= 2 and parts[0] == "remote":
                    host = parts[1]

                    if len(parts) >= 3:
                        return "{}:{}".format(
                            host,
                            parts[2]
                        )

                    return host

    except Exception:
        pass

    return "N/A"


def selector_state():
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return ""


SYSTEMCTL = shutil.which("systemctl")
SELECTOR_SERVICE = "vpn-selector.service"


def start_selector():
    if not SYSTEMCTL:
        return None

    try:
        result = subprocess.run(
            [
                SYSTEMCTL,
                "start",
                SELECTOR_SERVICE
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=45
        )

        return result.returncode

    except Exception:
        return None


def selector_service_state():
    if not SYSTEMCTL:
        return ""

    return run(
        [
            SYSTEMCTL,
            "is-active",
            SELECTOR_SERVICE
        ],
        timeout=2
    )


def vpn_state():
    route = internet_route()
    state = selector_state()
    iface = lan_interface() or "LAN"

    local_routed = (
        tunnel_exists()
        and "dev tun0" in route
    )

    # Local OpenVPN is actually carrying Internet traffic.
    if local_routed:
        ks = kill_switch_active()

        return {
            "path": "Local OpenVPN",
            "status": (
                "Protected"
                if ks
                else "VPN ACTIVE - KILL SWITCH OFF"
            ),
            "interface": "tun0",
            "tunnel_ip": tunnel_ip() or "N/A",
            "server": configured_server(),
            "killswitch": "Active" if ks else "INACTIVE",
            "verification": "tun0 route confirmed",
            "selector_state": state,
            "local_tunnel": True,
            "backend_verified": True,
        }

    # Router/upstream VPN selected and verified.
    if state == "router":
        return {
            "path": "Router / upstream VPN",
            "status": "Protected",
            "interface": "Upstream ({})".format(iface),
            "tunnel_ip": "N/A",
            "server": "Router-managed",
            "killswitch": "Router-managed",
            "verification": "Selector verified",
            "selector_state": state,
            "local_tunnel": False,
            "backend_verified": True,
        }

    # Selector expected local VPN but tun0 is not routing Internet.
    if state == "local":
        ks = kill_switch_active()

        return {
            "path": "Local OpenVPN",
            "status": "ROUTE FAULT",
            "interface": iface,
            "tunnel_ip": "N/A",
            "server": configured_server(),
            "killswitch": "Active" if ks else "INACTIVE",
            "verification": "tun0 Internet route missing",
            "selector_state": state,
            "local_tunnel": tunnel_exists(),
            "backend_verified": False,
        }

    # Selector deliberately failed closed.
    if state == "failed":
        ks = kill_switch_active()

        return {
            "path": "Local OpenVPN failed",
            "status": "FAIL-CLOSED",
            "interface": iface,
            "tunnel_ip": "N/A",
            "server": configured_server(),
            "killswitch": "Active" if ks else "UNKNOWN",
            "verification": "Selector failure",
            "selector_state": state,
            "local_tunnel": tunnel_exists(),
            "backend_verified": False,
        }

    # No trustworthy selector state available yet.
    ks = kill_switch_active()

    return {
        "path": "Unknown",
        "status": "CHECK VPN",
        "interface": iface,
        "tunnel_ip": "N/A",
        "server": "Unknown",
        "killswitch": "Active" if ks else "Unknown",
        "verification": "Selector state unavailable",
        "selector_state": state,
        "local_tunnel": tunnel_exists(),
        "backend_verified": False,
    }


def state_token():
    return selector_state()


def request_refresh():
    return start_selector()


def refresh_in_progress():
    return selector_service_state() in (
        "active",
        "activating",
    )


MANAGED_OPENVPN_SERVICE = "vpn-manager-openvpn.service"
MANAGEMENT_POLICY = "protected-selector"


def _profile_error(message):
    return {
        "ok": False,
        "code": None,
        "message": message,
    }


def can_manage_profile(profile):
    if not isinstance(profile, dict):
        return False

    if not profile.get("enabled", True):
        return False

    profile_type = str(
        profile.get("type", "")
    ).strip().lower()

    profile_path = str(
        profile.get("path", "")
    ).strip()

    return bool(
        SYSTEMCTL
        and profile_type == "openvpn"
        and profile_path
        and os.path.isfile(profile_path)
    )


def connect(profile):
    if not isinstance(profile, dict):
        return _profile_error(
            "Invalid VPN profile"
        )

    if not profile.get("enabled", True):
        return _profile_error(
            "VPN profile is disabled"
        )

    profile_type = str(
        profile.get("type", "")
    ).strip().lower()

    if profile_type != "openvpn":
        return _profile_error(
            "CoreELEC manager currently supports OpenVPN profiles"
        )

    if not can_manage_profile(profile):
        return _profile_error(
            "OpenVPN profile or manager backend unavailable"
        )

    try:
        data = profile_registry.load(
            PROFILE_REGISTRY
        )

        data = profile_registry.upsert(
            data,
            profile
        )

        data = profile_registry.set_selected(
            data,
            profile["id"]
        )

        selected = profile_registry.selected_profile(
            data
        )

        if not selected:
            return _profile_error(
                "Could not select VPN profile"
            )

        profile_registry.save(
            PROFILE_REGISTRY,
            data
        )

    except Exception as exc:
        return _profile_error(
            "Could not update VPN profile registry: {}".format(
                exc
            )
        )

    #
    # Do NOT start OpenVPN directly.
    # The selector first verifies the upstream/router path,
    # then starts the managed local fallback only if required.
    #
    code = request_refresh()

    if code == 0:
        return {
            "ok": True,
            "code": code,
            "message": "Protected VPN selection completed",
            "state": selector_state(),
        }

    return {
        "ok": False,
        "code": code,
        "message": "Protected VPN selection failed",
        "state": selector_state(),
    }


def disconnect(profile):
    if not isinstance(profile, dict):
        return _profile_error(
            "Invalid VPN profile"
        )

    #
    # Never deliberately remove the local protected path unless
    # the selector has already established that the router VPN
    # is the authoritative protected path.
    #
    state = selector_state()

    if state != "router":
        return {
            "ok": False,
            "code": None,
            "message": (
                "Local VPN disconnect refused: "
                "no verified upstream VPN path"
            ),
            "state": state,
        }

    if not SYSTEMCTL:
        return _profile_error(
            "systemctl unavailable"
        )

    try:
        result = subprocess.run(
            [
                SYSTEMCTL,
                "stop",
                MANAGED_OPENVPN_SERVICE,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=30,
        )

        return {
            "ok": result.returncode == 0,
            "code": result.returncode,
            "message": (
                "Managed local VPN stopped; "
                "verified router VPN retained"
            ),
            "state": state,
        }

    except Exception as exc:
        return {
            "ok": False,
            "code": None,
            "message": str(exc),
            "state": state,
        }


def supported_profile_types():
    return ["openvpn"]


def supported_profile_types():
    return ["openvpn"]
