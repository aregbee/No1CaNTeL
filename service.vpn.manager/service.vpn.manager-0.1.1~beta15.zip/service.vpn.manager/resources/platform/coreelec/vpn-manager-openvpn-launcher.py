#!/usr/bin/env python3

import argparse
import json
import os
import shutil
import sys


DEFAULT_REGISTRY = (
    "/storage/.kodi/userdata/addon_data/"
    "service.vpn.manager/profiles.json"
)


def fail(message, code=1):
    print(
        "VPN Manager OpenVPN: ERROR: {}".format(message),
        file=sys.stderr
    )
    raise SystemExit(code)


def load_selected_profile(registry_path):
    try:
        with open(
            registry_path,
            "r",
            encoding="utf-8"
        ) as f:
            data = json.load(f)

    except FileNotFoundError:
        fail(
            "Profile registry not found: {}".format(
                registry_path
            )
        )

    except Exception as exc:
        fail(
            "Could not read profile registry: {}".format(
                exc
            )
        )

    if not isinstance(data, dict):
        fail("Invalid profile registry")

    selected = data.get("selected")

    if not selected:
        fail("No VPN profile selected")

    for profile in data.get("profiles", []):
        if not isinstance(profile, dict):
            continue

        if profile.get("id") != selected:
            continue

        if not profile.get("enabled", True):
            fail("Selected VPN profile is disabled")

        if str(
            profile.get("type", "")
        ).strip().lower() != "openvpn":
            fail(
                "Selected profile is not OpenVPN"
            )

        profile_path = str(
            profile.get("path", "")
        ).strip()

        if not profile_path:
            fail(
                "Selected profile has no config path"
            )

        if not os.path.isfile(profile_path):
            fail(
                "OpenVPN config not found: {}".format(
                    profile_path
                )
            )

        return profile

    fail(
        "Selected profile '{}' not found".format(
            selected
        )
    )


def find_openvpn():
    executable = (
        shutil.which("openvpn")
        or (
            "/usr/sbin/openvpn"
            if os.path.isfile("/usr/sbin/openvpn")
            else None
        )
    )

    if not executable:
        fail("OpenVPN executable not found")

    return executable


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--registry",
        default=os.environ.get(
            "VPN_MANAGER_REGISTRY",
            DEFAULT_REGISTRY
        )
    )

    parser.add_argument(
        "--check",
        action="store_true",
        help="Validate selection without starting OpenVPN"
    )

    args = parser.parse_args()

    profile = load_selected_profile(
        args.registry
    )

    executable = find_openvpn()

    print(
        "VPN Manager OpenVPN: selected={} path={}".format(
            profile.get("name", profile["id"]),
            profile["path"]
        )
    )

    if args.check:
        print(
            "VPN Manager OpenVPN: executable={}".format(
                executable
            )
        )
        return 0

    os.execv(
        executable,
        [
            executable,
            "--config",
            profile["path"],
        ]
    )


if __name__ == "__main__":
    raise SystemExit(main())
