#!/bin/sh
set -eu

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DEV="$(cd "$SCRIPT_DIR/../../.." && pwd)"
CFG="/storage/.config"
SYSTEMD="$CFG/system.d"
BACKUP="/storage/vpn-manager-pre-migration"

STATE_FILE="/run/vpn-selector.state"

OLD_SERVICE="purevpn-openvpn.service"
NEW_SERVICE="vpn-manager-openvpn.service"
SELECTOR_SERVICE="vpn-selector.service"
SELECTOR_TIMER="vpn-selector.timer"

OLD_SELECTOR="$CFG/vpn-selector.sh"
NEW_SELECTOR="$DEV/resources/platform/coreelec/vpn-selector.sh"

NEW_LAUNCHER="$DEV/resources/platform/coreelec/vpn-manager-openvpn-launcher.py"
NEW_UNIT="$DEV/resources/platform/coreelec/vpn-manager-openvpn.service"

fail()
{
    echo "MIGRATION ABORTED: $*" >&2
    exit 1
}

echo "=== Kodi VPN Manager CoreELEC migration ==="

#
# Preflight
#
[ -f "$NEW_SELECTOR" ] || fail "Development selector missing"
[ -f "$NEW_LAUNCHER" ] || fail "OpenVPN launcher missing"
[ -f "$NEW_UNIT" ] || fail "OpenVPN service unit missing"

sh -n "$NEW_SELECTOR" ||
    fail "Development selector has a shell syntax error"

"$NEW_LAUNCHER" --check ||
    fail "Selected OpenVPN profile failed validation"

CURRENT_STATE="$(cat "$STATE_FILE" 2>/dev/null || true)"

[ "$CURRENT_STATE" = "router" ] ||
    fail "Current protected path is '$CURRENT_STATE', not router"

if systemctl is-active --quiet "$OLD_SERVICE"; then
    fail "Old local PureVPN service is still active"
fi

echo "Preflight: OK"
echo "Current path: router"
echo

#
# Preserve the original live files once.
#
mkdir -p "$BACKUP"

if [ ! -f "$BACKUP/vpn-selector.sh" ]; then
    cp -a "$OLD_SELECTOR" "$BACKUP/vpn-selector.sh"
fi

if [ ! -f "$BACKUP/purevpn-openvpn.service" ]; then
    cp -a \
        "$SYSTEMD/purevpn-openvpn.service" \
        "$BACKUP/purevpn-openvpn.service"
fi

echo "Rollback files: $BACKUP"

#
# Prevent the selector timer from racing the migration.
#
TIMER_WAS_ACTIVE=0

if systemctl is-active --quiet "$SELECTOR_TIMER"; then
    TIMER_WAS_ACTIVE=1
    systemctl stop "$SELECTOR_TIMER"
fi

systemctl stop "$SELECTOR_SERVICE" 2>/dev/null || true

rollback()
{
    echo
    echo "Migration validation failed -- restoring old selector."

    systemctl stop "$NEW_SERVICE" 2>/dev/null || true

    cp "$BACKUP/vpn-selector.sh" "$OLD_SELECTOR"
    chmod 755 "$OLD_SELECTOR"

    systemctl daemon-reload

    systemctl start "$SELECTOR_SERVICE" 2>/dev/null || true

    if [ "$TIMER_WAS_ACTIVE" -eq 1 ]; then
        systemctl start "$SELECTOR_TIMER" 2>/dev/null || true
    fi

    echo "Rollback attempted."
    echo "Selector state: $(cat "$STATE_FILE" 2>/dev/null || echo unknown)"
    exit 1
}

#
# Install generic OpenVPN launcher atomically.
#
cp "$NEW_LAUNCHER" "$CFG/vpn-manager-openvpn-launcher.py.new"
chmod 755 "$CFG/vpn-manager-openvpn-launcher.py.new"

mv \
    "$CFG/vpn-manager-openvpn-launcher.py.new" \
    "$CFG/vpn-manager-openvpn-launcher.py"

#
# Install generic OpenVPN systemd unit atomically.
#
cp "$NEW_UNIT" "$SYSTEMD/vpn-manager-openvpn.service.new"

mv \
    "$SYSTEMD/vpn-manager-openvpn.service.new" \
    "$SYSTEMD/vpn-manager-openvpn.service"

#
# Install generalized selector atomically.
#
cp "$NEW_SELECTOR" "$OLD_SELECTOR.new"
chmod 755 "$OLD_SELECTOR.new"

mv \
    "$OLD_SELECTOR.new" \
    "$OLD_SELECTOR"

systemctl daemon-reload

#
# Run the protected selector using the new architecture.
#
if ! systemctl start "$SELECTOR_SERVICE"; then
    rollback
fi

NEW_STATE="$(cat "$STATE_FILE" 2>/dev/null || true)"

case "$NEW_STATE" in
    router)
        if systemctl is-active --quiet "$NEW_SERVICE"; then
            rollback
        fi

        echo "Verified path after migration: router"
        ;;

    local)
        if ! systemctl is-active --quiet "$NEW_SERVICE"; then
            rollback
        fi

        if ! ip route get 1.1.1.1 2>/dev/null |
             grep -q 'dev tun0'; then
            rollback
        fi

        echo "Verified path after migration: managed local OpenVPN"
        ;;

    *)
        rollback
        ;;
esac

if [ "$TIMER_WAS_ACTIVE" -eq 1 ]; then
    systemctl start "$SELECTOR_TIMER"
fi

echo
echo "=== MIGRATION SUCCESSFUL ==="
echo "Selector state: $NEW_STATE"
echo "Old PureVPN unit retained for rollback."
echo "Generic service: $NEW_SERVICE"
