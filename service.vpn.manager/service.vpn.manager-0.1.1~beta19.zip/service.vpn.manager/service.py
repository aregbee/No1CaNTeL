import xbmc
import xbmcgui
import xbmcaddon

from resources.lib.backend_loader import (
    backend_capabilities,
    get_backend,
    platform_name,
)
from resources.lib import netverify

from resources.lib.log_privacy import (
    install_log_filter,
    reset_full_ip_logging,
)

# Privacy failsafe: every service start begins redacted.
reset_full_ip_logging()
install_log_filter()

backend = get_backend()
PLATFORM = platform_name()
CAPABILITIES = backend_capabilities(backend)

import time
import os
import threading
import struct


window = xbmcgui.Window(10000)


ADDON = xbmcaddon.Addon(
    "service.vpn.manager"
)

PROTECTION_SETTING_ID = (
    "protection_enabled"
)


def protection_setting_enabled():
    try:
        return ADDON.getSettingBool(
            PROTECTION_SETTING_ID
        )

    except Exception:
        value = ADDON.getSetting(
            PROTECTION_SETTING_ID
        )

        return str(value).strip().lower() in (
            "true",
            "1",
            "yes",
            "on",
        )


def set_protection_setting(value):
    try:
        ADDON.setSettingBool(
            PROTECTION_SETTING_ID,
            bool(value),
        )

    except Exception:
        ADDON.setSetting(
            PROTECTION_SETTING_ID,
            "true" if value else "false",
        )


def backend_protection_disabled():
    check = getattr(
        backend,
        "protection_disabled",
        None,
    )

    if not check:
        return False

    try:
        return bool(check())

    except Exception:
        return False


# Synchronize the UI with the authoritative backend state.
#
# A persistent deliberate-disabled marker means the toggle
# starts OFF. Otherwise protected mode is requested.
if getattr(
    backend,
    "protection_disabled",
    None,
):
    set_protection_setting(
        not backend_protection_disabled()
    )


class VFDVPNIndicator:
    """
    CoreELEC/OpenVFD VPN indicator.

    verified:
        clock steady
        SETUP icon ON

    checking/switching:
        clock slow flash
        SETUP icon OFF

    fault/fail-closed:
        clock rapid flash
        SETUP icon OFF
    """

    LED_ON = (
        "/sys/class/leds/openvfd/led_on"
    )

    LED_OFF = (
        "/sys/class/leds/openvfd/led_off"
    )

    PIPE = "/tmp/openvfd_service"

    ICON = "setup"

    FRAME_FORMAT = (
        "<HBB6BH4B2H512s128s"
    )

    def __init__(self):
        self.available = (
            os.path.exists(self.LED_ON)
            and os.path.exists(self.LED_OFF)
        )

        self._mode = "off"
        self._stop = threading.Event()
        self._thread = None

    def start(self):
        if not self.available:
            return

        if (
            self._thread
            and self._thread.is_alive()
        ):
            return

        self._thread = threading.Thread(
            target=self._run,
            name="VPNManagerVFD",
            daemon=True,
        )

        self._thread.start()

    def set_mode(self, mode):
        if not self.available:
            return

        if mode not in (
            "steady",
            "slow",
            "rapid",
            "off",
        ):
            mode = "rapid"

        self._mode = mode

    def _set_icon(self, enabled):
        path = (
            self.LED_ON
            if enabled
            else self.LED_OFF
        )

        try:
            with open(
                path,
                "w",
                encoding="utf-8",
            ) as f:
                f.write(
                    self.ICON + "\n"
                )
        except OSError:
            pass

    def _show_clock(self):
        try:
            with open(
                self.PIPE,
                "wb",
                buffering=0,
            ) as f:
                # Return OpenVFD to normal clock mode.
                f.write(b"\x00")
        except OSError:
            pass

    def _blank_clock(self):
        try:
            blank = b"    "

            frame = struct.pack(
                self.FRAME_FORMAT,
                4,          # DISPLAY_MODE_TITLE
                0, 0,
                0, 0, 0,
                0, 0, 0,
                0,
                0, 0, 0, 0,
                0, 0,
                blank.ljust(
                    512,
                    b"\x00",
                ),
                b"".ljust(
                    128,
                    b"\x00",
                ),
            )

            with open(
                self.PIPE,
                "wb",
                buffering=0,
            ) as f:
                f.write(frame)

        except (
            OSError,
            struct.error,
        ):
            pass

    def _run(self):
        previous_mode = None
        clock_visible = True
        next_toggle = 0.0
        next_reassert = 0.0

        while not self._stop.wait(0.10):
            now = time.monotonic()
            mode = self._mode

            if mode != previous_mode:
                previous_mode = mode
                next_toggle = 0.0
                next_reassert = 0.0

                # Every state change starts with a visible clock.
                self._show_clock()
                clock_visible = True

                if mode == "steady":
                    self._set_icon(True)

                else:
                    self._set_icon(False)

            if mode == "steady":
                if now >= next_reassert:
                    self._set_icon(True)
                    next_reassert = (
                        now + 2.0
                    )

                continue

            if mode == "off":
                if now >= next_reassert:
                    self._set_icon(False)
                    next_reassert = (
                        now + 2.0
                    )

                continue

            interval = (
                0.75
                if mode == "slow"
                else 0.20
            )

            if now >= next_toggle:
                if clock_visible:
                    self._blank_clock()
                    clock_visible = False
                else:
                    self._show_clock()
                    clock_visible = True

                next_toggle = (
                    now + interval
                )

    def close(self):
        if not self.available:
            return

        self._mode = "off"
        self._stop.set()

        if self._thread:
            self._thread.join(
                timeout=1.0
            )

        self._set_icon(False)
        self._show_clock()



monitor = xbmc.Monitor()

vfd_indicator = VFDVPNIndicator()
vfd_indicator.start()


def update_vfd_vpn_indicator():
    if not vfd_indicator.available:
        return

    #
    # A running selector means the protection path is
    # actively being checked/changed.
    #
    try:
        if backend.refresh_in_progress():
            vfd_indicator.set_mode(
                "slow"
            )
            return
    except Exception:
        pass

    #
    # Use the backend's existing verified VPN contract
    # rather than creating a second protection detector.
    #
    try:
        state = backend.vpn_state() or {}
    except Exception:
        vfd_indicator.set_mode(
            "rapid"
        )
        return

    if state.get(
        "backend_verified"
    ) is True:
        vfd_indicator.set_mode(
            "steady"
        )
        return

    #
    # failed, local route fault, unknown state, etc.
    # All are intentionally conspicuous.
    #
    vfd_indicator.set_mode(
        "rapid"
    )


def setprop(name, value):
    window.setProperty(name, str(value) if value else "N/A")


def _dashboard_interface(value):
    text = str(value or "").strip()

    if "(" in text and text.endswith(")"):
        return text.rsplit("(", 1)[1][:-1].strip()

    if text in ("", "N/A", "Unknown"):
        return ""

    return text


def _dashboard_path(value):
    text = str(value or "Unknown").strip()
    lower = text.lower()

    if "router" in lower or "upstream" in lower:
        return "Router/Upstream"

    if "local" in lower or "openvpn" in lower:
        return "Local OpenVPN"

    return text


def publish_dashboard_summary(state):
    state = state or {}

    status = str(
        state.get("status", "CHECK VPN")
    ).strip()

    path = _dashboard_path(
        state.get("path", "Unknown")
    )

    interface = _dashboard_interface(
        state.get("interface", "")
    )

    summary = "{} - {}".format(
        status,
        path
    )

    if interface:
        summary += " [{}]".format(interface)

    setprop(
        "VPNManager.StatusSummary",
        summary
    )

    path_lower = str(
        state.get("path", "")
    ).lower()

    status_lower = status.lower()

    if (
        ("local" in path_lower or "openvpn" in path_lower)
        and status_lower == "protected"
    ):
        activity = "Active"

    elif (
        ("router" in path_lower or "upstream" in path_lower)
        and status_lower == "protected"
    ):
        activity = "Standby"

    else:
        activity = "Inactive"

    setprop(
        "VPNManager.ProfileActivity",
        activity
    )


def publish_backend_state(state):
    state = state or {}

    publish_dashboard_summary(state)

    setprop("VPNManager.PublicIP", "Updating...")
    setprop("VPNManager.VPNExitLocation", "Updating...")
    setprop("VPNManager.VPNExitNetwork", "Updating...")
    setprop("VPNManager.VPNPath", state.get("path", "Unknown"))
    setprop("VPNManager.VPNStatus", state.get("status", "CHECK VPN"))
    setprop("VPNManager.VPNInterface", state.get("interface", "N/A"))
    setprop("VPNManager.VPNTunnelIP", state.get("tunnel_ip", "N/A"))
    setprop("VPNManager.VPNServer", state.get("server", "Unknown"))
    setprop("VPNManager.VPNKillSwitch", state.get("killswitch", "Unknown"))
    setprop(
        "VPNManager.VPNVerification",
        state.get("verification", "Backend state unavailable")
    )


def refresh():
    # Publish authoritative local/backend state first.
    # External IP classification is supplemental and must not delay
    # path/status/killswitch changes appearing in Kodi.
    backend_state = backend.vpn_state()
    publish_backend_state(backend_state)

    external = netverify.external_vpn_check()
    state = netverify.merge_state(
        backend_state,
        external
    )

    pub = external.get(
        "public_ip",
        "Unavailable"
    )

    path = state.get("path", "Unknown")
    status = state.get("status", "CHECK VPN")
    interface = state.get("interface", "N/A")
    tip = state.get("tunnel_ip", "N/A")
    server = state.get("server", "Unknown")
    killswitch = state.get("killswitch", "Unknown")
    verification = state.get(
        "verification",
        "Backend state unavailable"
    )

    setprop("VPNManager.PublicIP", pub)
    setprop(
        "VPNManager.VPNExitLocation",
        external.get("exit_location", "Unavailable")
    )
    setprop(
        "VPNManager.VPNExitNetwork",
        external.get("exit_network", "Unavailable")
    )
    setprop("VPNManager.VPNPath", path)
    setprop("VPNManager.VPNStatus", status)
    setprop("VPNManager.VPNInterface", interface)
    setprop("VPNManager.VPNTunnelIP", tip)
    setprop("VPNManager.VPNServer", server)
    setprop("VPNManager.VPNKillSwitch", killswitch)
    setprop("VPNManager.VPNVerification", verification)

    publish_dashboard_summary(state)

    xbmc.log(
        "Kodi VPN Manager: Public={} VPN={} Status={} Verify={}".format(
            pub,
            path,
            status,
            verification
        ),
        xbmc.LOGINFO
    )


AUTO_REFRESH_SECONDS = 300

FAILOVER_PROBE_SECONDS = 30
LOCAL_ROUTER_RECHECK_SECONDS = 120
UNKNOWN_RECHECK_SECONDS = 60
PROBE_FAILURE_CONFIRMATIONS = 2

FAILED_RETRY_DELAYS = (
    30,
    60,
    120,
    300,
)

next_auto_refresh = (
    time.monotonic()
    + AUTO_REFRESH_SECONDS
)

next_failover_probe = (
    time.monotonic()
    + 10
)

router_probe_failures = 0
detector_degraded = False
failed_retry_attempts = 0

last_state_token = backend.state_token()

# Initial display refresh, after backend state tracking exists.
refresh()
update_vfd_vpn_indicator()

last_protection_enabled = (
    protection_setting_enabled()
)

while not monitor.waitForAbort(1):

    update_vfd_vpn_indicator()

    current_protection_enabled = (
        protection_setting_enabled()
    )

    if (
        current_protection_enabled
        != last_protection_enabled
    ):
        requested_enabled = (
            current_protection_enabled
        )

        last_protection_enabled = (
            requested_enabled
        )

        # ====================================================
        # VPN PROTECTION ON
        # ====================================================

        if requested_enabled:
            vfd_indicator.set_mode(
                "slow"
            )

            enable = getattr(
                backend,
                "enable_protection",
                None,
            )

            if not enable:
                result = {
                    "ok": False,
                    "message":
                        "Enable protection unsupported",
                }

            else:
                try:
                    result = enable()

                except Exception as exc:
                    result = {
                        "ok": False,
                        "message": str(exc),
                    }

            if not isinstance(result, dict):
                result = {
                    "ok": False,
                    "message":
                        "Invalid backend result",
                }

            xbmc.log(
                "Kodi VPN Manager: protection ON "
                "request result={}".format(
                    result
                ),
                xbmc.LOGINFO,
            )

            still_disabled = (
                backend_protection_disabled()
            )

            if (
                not result.get("ok")
                and still_disabled
            ):
                # The fail-closed guard could not be armed,
                # therefore we are still deliberately
                # unprotected. Reflect the truth in the UI.
                set_protection_setting(
                    False
                )

                last_protection_enabled = (
                    False
                )

                vfd_indicator.set_mode(
                    "rapid"
                )

                xbmcgui.Dialog().notification(
                    "VPN Protection",
                    (
                        "Could not enable protection. "
                        "Protection remains OFF."
                    ),
                    xbmcgui.NOTIFICATION_ERROR,
                    6000,
                )

            elif not result.get("ok"):
                # Disabled mode was successfully exited and
                # fail-closed protection was armed, but the
                # VPN itself did not verify.
                #
                # Toggle remains ON because protected mode
                # is still the requested state.
                vfd_indicator.set_mode(
                    "rapid"
                )

                xbmcgui.Dialog().notification(
                    "VPN Protection",
                    (
                        "VPN connection failed. "
                        "Fail-closed protection is active."
                    ),
                    xbmcgui.NOTIFICATION_ERROR,
                    6000,
                )

            refresh()

        # ====================================================
        # VPN PROTECTION OFF
        # ====================================================

        else:
            confirmed = (
                xbmcgui.Dialog().yesno(
                    "Disable VPN Protection",
                    (
                        "Turn VPN protection OFF?\n\n"
                        "Normal ISP Internet access will "
                        "be allowed and automatic VPN "
                        "reconnect will be suppressed until "
                        "protection is turned back ON."
                    ),
                )
            )

            if not confirmed:
                set_protection_setting(
                    True
                )

                last_protection_enabled = (
                    True
                )

            else:
                # Make deliberate unprotected mode visually
                # conspicuous immediately.
                vfd_indicator.set_mode(
                    "rapid"
                )

                disable = getattr(
                    backend,
                    "disable_protection",
                    None,
                )

                if not disable:
                    result = {
                        "ok": False,
                        "message":
                            "Disable protection unsupported",
                    }

                else:
                    try:
                        result = disable()

                    except Exception as exc:
                        result = {
                            "ok": False,
                            "message": str(exc),
                        }

                if not isinstance(result, dict):
                    result = {
                        "ok": False,
                        "message":
                            "Invalid backend result",
                    }

                xbmc.log(
                    "Kodi VPN Manager: protection OFF "
                    "request result={}".format(
                        result
                    ),
                    xbmc.LOGINFO,
                )

                if not result.get("ok"):
                    disabled_now = (
                        backend_protection_disabled()
                    )

                    # Request protected mode again.
                    set_protection_setting(
                        True
                    )

                    if disabled_now:
                        # Force the next loop through the safe
                        # OFF -> ON transition.
                        last_protection_enabled = (
                            False
                        )
                    else:
                        last_protection_enabled = (
                            True
                        )

                    xbmcgui.Dialog().notification(
                        "VPN Protection",
                        (
                            "Disable did not complete. "
                            "Protected mode is being restored."
                        ),
                        xbmcgui.NOTIFICATION_ERROR,
                        6000,
                    )

                refresh()

    current_state_token = backend.state_token()

    state_changed = (
        bool(current_state_token)
        and current_state_token != last_state_token
    )

    if state_changed:
        xbmc.log(
            "Kodi VPN Manager: VPN state changed {} -> {}".format(
                last_state_token or "unknown",
                current_state_token
            ),
            xbmc.LOGINFO
        )

        last_state_token = current_state_token

    #
    # Lightweight automatic failover watchdog v2.
    #
    now = time.monotonic()

    try:
        managed_protection_disabled = bool(
            backend.protection_disabled()
        )
    except Exception:
        managed_protection_disabled = False

    if (
        now >= next_failover_probe
        and not managed_protection_disabled
    ):

        try:
            selector_mode = backend.selector_state()
        except Exception:
            selector_mode = "unknown"

        request_selector = False
        request_reason = None
        next_delay = FAILOVER_PROBE_SECONDS

        # ----------------------------------------------------
        # Router mode
        # ----------------------------------------------------
        if selector_mode == "router":

            failed_retry_attempts = 0

            try:
                probe = (
                    backend.lightweight_router_probe()
                    or {}
                )
            except Exception as exc:
                probe = {
                    "ok": False,
                    "changed": False,
                    "physical_internet": None,
                    "reason": str(exc),
                }

            if probe.get("ok"):

                router_probe_failures = 0
                detector_degraded = False

                if probe.get("changed"):
                    request_selector = True

                    request_reason = (
                        "router upstream fingerprint changed "
                        "{} -> {}".format(
                            probe.get(
                                "previous_ip",
                                "unknown",
                            ),
                            probe.get(
                                "current_ip",
                                "unknown",
                            ),
                        )
                    )

            elif probe.get("physical_internet") is True:

                # Internet still works. Failure of the public-IP
                # detector alone is NOT evidence of VPN loss.
                router_probe_failures = 0

                if not detector_degraded:
                    xbmc.log(
                        "Kodi VPN Manager: public-IP detector "
                        "degraded while physical Internet remains "
                        "reachable; selector suppressed: {}".format(
                            probe.get(
                                "reason",
                                "unknown",
                            )
                        ),
                        xbmc.LOGWARNING
                    )

                detector_degraded = True

            else:

                detector_degraded = False
                router_probe_failures += 1

                if (
                    router_probe_failures
                    >= PROBE_FAILURE_CONFIRMATIONS
                ):
                    request_selector = True

                    request_reason = (
                        "physical upstream unavailable "
                        "{} consecutive times".format(
                            router_probe_failures
                        )
                    )

                    router_probe_failures = 0

            next_delay = FAILOVER_PROBE_SECONDS

        # ----------------------------------------------------
        # Local mode
        # ----------------------------------------------------
        elif selector_mode == "local":

            router_probe_failures = 0
            detector_degraded = False
            failed_retry_attempts = 0

            request_selector = True
            request_reason = (
                "periodic protected router recovery check"
            )

            next_delay = LOCAL_ROUTER_RECHECK_SECONDS

        # ----------------------------------------------------
        # Fail-closed mode
        # ----------------------------------------------------
        elif selector_mode == "failed":

            router_probe_failures = 0
            detector_degraded = False

            index = min(
                failed_retry_attempts,
                len(FAILED_RETRY_DELAYS) - 1,
            )

            retry_delay = FAILED_RETRY_DELAYS[index]

            try:
                recovery = (
                    backend.failed_recovery_probe()
                    or {}
                )
            except Exception as exc:
                recovery = {
                    "ready": False,
                    "reason": str(exc),
                }

            if recovery.get("ready"):

                request_selector = True
                request_reason = (
                    "failed-path recovery signal: {}".format(
                        recovery.get(
                            "reason",
                            "ready",
                        )
                    )
                )

            else:

                xbmc.log(
                    "Kodi VPN Manager: fail-closed path "
                    "still has no recovery signal; selector "
                    "suppressed; retry in {}s".format(
                        retry_delay
                    ),
                    xbmc.LOGINFO
                )

            failed_retry_attempts += 1
            next_delay = retry_delay

        # ----------------------------------------------------
        # Unknown / startup state
        # ----------------------------------------------------
        else:

            router_probe_failures = 0
            detector_degraded = False
            failed_retry_attempts = 0

            request_selector = True
            request_reason = (
                "VPN path is {}".format(
                    selector_mode or "unknown"
                )
            )

            next_delay = UNKNOWN_RECHECK_SECONDS

        if request_selector:

            xbmc.log(
                "Kodi VPN Manager: automatic selector request: "
                "{}".format(
                    request_reason
                ),
                xbmc.LOGINFO
            )

            vfd_indicator.set_mode(
                "slow"
            )

            try:
                backend.request_refresh()

            except Exception as exc:
                xbmc.log(
                    "Kodi VPN Manager: automatic selector "
                    "request failed: {}".format(
                        exc
                    ),
                    xbmc.LOGERROR
                )

        # Re-base AFTER any blocking selector run.
        next_failover_probe = (
            time.monotonic()
            + next_delay
        )

    manual_refresh = (
        window.getProperty("VPNManager.RefreshVPN") == "1"
    )

    timed_refresh = (
        time.monotonic() >= next_auto_refresh
    )

    if manual_refresh or timed_refresh or state_changed:

        if manual_refresh:
            window.clearProperty("VPNManager.RefreshVPN")
            setprop("VPNManager.VPNStatus", "Refreshing...")
            setprop("VPNManager.VPNVerification", "Checking now...")

            xbmc.log(
                "Kodi VPN Manager: Manual VPN refresh requested",
                xbmc.LOGINFO
            )

            vfd_indicator.set_mode(
                "slow"
            )

            try:
                result = backend.request_refresh()

                # If a backend refresh is already running,
                # wait for it to finish before reading state.
                for _ in range(90):
                    if not backend.refresh_in_progress():
                        break

                    if monitor.waitForAbort(0.5):
                        break

                xbmc.log(
                    "Kodi VPN Manager: VPN refresh result={}".format(
                        result if result is not None else "unavailable"
                    ),
                    xbmc.LOGINFO
                )

            except Exception as exc:
                xbmc.log(
                    "Kodi VPN Manager: VPN refresh failed: {}".format(exc),
                    xbmc.LOGERROR
                )

        if state_changed and not manual_refresh:
            monitor.waitForAbort(2)

        refresh()

        # Prevent a manual backend refresh from causing a duplicate refresh.
        last_state_token = backend.state_token() or last_state_token

        next_auto_refresh = (
            time.monotonic() + AUTO_REFRESH_SECONDS
        )


vfd_indicator.close()

# Privacy failsafe: never preserve diagnostic IP logging
# after the persistent service exits.
reset_full_ip_logging()

for prop in (
    "VPNManager.PublicIP",
    "VPNManager.VPNExitLocation",
    "VPNManager.VPNExitNetwork",
    "VPNManager.VPNPath",
    "VPNManager.VPNStatus",
    "VPNManager.StatusSummary",
    "VPNManager.ProfileActivity",
    "VPNManager.VPNInterface",
    "VPNManager.VPNTunnelIP",
    "VPNManager.VPNServer",
    "VPNManager.VPNKillSwitch",
    "VPNManager.VPNVerification",
):
    window.clearProperty(prop)
